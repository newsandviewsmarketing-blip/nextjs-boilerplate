import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const root = fileURLToPath(new URL("..", import.meta.url));
const read = (path) => readFileSync(join(root, path), "utf8");
const phase3Paths = [
  "supabase/migrations/202608110001_phase3_roles.sql",
  "supabase/migrations/202608110002_phase3_foundation.sql",
  "supabase/migrations/202608110003_phase3_master_data.sql",
  "supabase/migrations/202608110004_phase3_permissions.sql",
  "supabase/migrations/202608110005_phase3_privacy_cutover.sql",
];
const phase4Path = "supabase/migrations/202608170001_phase4_admin_control.sql";

test("Phase 1 and Phase 2 migrations remain byte-for-byte unchanged", () => {
  const expected = new Map([
    ["supabase/migrations/202608090001_backend_phase1.sql", "51c9945b827290c403ee320696a11a76d30af1dae71afde1a4375961cb99dbcf"],
    ["supabase/migrations/202608090002_backend_phase2.sql", "399fe7a5f4927d050da12dbd51bb50f4292a78c2265006042b2c396ae5d7834c"],
  ]);

  for (const [path, hash] of expected) {
    const actual = createHash("sha256").update(readFileSync(join(root, path))).digest("hex");
    assert.equal(actual, hash, `${path} must not be changed by Phase 3`);
  }
});

test("every Phase 3 migration has an explicit transaction boundary", () => {
  for (const path of phase3Paths) {
    const sql = read(path);
    assert.match(sql, /^begin;$/m, `${path} is missing begin`);
    assert.match(sql, /^commit;$/m, `${path} is missing commit`);
  }
});

test("Phase 3 migrations do not delete existing schema or data", () => {
  const sql = phase3Paths.map(read).join("\n");
  assert.doesNotMatch(sql, /\bdrop\s+table\b|\bdrop\s+column\b|\btruncate\b|\bdelete\s+from\b/i);
});

test("all additive Phase 3 policies can be retried", () => {
  for (const path of phase3Paths.slice(1, 3)) {
    const sql = read(path);
    const policies = [...sql.matchAll(/create policy "([^"]+)" on public\.([a-z_]+)/g)];
    for (const [, name, table] of policies) {
      assert.ok(
        sql.includes(`drop policy if exists "${name}" on public.${table};`),
        `${path} must drop ${name} before recreating it`,
      );
    }
  }
});

test("legacy public-table access is revoked only after frontend cutover", () => {
  const preDeploy = phase3Paths.slice(0, 4).map(read).join("\n");
  const cutover = read(phase3Paths[4]);
  assert.doesNotMatch(preDeploy, /drop policy if exists "vets_public_approved"|drop policy if exists "companies_public_approved"|revoke all on public\.veterinarian_profiles/i);
  assert.match(cutover, /drop policy if exists "vets_public_approved"/);
  assert.match(cutover, /drop policy if exists "companies_public_approved"/);
  assert.match(cutover, /revoke all on public\.veterinarian_profiles, public\.company_profiles from anon/);
});

test("public company view preserves its original first nine columns", () => {
  const sql = read("supabase/migrations/202608110003_phase3_master_data.sql");
  assert.match(
    sql,
    /select c\.user_id, coalesce\(c\.trade_name, c\.company_name\) as company_name, c\.business_type, c\.city, c\.address, coalesce\(c\.short_description, c\.description\) as description, c\.website, c\.contact_email, c\.logo_url, c\.slug/,
  );
});

test("approved profile images flow from privacy-safe views to public pages", () => {
  const foundation = read("supabase/migrations/202608110002_phase3_foundation.sql");
  const directories = read("lib/directories.ts");
  const pages = [
    "app/components/ProfilePhoto.tsx",
    "app/vets/page.tsx",
    "app/vets/[id]/page.tsx",
    "app/professionals/page.tsx",
    "app/professionals/[slug]/page.tsx",
  ].map(read).join("\n");

  assert.match(foundation, /true as pvmc_verified, v\.image_url/);
  assert.match(foundation, /true as profile_verified, pp\.image_url/);
  assert.match(directories, /image_url: string \| null/);
  assert.match(pages, /profile-photo/);
  assert.doesNotMatch(pages, /pvmc_number/);
});

test("mobile navigation remains accessible at compact widths", () => {
  const header = read("app/components/SiteHeader.tsx");
  const mobile = read("app/components/MobileNav.tsx");
  const css = read("app/globals.css");

  assert.match(header, /<MobileNav items=\{navItems\}/);
  assert.match(mobile, /aria-expanded=\{isOpen\}/);
  assert.match(mobile, /aria-controls="mobile-navigation-panel"/);
  assert.match(mobile, /event\.key === "Escape"/);
  assert.match(css, /@media \(max-width: 1050px\)[\s\S]*?\.mobile-navigation \{\s*display: block;/);
});

test("Phase 4 migration is transactional and preserves existing data", () => {
  const sql = read(phase4Path);
  assert.match(sql, /^begin;$/m);
  assert.match(sql, /^commit;$/m);
  assert.doesNotMatch(sql, /\bdrop\s+table\b|\bdrop\s+column\b|\btruncate\b|\bdelete\s+from\b/i);
  assert.match(sql, /add column if not exists archived_at timestamptz/);
  assert.match(sql, /create table if not exists public\.admin_role_permissions/);
});

test("administrator hierarchy narrows legacy access and protects role management", () => {
  const sql = read(phase4Path);
  const admin = read("lib/admin.ts");
  assert.match(sql, /select public\.is_super_admin\(check_user_id\);/);
  assert.match(sql, /create policy "roles_admin_manage"[\s\S]*?public\.is_super_admin\(\)/);
  assert.match(sql, /create policy "products_content_manage"[\s\S]*?public\.can_manage_content\(\)/);
  assert.match(sql, /create policy "jobs_content_manage"[\s\S]*?public\.can_manage_jobs\(\)/);
  assert.match(admin, /verification_officer:[\s\S]*?"profiles\.review"/);
  assert.match(admin, /analyst: \["admin\.view", "audit\.view", "analytics\.view"\]/);
});

test("product administration implements the complete controlled lifecycle", () => {
  const actions = read("app/admin/products/actions.ts");
  const pages = [
    "app/admin/products/page.tsx",
    "app/admin/products/new/page.tsx",
    "app/admin/products/[id]/page.tsx",
    "app/dashboard/company/products/[id]/page.tsx",
  ].map(read).join("\n");
  assert.match(actions, /requireAdminPermission\("products\.manage"/);
  assert.match(actions, /\["publish", "unpublish", "pending", "reject", "archive", "restore"\]/);
  assert.match(actions, /requireAdminPermission\("products\.delete"/);
  assert.match(actions, /confirmation !== "DELETE"/);
  assert.match(pages, /Add product/);
  assert.match(pages, /Approve & publish/);
  assert.match(pages, /Save and submit changes/);
});

test("new administrator mutations verify permissions inside server actions", () => {
  const productActions = read("app/admin/products/actions.ts");
  const userActions = read("app/admin/users/actions.ts");
  assert.match(productActions, /^"use server";/);
  assert.match(productActions, /requireAdminPermission\("products\.manage"/);
  assert.match(userActions, /^"use server";/);
  assert.match(userActions, /requireAdminPermission\("users\.manage"/);
  assert.match(userActions, /cannot remove your own Super Administrator role/);
  assert.match(userActions, /cannot suspend your own administrator account/);
});

test("veterinarian profile uses standardized sector, specialization and service selectors", () => {
  const dashboard = read("app/dashboard/page.tsx");
  const fields = read("app/components/VeterinaryProfileFields.tsx");
  const actions = read("app/dashboard/actions.ts");
  assert.match(dashboard, /<VeterinaryProfileFields/);
  assert.match(fields, /name="veterinary_sector"/);
  assert.match(fields, /name="specialization"/);
  assert.match(fields, /type="checkbox"[\s\S]*?name="services"|name="services"[\s\S]*?type="checkbox"/);
  assert.match(actions, /formData\.getAll\("services"\)/);
});

test("account location uses dependent Pakistan administrative selectors", () => {
  const dashboard = read("app/dashboard/page.tsx");
  const locations = read("app/components/PakistanLocationFields.tsx");
  const migration = read("supabase/migrations/202608300001_profile_standardization.sql");
  assert.match(dashboard, /<PakistanLocationFields/);
  assert.match(locations, /Province \/ Territory/);
  assert.match(locations, /District/);
  assert.match(locations, /Tehsil \/ Taluka/);
  assert.match(locations, /public\/data\/pakistan-administrative-hierarchy\.json/);
  assert.doesNotMatch(locations, /fetch\(/);
  assert.match(migration, /^begin;$/m);
  assert.match(migration, /^commit;$/m);
  assert.doesNotMatch(migration, /\bdrop\s+table\b|\bdrop\s+column\b|\btruncate\b|\bdelete\s+from\b/i);
});

test("career workspace and veterinarian job application flow are active", () => {
  const dashboard = read("app/dashboard/page.tsx");
  const career = read("app/dashboard/career/page.tsx");
  const jobs = read("app/jobs/actions.ts");
  const routes=read("lib/professional-workspace.ts");
  assert.match(dashboard, /active="account" module="account"/);
  assert.match(routes, /href:'\/dashboard\/career'/);
  assert.match(career, /MY APPLICATIONS/);
  assert.match(career, /job_applications/);
  assert.match(jobs, /"veterinarian"/);
  // Applicants need an eligible account, verified email, valid private CV, and
  // an open published job. The old professional-profile approval prerequisite
  // is no longer part of the approved application workflow.
  assert.match(jobs, /matchingVerifiedAccountEmail/);
  assert.match(jobs, /inspectCvFile/);
  assert.match(jobs, /from\("public_jobs"\)/);
  assert.match(jobs, /jobStatus\.deadline/);
  assert.doesNotMatch(jobs, /careerProfile\?\.verification_status !== "approved"/);
});

test("admin directory supports standardized filters and CSV export", () => {
  const users = read("app/admin/users/page.tsx");
  const route = read("app/admin/users/export/route.ts");
  assert.match(users, /Veterinary sector/);
  assert.match(users, /All provinces/);
  assert.match(users, /All districts/);
  assert.match(users, /admin-directory-table/);
  assert.match(users, /\/admin\/users\/export/);
  assert.match(route, /vetconnect-users-directory\.csv/);
  assert.match(route, /"PVMC"/);
  assert.match(route, /"Veterinary Sector"/);
});


test("professional workspace supports rich profile, photo, education, experience and CV records", () => {
  const page = read("app/dashboard/professional/page.tsx");
  const actions = read("app/dashboard/professional/actions.ts");
  const migration = read("supabase/migrations/202608300002_workspaces_and_media.sql");
  const publicPage = read("app/professionals/[slug]/page.tsx");
  // The workspace heading is now centralized in the shared frame.
  const frame = read("app/components/CareerWorkspaceFrame.tsx");
  assert.match(page, /CareerWorkspaceFrame/);
  assert.match(frame, /PROFESSIONAL WORKSPACE/);
  assert.match(page, /professional_education/);
  assert.match(page, /professional_experience/);
  assert.match(page, /professional_credentials/);
  assert.match(page, /career_documents/);
  assert.match(actions, /profile-media/);
  assert.match(actions, /career-documents/);
  assert.match(migration, /insert into storage\.buckets/);
  assert.match(migration, /professional_education_public_read/);
  assert.match(publicPage, /Professional experience/);
  assert.match(publicPage, /VERIFIED CREDENTIALS/);
});

test("core profile progress is consistent and independent from practitioner verification", () => {
  const shared = read("lib/professional-progress.ts");
  const frame = read("app/components/CareerWorkspaceFrame.tsx");
  const profile = read("app/dashboard/professional/page.tsx");
  const career = read("app/career/page.tsx");
  assert.match(shared, /coreProfileChecks/);
  assert.match(shared, /Basic identity/);
  assert.match(shared, /Education or work background/);
  assert.match(frame, /getCoreProfileProgress/);
  assert.match(profile, /<CareerWorkspaceFrame active="profile"/);
  assert.doesNotMatch(profile, /completion=\{completion\}/);
  assert.match(frame, /isVeterinaryPractitioner/);
  assert.match(frame, /pvmc\.gov\.pk\/Registration\/Search/);
  assert.match(career, /CV details are saved/);
});

test("clinic workspace activates facility profile, media, services and affiliation request", () => {
  const listPage = read("app/dashboard/clinics/page.tsx");
  const detailPage = read("app/dashboard/clinics/[id]/page.tsx");
  const actions = read("app/dashboard/clinics/actions.ts");
  const publicPage = read("app/clinics/[slug]/page.tsx");
  assert.match(listPage, /CareerWorkspaceFrame/);
  assert.match(listPage, /Practices and clinics you manage/);
  assert.match(detailPage, /ClinicRateCard/);
  assert.match(detailPage, /uploadClinicMediaAction/);
  assert.match(actions, /request_clinic_membership/);
  assert.match(actions, /clinic_services/);
  assert.match(publicPage, /Request clinic affiliation/);
  assert.match(publicPage, /clinic_services/);
});

test("career workspace supports saved jobs and calculated job matches", () => {
  const career = read("app/dashboard/career/page.tsx");
  const jobActions = read("app/jobs/actions.ts");
  const jobDetail = read("app/jobs/[slug]/page.tsx");
  assert.match(career, /SAVED JOBS/);
  assert.match(career, /JOB MATCHES/);
  assert.match(career, /job_matches/);
  assert.match(jobActions, /toggleSavedJobAction/);
  assert.match(jobActions, /saved_jobs/);
  assert.match(jobDetail, /Save job/);
});

test("new 30 August migrations are additive and transactional", () => {
  for (const path of [
    "supabase/migrations/202608300001_profile_standardization.sql",
    "supabase/migrations/202608300002_workspaces_and_media.sql",
  ]) {
    const sql = read(path);
    assert.match(sql, /^begin;$/m);
    assert.match(sql, /^commit;$/m);
    assert.doesNotMatch(sql, /\bdrop\s+table\b|\bdrop\s+column\b|\btruncate\b|\bdelete\s+from\b/i);
  }
});

test("admin home provides operational pulse and eight-entry recent update summary", async () => {
  const admin = await read("app/admin/page.tsx");
  assert.match(admin, /LAST 24 HOURS/);
  assert.match(admin, /New registrations/);
  assert.match(admin, /Pending clinic affiliations/);
  assert.match(admin, /Latest recorded actions/);
  assert.match(admin, /\.limit\(8\)/);
});

test("release closure preserves assisted-entry data and adds media/document uploads", () => {
  const page = read("app/admin/create/page.tsx");
  const persistentForm = read("app/admin/create/PersistentForm.tsx");
  const uploads = read("lib/admin-uploads.ts");
  assert.match(page, /<PersistentForm/);
  assert.match(page, /type="file"/);
  assert.match(uploads, /record-documents/);
  assert.match(persistentForm, /sessionStorage/);
  assert.doesNotMatch(persistentForm, /localStorage/);
  assert.match(page, /draft-v2:\$\{identity\.userId\}/);
  assert.match(persistentForm, /data-draft/);
  assert.match(persistentForm, /selectedOptions/);
  assert.match(persistentForm, /clearSaved/);
  assert.match(uploads, /uploadPublicImage/);
  assert.match(uploads, /uploadPrivateDocument/);
  assert.match(uploads, /admin_record_documents/);
});

test("release closure provides guarded CSV and XLSX assisted imports", () => {
  const page = read("app/admin/create/page.tsx");
  const actions = read("app/admin/create/bulk-actions.ts");
  const parser = read("lib/tabular-import.ts");
  assert.match(page, /bulkImportAction/);
  assert.match(page, /accept="\.csv,\.xlsx/);
  assert.match(actions, /maximum%20of%20250/);
  assert.match(actions, /verification_status: "pending"/);
  assert.match(actions, /is_published: false/);
  assert.match(parser, /parseCsv/);
  assert.match(parser, /parseXlsx/);
});

test("release closure publishes approved professional records through controlled review", () => {
  const actions = read("app/admin/actions.ts");
  const reviews = read("app/admin/reviews/page.tsx");
  assert.match(actions, /profile_visibility: decision === "approved" \? "public" : "owner_only"/);
  assert.match(actions, /recordSource === "managed_people"/);
  assert.match(actions, /recordSource === "companies"/);
  assert.match(actions, /recordSource === "clinics"/);
  assert.match(reviews, /managed_people/);
  assert.match(reviews, /canonicalCompanies/);
  assert.match(reviews, /admin_record_documents/);
});

test("release closure migration is transactional and adds private evidence storage", () => {
  const sql = read("supabase/migrations/202608300004_release_closure_uploads.sql");
  assert.match(sql, /^begin;$/m);
  assert.match(sql, /^commit;$/m);
  assert.match(sql, /create table if not exists public\.admin_record_documents/);
  assert.match(sql, /'record-documents'/);
  assert.match(sql, /add column if not exists company_id uuid references public\.companies/);
  assert.match(sql, /coalesce\(c\.canonical_name/);
  assert.doesNotMatch(sql, /\btruncate\b|\bdelete\s+from\b/i);
});

test("marketplace and review queues resolve canonical companies", () => {
  const marketplace = read("app/marketplace/page.tsx") + read("app/marketplace/[slug]/page.tsx");
  const reviews = read("app/admin/reviews/page.tsx");
  assert.match(marketplace, /company_id/);
  assert.match(marketplace, /public_company_directory/);
  assert.match(reviews, /canonicalProductCompanyMap/);
  assert.match(reviews, /companyNameFor/);
});

test("master closure migration can build canonical public jobs before release closure", () => {
  const sql = read("supabase/migrations/202608300003_master_closure_operations.sql");
  assert.match(sql, /coalesce\(c\.canonical_name, cp\.trade_name, cp\.company_name/);
  assert.doesNotMatch(sql, /coalesce\(c\.company_name, cp\.trade_name/);
});


test("job coverage matching honors province-wide, selected districts, cities and optional tehsil", async () => {
  // Exercise the actual production matching module rather than a duplicate implementation.
  const ts = await import("typescript");
  const vm = await import("node:vm");
  const compiled = ts.default.transpileModule(read("lib/job-location.ts"), {
    compilerOptions: {
      module: ts.default.ModuleKind.CommonJS,
      esModuleInterop: true,
      resolveJsonModule: true,
      target: ts.default.ScriptTarget.ES2022,
    },
  }).outputText;
  const cityModule = { exports: {} };
  const cityCompiled = ts.default.transpileModule(read("lib/city-normalization.ts"), {
    compilerOptions: { module: ts.default.ModuleKind.CommonJS, target: ts.default.ScriptTarget.ES2022 },
  }).outputText;
  vm.runInNewContext(cityCompiled, {
    module: cityModule,
    exports: cityModule.exports,
    require: (name) => { throw new Error("Unexpected city module import: " + name); },
  });
  const exported = { exports: {} };
  const geo = JSON.parse(read("public/data/pakistan-administrative-hierarchy.json"));
  vm.runInNewContext(compiled, {
    module: exported,
    exports: exported.exports,
    require: (name) => {
      if (name === "../public/data/pakistan-administrative-hierarchy.json") return geo;
      if (name === "./city-normalization") return cityModule.exports;
      throw new Error("Unexpected module import: " + name);
    },
  });
  const {matchesJobLocation, locationSearchOptions} = exported.exports;
  // The public dropdown must expose every tehsil that the matching helper accepts.
  // Check the actual reference hierarchy, not a hand-maintained subset.
  const choices = locationSearchOptions();
  const tehsils = geo.data.flatMap(province =>
    province.district.flatMap(district => district.tehsil.map(tehsil => tehsil.name.en)));
  for (const name of tehsils) {
    assert.ok(choices.includes(name), `Public job location filter omits tehsil: ${name}`);
  }
  assert.ok(choices.includes("Kingri"));
  assert.ok(choices.includes("Khanpur"));
  assert.equal(new Set(choices).size, choices.length, "Location dropdown should not duplicate names");
  const base = {
    city: null, district: null, province: "Punjab",
    coverage: {scope:"province",province:"Punjab",display_text:"All Punjab"},
    coverage_areas:[],
  };
  assert.equal(matchesJobLocation(base, "Faisalabad"), true);
  assert.equal(matchesJobLocation(base, "Lahore"), true);
  assert.equal(matchesJobLocation(base, "Sindh"), false);
  assert.equal(matchesJobLocation(base, "Karachi"), false);

  const districts = {
    ...base,
    coverage: {scope:"multiple",province:"Punjab",display_text:"Faisalabad and Toba Tek Singh"},
    coverage_areas:[
      {district:"Faisalabad",city:null,label:"Faisalabad",province:"Punjab"},
      {district:"Toba Tek Singh",city:null,label:"Toba Tek Singh",province:"Punjab"},
    ],
  };
  assert.equal(matchesJobLocation(districts, "Faisalabad"), true);
  assert.equal(matchesJobLocation(districts, "Toba Tek Singh"), true);
  assert.equal(matchesJobLocation(districts, "Faisalabad City"), true);
  assert.equal(matchesJobLocation(districts, "Lahore"), false);
  assert.equal(matchesJobLocation(districts, "Punjab"), true);

  const cityOnly = {
    ...base,
    coverage: {scope:"city",province:"Punjab",display_text:"Lahore"},
    coverage_areas:[{district:null,city:"Lahore",label:"Lahore",province:"Punjab"}],
  };
  assert.equal(matchesJobLocation(cityOnly, "Lahore"), true);
  assert.equal(matchesJobLocation(cityOnly, "Faisalabad"), false);
  assert.equal(matchesJobLocation({...cityOnly,coverage:{scope:"flexible",province:null,display_text:"TBA"}}, "Lahore"), false);
  assert.equal(matchesJobLocation({...base,coverage:{scope:"nationwide",province:null,display_text:"Pakistan"}}, "Karachi"), true);

  // The reference hierarchy includes Khanpur in KP, Punjab and Sindh, and
  // Kingri in Balochistan and Sindh. A first-match-only map loses valid jobs.
  for (const province of ["Khyber Pakhtunkhwa", "Punjab", "Sindh"]) {
    const provinceJob = {
      ...base, province,
      coverage: {scope:"province",province,display_text:`All ${province}`},
    };
    assert.equal(matchesJobLocation(provinceJob, "Khanpur"), true, province);
  }
  for (const province of ["Balochistan", "Sindh"]) {
    const provinceJob = {
      ...base, province,
      coverage: {scope:"province",province,display_text:`All ${province}`},
    };
    assert.equal(matchesJobLocation(provinceJob, "Kingri"), true, province);
  }
  assert.equal(matchesJobLocation({
    ...base,
    coverage: {scope:"multiple",province:"Punjab",display_text:"Rahim Yar Khan"},
    coverage_areas: [{district:"Rahim Yar Khan",city:null,label:"Rahim Yar Khan",province:"Punjab"}],
  }, "Khanpur"), true);
  assert.equal(matchesJobLocation({
    ...base, province:"Balochistan",
    coverage: {scope:"province",province:"Balochistan",display_text:"All Balochistan"},
  }, "Khanpur"), false);
});


test("staff and employer job forms share optional multi-location territory data", () => {
  const admin = read("app/admin/create/page.tsx");
  const company = read("app/dashboard/company/page.tsx");
  const fields = read("app/admin/create/JobTerritoryFields.tsx");
  const adminAction = read("app/admin/create/actions.ts");
  const companyAction = read("app/dashboard/company/actions.ts");
  const publicJobs = read("app/jobs/page.tsx");
  const locationLogic = read("lib/job-location.ts");

  assert.match(admin, /<JobTerritoryFields/);
  assert.match(company, /<JobTerritoryFields/);
  assert.doesNotMatch(company, /<PakistanLocationFields fieldPrefix="job_"/);
  assert.match(fields, /coverage_districts/);
  assert.match(fields, /coverage_cities/);
  assert.match(fields, /region_name/);
  assert.match(fields, /Add tehsil \/ taluka/);
  assert.match(fields, /Advertised location text \(optional\)/);

  for (const action of [adminAction,companyAction]) {
    assert.match(action, /from\("job_coverage"\)\.insert/);
    assert.match(action, /from\("job_coverage_areas"\)\.insert/);
    assert.match(action, /minimum_experience:[^\n]*null/);
    assert.match(action, /verification_status:"pending",is_published:false/);
  }
  assert.match(companyAction, /requireWorkspace\("jobs\.manage", formData\)/);
  assert.match(company, /coverage_display/);
  assert.match(publicJobs, /matchesJobLocation/);
  // Public filters offer locations found in published jobs, not every administrative subdivision.\n  assert.match(publicJobs, /jobs\.flatMap\(job/);\n  assert.doesNotMatch(publicJobs, /locationSearchOptions\(\)/);
  assert.match(locationLogic, /scope==="nationwide"/);
});


test("job submission is pending with a full receipt and admin review links",()=>{
  const admin=read("app/admin/create/page.tsx");
  const company=read("app/dashboard/company/page.tsx");
  const receipt=read("app/components/JobSubmissionReceipt.tsx");
  const adminActions=read("app/admin/create/actions.ts");
  const companyActions=read("app/dashboard/company/actions.ts");
  const review=read("app/admin/reviews/page.tsx");
  for(const page of [admin,company])assert.match(page,/<JobSubmissionReceipt/);
  assert.match(receipt,/role="dialog"/);
  assert.match(receipt,/Status:<\/strong> Pending approval/);
  assert.match(receipt,/Minimum qualification/);
  assert.match(review,/id=\{"job-"\+job\.id\}/);
  assert.match(read("app/admin/components/AdminNav.tsx"),/href:"\/admin\/reviews#jobs-review"/);
  for(const action of [adminActions,companyActions]){
    assert.match(action,/proposeJobMasterTerms\(/);
    assert.match(action,/emailJobReviewNotice\(/);
    assert.match(action,/is_published:false/);
  }
});

test("approved master options include Other suggestions but are not auto-published",()=>{
  const field=read("app/components/JobMasterChoice.tsx");
  const approvals=read("app/admin/data/actions.ts");
  const studio=read("app/admin/data/page.tsx");
  const suggestions=read("lib/job-review-helpers.ts");
  const migration=read("supabase/migrations/20261023065621_job_master_suggestions_review_outbox_20261023.sql");
  assert.match(field,/Other \/ Add new option/);
  assert.match(field,/job_qualification/);
  assert.match(approvals,/requireAdminPermission\("master_data\.manage"/);
  assert.match(studio,/suggestions-to-review/);
  assert.match(suggestions,/status:"pending"/);
  assert.match(migration,/create table if not exists public\.master_data_suggestions/);
  assert.match(migration,/lower\(trim\(label\)\)='punjab'/);
  assert.match(migration,/trg_queue_pending_job_review/);
  assert.doesNotMatch(migration,/drop table|truncate table/i);
});


test("CV applications require an owned saved CV or a builder snapshot",()=>{
 const apply=read("app/jobs/actions.ts");
 const page=read("app/jobs/[slug]/page.tsx");
 const career=read("app/dashboard/career/page.tsx");
 const cvAction=read("app/dashboard/career/actions.ts");
 const employer=read("app/dashboard/company/page.tsx");
 const privateRoute=read("app/api/career/documents/[id]/route.ts");
 assert.match(page,/name="cv_choice"/);
 assert.match(page,/Upload a new CV with this application/);
 assert.match(apply,/professional_user_id",identity.userId/);
 assert.match(apply,/career_cv_profiles/);
 assert.match(apply,/cv_snapshot: snapshot/);
 assert.match(career,/uploadCareerCvAction/);
 assert.match(cvAction,/career-documents/);
 assert.match(employer,/cv_document_id/);
 assert.match(privateRoute,/createSignedUrl/);
});

test("job advertisement is an approved-only image, never the private support file",()=>{
 const admin=read("app/admin/create/page.tsx");
 const company=read("app/dashboard/company/page.tsx");
 const helper=read("lib/job-advert-image.ts");
 const route=read("app/api/jobs/[id]/advertisement/route.ts");
 const detail=read("app/jobs/[slug]/page.tsx");
 assert.match(admin,/name="job_ad_image"/);
 assert.match(company,/name="job_ad_image"/);
 assert.match(helper,/record-documents/);
 assert.match(route,/job.verification_status!=="approved"/);
 assert.match(route,/createSignedUrl/);
 assert.match(detail,/Original approved job advertisement image/);
});

test("homepage job slider never displays mock expired or unapproved-sector jobs",()=>{
 const page=read("app/page.tsx");
 const slider=read("app/components/SectorJobSlider.tsx");
 const css=read("app/globals.css");
 assert.doesNotMatch(page,/jobs.map\(\(j\)/);
 assert.match(page,/approvedSectors.has/);
 assert.match(page,/job.deadline>=today/);
 assert.match(page,/<SectorJobSlider jobs=\{currentJobs\}/);
 assert.match(slider,/aria-pressed/);
 assert.match(css,/current-jobs-track/);
 assert.match(css,/@media \(max-width:640px\)/);
});


test("applicant eligibility permits direct CV submission without profile approval while retaining role restrictions",()=>{
 const page=read("app/jobs/[slug]/page.tsx");
 const actions=read("app/jobs/actions.ts");
 assert.match(page,/Job seeker account required/);
 assert.match(page,/Create job seeker account|Register a job seeker account/);
 assert.doesNotMatch(page,/profileApproved/);
 assert.match(page,/Upload a new CV with this application/);
 assert.match(page,/Application already submitted/);
 assert.match(page,/canApply && !hasApplied/);
 assert.match(page,/name="cv_choice"/);
 assert.match(actions,/This account cannot apply/);
 assert.match(actions,/inspectCvFile/);
 assert.match(actions,/owner_only/);
 assert.doesNotMatch(actions,/careerProfile\?\.verification_status !== "approved"/);
});

test("all CV uploads and job applications require an authenticated verified account email",()=>{
 const upload=read("app/dashboard/career/actions.ts");
 const uploadForm=read("app/dashboard/career/page.tsx");
 const apply=read("app/jobs/actions.ts");
 const detail=read("app/jobs/[slug]/page.tsx");
 const verify=read("lib/career-email-verification.ts");
 const company=read("app/dashboard/company/page.tsx");
 assert.match(upload,/matchingVerifiedAccountEmail/);
 assert.match(apply,/matchingVerifiedAccountEmail/);
 assert.match(uploadForm,/name="confirm_email"/);
 assert.match(detail,/name="confirm_email"/);
 assert.doesNotMatch(detail,/GuestJobApply/);
 assert.doesNotMatch(company,/guestApplicationRows/);
 assert.match(verify,/auth\.getUser\(\)/);
 assert.match(verify,/email_confirmed_at/);
 assert.match(verify,/user\.id!==expectedUserId/);
 assert.match(verify,/submitted===user\.email\.trim\(\)\.toLowerCase\(\)/);
 const guarded=read("supabase/migrations/20261023105536_guest_cv_login_only_lockdown.sql");
 assert.match(guarded,/revoke all on public\.guest_job_applications/);
 assert.match(guarded,/drop policy if exists guest_submitted_employer_read/);
});

test("CSV import removes incomplete jobs after region-area failures", async () => {
  // Execute the actual production rollback helper with fake persistence calls.
  const ts = await import("typescript");
  const vm = await import("node:vm");
  const compiled = ts.default.transpileModule(read("lib/job-import-cleanup.ts"), {
    compilerOptions: {
      module: ts.default.ModuleKind.CommonJS,
      target: ts.default.ScriptTarget.ES2022,
    },
  }).outputText;
  const sandboxModule = {exports: {}};
  vm.runInNewContext(compiled, {module: sandboxModule, exports: sandboxModule.exports, Error});
  const {persistImportedJobDetails} = sandboxModule.exports;

  const deleted = [];
  await assert.rejects(
    persistImportedJobDetails("job-1", async () => {
      throw new Error("company_region_areas insert failed");
    }, async (id) => {
      deleted.push(id);
      return true;
    }),
    /company_region_areas insert failed.*incomplete pending job was removed/i,
  );
  assert.deepEqual(deleted, ["job-1"]);

  await assert.rejects(
    persistImportedJobDetails("job-2", async () => {
      throw new Error("job_coverage_areas insert failed");
    }, async () => false),
    /job_coverage_areas insert failed.*manual review required/i,
  );
  await assert.rejects(
    persistImportedJobDetails("job-3", async () => {
      throw new Error("company_regions lookup failed");
    }, async () => {
      throw new Error("RLS denied cleanup");
    }),
    /company_regions lookup failed.*manual review required/i,
  );

  const saved = await persistImportedJobDetails("job-4", async () => ({id: "job-4"}), async () => {
    throw new Error("Cleanup must not run after success");
  });
  assert.equal(saved.id, "job-4");

  const bulk = read("app/admin/create/bulk-actions.ts");
  assert.match(bulk, /persistImportedJobDetails\(job\.id/);
  assert.match(bulk, /if\(readError\) throw readError/);
  assert.match(bulk, /if\(regionAreaError\) throw regionAreaError/);
  assert.match(bulk, /\.delete\(\)\.eq\("id",jobId\)\.select\("id"\)\.maybeSingle\(\)/);
});

test("Phase 2 dashboard links to actionable administration, reports and records", () => {
  const overview = read("app/admin/page.tsx");
  const reviews = read("app/admin/reviews/page.tsx");
  const nav = read("app/admin/components/AdminNav.tsx");
  const report = read("app/admin/reports/page.tsx");
  const exportRoute = read("app/admin/reports/export/route.ts");
  const company = read("app/dashboard/company/page.tsx");
  const account = read("app/dashboard/page.tsx");
  assert.match(overview, /getEffectiveAdminPermissions/);
  assert.match(overview, /Pending review records/);
  assert.match(overview, /New registrations/);
  assert.match(overview, /admin\/reviews#profile-account-/);
  assert.match(overview, /newRegistrations24h/);
  assert.match(overview, /24\*60\*60\*1000/);
  assert.match(reviews, /id=\{\`profile-\$\{row\.record_source/);
  assert.match(reviews, /id=\{\`credential-\$\{row\.record_source/);
  assert.match(reviews, /id=\{\`product-\$\{product.id\}/);
  assert.match(nav, /getEffectiveAdminPermissions/);
  assert.match(nav, /Reports \/ CSV/);
  assert.match(report, /PrintReportButton/);
  assert.match(exportRoute, /getEffectiveAdminPermission\(identity,"audit.view"\)/);
  assert.match(exportRoute, /no-store/);
  assert.match(exportRoute, /csvCell/);
  assert.match(company, /company-applications/);
  assert.match(account, /CareerWorkspaceFrame/);
  assert.match(account, /updateProfileAction/);
  for(const file of ["app/admin/jobs/page.tsx","app/admin/jobs/[id]/page.tsx","app/admin/applications/page.tsx","app/admin/clinic-affiliations/page.tsx","app/admin/reports/page.tsx"]){
    assert.ok(read(file).length>300, file+" is missing");
  }
});


test("organization connections distinguish clinic ownership, affiliations and company roles", () => {
  const connections = read("app/career/connections/page.tsx");
  const clinics = read("app/dashboard/clinics/page.tsx");
  const actions = read("app/dashboard/clinics/actions.ts");
  assert.match(connections, /\.from\('clinics'\)\.select\('id,slug,clinic_name,facility_type,city,verification_status,is_published'\)\.eq\('owner_id',identity\.userId\)/);
  assert.match(connections, /Clinics I own/);
  assert.match(connections, /My clinic affiliations/);
  assert.match(connections, /My company relationships/);
  assert.match(connections, /dashboard\/clinics#new-clinic/);
  assert.match(connections, /clinic\.is_published\?'Published':'Unpublished'/);
  assert.match(connections, /hasCompanyAccess&&approved/);
  assert.match(clinics, /id="new-clinic"/);
  assert.match(actions, /verification_status: "pending"/);
  assert.match(actions, /is_published: false/);
});


test("clinic onboarding stays linked to the personal dashboard and never self-publishes",()=>{
 const connections=read("app/career/connections/page.tsx");
 const clinic=read("app/dashboard/clinics/page.tsx");
 const detail=read("app/dashboard/clinics/[id]/page.tsx");
 const actions=read("app/dashboard/clinics/actions.ts");
 const admin=read("app/admin/actions.ts");
 const adminCreate=read("app/admin/create/actions.ts");
 const readiness=read("lib/clinic-practice-readiness.ts");
 assert.match(connections,/Clinics I own/);
 assert.match(clinic,/CareerWorkspaceFrame/);
 assert.match(detail,/CareerWorkspaceFrame/);
 assert.match(clinic,/responsible_veterinarian_pvmc/);
 assert.match(detail,/responsible_veterinarian_pvmc/);
 assert.match(actions,/responsible_veterinarian_pvmc: nullableText\(formData, "responsible_veterinarian_pvmc"\)/);
 assert.match(actions,/verification_status: "pending"/);
 assert.match(actions,/is_published: false/);
 assert.match(admin,/clinicPracticeReadiness/);
 assert.match(admin,/reviewerCheckedPVMC/);
 assert.match(admin,/gate.registration_intent==="clinic"/);
 const adminReview=read("app/admin/reviews/page.tsx");
 assert.match(adminReview,/name="pvmc_checked"/);
 assert.match(admin,/registration_intent==="clinic"/);
 assert.match(adminCreate,/const publish = false/);
 assert.match(readiness,/At least one open day/);
 assert.match(readiness,/At least one active public clinical service/);
});


test("registration approval never publishes clinical practice without separate PVMC review",()=>{
  const migration=read("supabase/migrations/20261101162000_separate_clinic_publication_from_registration.sql");
  const admin=read("app/admin/actions.ts");
  const reviews=read("app/admin/reviews/page.tsx");
  const first="if gate_row.registration_intent = 'clinic' then";
  const start=migration.lastIndexOf(first);
  const end=migration.indexOf("elsif account_role_value = 'laboratory'",start);
  assert.ok(start>0 && end>start);
  const clinicRegistration=migration.slice(start,end);
  assert.match(clinicRegistration,/is_published = false/);
  assert.match(clinicRegistration,/then 'pending'::public.approval_status/);
  assert.doesNotMatch(clinicRegistration,/is_published = p_decision='approved'/);
  assert.match(migration,/enforce_clinic_publication_readiness/);
  assert.match(migration,/pvmc_reviewed_by/);
  assert.match(migration,/pvmc_review_note/);
  assert.match(migration,/clinic_availability/);
  assert.match(migration,/clinic_services/);
  assert.match(admin,/pvmc_review_note: decision === "approved" \? reason : null/);
  assert.match(admin,/select\("id"\)\.single\(\)/);
  assert.doesNotMatch(admin,/Clinic registration requires manual PVMC evidence confirmation and a review note/);
  assert.match(reviews,/its clinic stays private and pending/i);
});


test("account, professional, clinic and company use one navigation shell with separate review states",()=>{
 const nav=read("lib/professional-workspace.ts");
 const frame=read("app/components/CareerWorkspaceFrame.tsx");
 const account=read("app/dashboard/page.tsx");
 const profile=read("app/dashboard/professional/ProfileBuilder.tsx");
 const clinic=read("app/dashboard/clinics/page.tsx");
 const clinicDetail=read("app/dashboard/clinics/[id]/page.tsx");
 const company=read("app/dashboard/company/page.tsx");
 const admin=read("app/admin/components/AdminNav.tsx");
 assert.match(nav,/id:'account'/);
 assert.match(nav,/id:'clinic'/);
 assert.match(nav,/id:'company'/);
 assert.match(frame,/data-module=\{module\}/);
 assert.match(frame,/PVMC number provided · verification pending/);
 assert.match(frame,/credentialReviewed/);
 assert.match(account,/active="account" module="account"/);
 assert.match(account,/className="vcx-account-details"/);
 assert.match(account,/updateProfileAction/);
 assert.doesNotMatch(account, /dashboard-hero-row/);
 assert.match(clinic,/active="clinic" module="clinic"/);
 assert.match(clinicDetail,/active="clinic" module="clinic"/);
 assert.match(company,/active="company" module="company"/);
 assert.doesNotMatch(company, /<SiteHeader/);
 assert.doesNotMatch(profile, /of checklist saved/);
 assert.match(admin,/vc-admin-section/);
 assert.match(read("docs/unified-workspace-design-system.md"),/Clinic publication database-migration/);
});


test("clinic practice types, Other options and specialty labels reuse both clinic forms",()=>{
 const types=read("lib/clinic-facility-options.ts");
 const selector=read("app/dashboard/clinics/ClinicFacilityTypeField.tsx");
 const focus=read("app/dashboard/clinics/ClinicFocusFields.tsx");
 const list=read("app/dashboard/clinics/page.tsx");
 const detail=read("app/dashboard/clinics/[id]/page.tsx");
 const actions=read("app/dashboard/clinics/actions.ts");
 assert.match(types,/Poultry Veterinary Clinic/);
 assert.match(types,/Poultry Farm Veterinary Service/);
 assert.match(types,/Poultry Veterinary Consultancy/);
 assert.match(types,/Cat \/ Feline Clinic/);
 assert.match(types,/Other/);
 assert.match(selector,/value="Other"/);
 assert.match(selector,/required maxLength=\{90\}/);
 assert.match(focus,/kind\+"_selected"/);
 assert.match(focus,/ANIMAL_GROUPS\.map/);
 assert.match(list,/<ClinicFacilityTypeField \/>/);
 assert.match(list,/<ClinicFocusFields \/>/);
 assert.match(detail,/<ClinicFacilityTypeField defaultValue=\{clinic.facility_type\} \/>/);
 assert.match(detail,/<ClinicFocusFields services=\{clinic.services\} species=\{clinic.species\}\/>/);
 assert.match(list,/Weekly hours & appointment slots/);
 assert.doesNotMatch(list,/value="Set after clinic creation"/);
 assert.match(actions,/resolveClinicFacilityType\(formData\)/);
 assert.match(actions,/clinicFocusEntries\(formData,"services"\)/);
 assert.match(actions,/clinicFocusEntries\(formData,"species"\)/);
 assert.match(actions,/Enter a valid fee range and a duration between 1 and 1440 minutes/);
 assert.match(actions,/is_published: false/);
});


test("admin home visibly shows status counts across real sectors and permission-gated queues",()=>{
 const overview=read("app/admin/page.tsx");
 const nav=read("app/admin/components/AdminNav.tsx");
 const css=read("app/globals.css");
 const spec=read("docs/admin-control-v2-canonical-data-plan.md");
 assert.match(overview,/Registrations, approvals and new activity/);
 assert.match(overview,/sectorRows\.map\(row=>/);
 assert.match(overview,/Approved/);
 assert.match(overview,/Pending/);
 assert.match(overview,/Rejected/);
 assert.match(overview,/New 24h/);
 assert.match(overview,/newRegistrations24h/);
 assert.match(overview,/candidateAccounts/);
 assert.match(overview,/registrationPending/);
 assert.match(overview,/registration_completion_gate/);
 assert.match(overview,/last 24 hours/i);
 assert.match(overview,/cards\.filter\(card=>card\.attention\)/);
 assert.ok(overview.indexOf("Registrations, approvals and new activity") < overview.indexOf("Approval and review queues"));
 assert.ok(overview.indexOf("Approval and review queues") < overview.indexOf("Latest updates and decisions"));
 assert.doesNotMatch(overview,/vc-admin-overview-details/);
 assert.doesNotMatch(overview,/Operations & quick actions/);
 for(const category of ["Registrations & people","Clinics & diagnostics","Marketplace & companies","Jobs & HR","Approvals","Governance & data"]){
   assert.ok(nav.includes('title:"'+category+'"'),category+" navigation group");
 }
 assert.match(nav,/visibleGroups/);
 assert.doesNotMatch(nav,/\/admin\/review-history/);
 assert.match(nav,/Veterinarian PVMC checks/);
 assert.doesNotMatch(nav,/title:"PVMC"/);
 assert.match(css,/\.vc-admin-page \.vc-admin-layout\{display:grid/);
 assert.match(css,/\.vc-admin-page \.vc-admin-sector-grid\{display:grid/);
 assert.match(css,/max-width:520px/);
 assert.match(spec,/UAF → University of Agriculture Faisalabad/);
 assert.match(spec,/UVAS → University of Veterinary and Animal Sciences Lahore/);
 assert.match(spec,/CSV\/PDF are outputs/);
});

test("profile step navigation and visible form stay in sync without an extra scroll bar",()=>{
 const stepper=read("app/dashboard/professional/ProfileBuilder.tsx");
 const page=read("app/dashboard/professional/page.tsx");
 const frame=read("app/components/CareerWorkspaceFrame.css");
 assert.match(stepper,/setActive\(index\)/);
 assert.match(stepper,/stepIndex\(initialStep\)/);
 assert.match(stepper,/window\.addEventListener\('popstate',syncFromUrl\)/);
 assert.match(stepper,/aria-selected=\{active===index\}/);
 assert.match(stepper,/hidden=\{active!==index\}/);
 assert.match(stepper,/Select profile section/);
 assert.match(stepper,/Next: \{steps\[active\+1\]\.label\}/);
 assert.match(frame,/\.vcx-primary \.builder-step-list\{\s*display:grid;grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
 assert.match(frame,/\.vcx-primary \.builder-step-list\{display:none\}/);
 assert.match(frame,/\.vcx-primary \.builder-mobile-selector\{display:grid/);
 assert.match(page,/Your current photograph is shown in the profile card above/);
 assert.doesNotMatch(page,/<ProfilePhoto\s/);
 assert.doesNotMatch(page,/\{completion\}% core profile/);
});


test("CV and applications avoid repeat navigation and CV-library overload",()=>{
 const frame=read("app/components/CareerWorkspaceFrame.tsx");
 const apps=read("app/dashboard/career/page.tsx");
 const css=read("app/components/CareerWorkspaceFrame.css");
 assert.match(frame,/personalWorkspace&&active!=='cv'/);
 assert.match(apps,/<details className="backend-form-card career-cv-library vcx-collapsible-library"/);
 assert.match(apps,/open=\{\(cvDocumentsResult\.data\?\?\[\]\)\.length===0\}/);
 assert.match(apps,/<summary>/);
 assert.match(apps,/<\/details>/);
 assert.match(css,/\.vcx-primary \.vcx-collapsible-library/);
});

test("clinic booking degrades safely only when the optional date-exception table is missing", () => {
  const booking = read("app/clinics/actions.ts");
  assert.match(booking, /exceptionTableUnavailable/);
  assert.match(booking, /PGRST205/);
  assert.match(booking, /42P01/);
  assert.match(booking, /exceptionError\.message\?\.includes\("clinic_schedule_exceptions"\)/);
  assert.match(booking, /exceptionError && !exceptionTableUnavailable/);
  assert.match(booking, /exception \|\| exceptionTableUnavailable/);
  assert.match(booking, /clinic_availability/);
  assert.match(booking, /clinic_appointment_requests/);
});

test("clinic booking rejects impossible calendar dates and expired same-day appointments", () => {
  const booking = read("app/clinics/actions.ts");
  assert.match(booking, /isCalendarDate/);
  assert.match(booking, /date\.toISOString\(\)\.slice\(0, 10\) !== preferredDate/);
  assert.match(booking, /preferredDate === pakistanToday\(\)/);
  assert.match(booking, /timeZone: "Asia\/Karachi"/);
  assert.match(booking, /requestedMinutes <= hours \* 60 \+ minutes/);
  assert.match(booking, /Choose a future appointment time for today/);
});

 test("master admin has one account workspace and exposes secondary roles",()=>{
 const nav=read("app/admin/components/AdminNav.tsx");
 const users=read("app/admin/users/page.tsx");
 assert.equal((nav.match(/href:"\/admin\/users"/g)??[]).length,1);
 assert.match(users,/aria-label="Account categories"/);
 assert.match(users,/roleMap.get\(user.id\)/);
 assert.match(users,/rolesError/);
 });
