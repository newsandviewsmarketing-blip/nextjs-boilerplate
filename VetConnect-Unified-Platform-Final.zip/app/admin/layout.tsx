import type {Metadata} from "next";
import Link from "next/link";
import {getCurrentIdentity} from "@/lib/auth";
import {getEffectiveAdminPermission} from "@/lib/admin";
import {signOutAction,switchAccountAction} from "@/app/auth/actions";
import WorkspaceClock from "@/app/components/WorkspaceClock";
export const metadata:Metadata={robots:{index:false,follow:false}};
export default async function PrivateWorkspaceLayout({children}:{children:React.ReactNode}){
 const identity=await getCurrentIdentity();
 const allowed=identity&&await getEffectiveAdminPermission(identity,"admin.view");
 return <div className="vc-unified-admin">{allowed&&identity&&<header className="vc-unified-admin-bar"><Link href="/admin" className="vc-unified-brand">VetConnect Admin</Link><WorkspaceClock/><details className="vc-unified-admin-account"><summary>My account ▾</summary><div className="vc-unified-admin-menu"><strong>{identity.profile?.full_name||"My account"}</strong><span>{identity.email||"Email unavailable"}</span><small>{identity.roles.map(role=>role.replaceAll("_"," ")).join(" · ")}</small><Link href="/admin">Admin dashboard</Link><Link href="/dashboard">My VetConnect</Link><Link href="/">Visit public website</Link><form action={switchAccountAction}><button type="submit">Switch account</button></form><form action={signOutAction}><button type="submit">Sign out</button></form></div></details></header>}{children}</div>;
}
