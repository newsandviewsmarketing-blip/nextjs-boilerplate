"use client";
import {useSyncExternalStore} from "react";
const subscribe=(notify:()=>void)=>{const timer=setInterval(notify,1000);return()=>clearInterval(timer);};
const snapshot=()=>Math.floor(Date.now()/1000)*1000;
const serverSnapshot=()=>0;
const clock=new Intl.DateTimeFormat("en-PK",{timeZone:"Asia/Karachi",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true});
const date=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Karachi",weekday:"short",day:"numeric",month:"short",year:"numeric"});
export default function WorkspaceClock(){
 const now=useSyncExternalStore(subscribe,snapshot,serverSnapshot);
 return <div className="vc-unified-clock" aria-label="Pakistan Standard Time"><time dateTime={now?new Date(now).toISOString():undefined}>{now?clock.format(now):"—"} PKT</time><small>{now?date.format(now):"Pakistan Standard Time"}</small></div>;
}
