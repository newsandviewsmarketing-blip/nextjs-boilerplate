import type {ReactNode} from 'react';
import Link from 'next/link';
import Image from 'next/image';
import ProfilePhoto from '@/app/components/ProfilePhoto';
import {getCoreProfileProgress} from '@/lib/professional-progress';
import {getCurrentIdentity} from '@/lib/auth';
import {createClient} from '@/lib/supabase/server';
import {getEffectiveAdminPermission} from '@/lib/admin';
import {workspaceCapabilities} from '@/lib/workspace-navigation';
import {WORKSPACE_LINKS} from '@/lib/professional-workspace';
import {signOutAction, switchAccountAction} from '@/app/auth/actions';
import WorkspaceClock from './WorkspaceClock';
import './CareerWorkspaceFrame.css';

type WorkspaceId=(typeof WORKSPACE_LINKS)[number]['id'];
type Check={label:string;done:boolean;optional?:boolean};
type Props={
 active:WorkspaceId;
 module?:'career'|'account'|'clinic'|'company'|'laboratory';
 name:string;
 headline?:string|null;
 location?:string|null;
 photoUrl?:string|null;
 approved?:boolean;
 verificationStatus?:string|null;
 cvStatus?:'saved'|'draft'|'missing';
 emailAlerts?:boolean;
 checklist?:Check[];
 title:string;
 description:string;
 children:ReactNode;
};

const SYMBOLS:Record<WorkspaceId,string>={
 overview:'▦',account:'⚙',profile:'◉',cv:'▤',preferences:'⌖',
 letter:'✉',connections:'◇',clinic:'✚',company:'▣',laboratory:'⚗',applications:'☷',
};
function profileReview(status?:string|null, practitioner=false){
 if(!practitioner)return 'Professional profile · self-managed';
 if(status==='approved')return 'Profile reviewed · PVMC credential status separate';
 if(status==='rejected')return 'Credential review needs attention';
 return 'Practitioner credential review separate';
}
export default async function CareerWorkspaceFrame({
 active,module='career',name,headline,location,photoUrl,approved=false,verificationStatus,
 cvStatus,emailAlerts,title,description,children
}:Props){
 const current=WORKSPACE_LINKS.find(link=>link.id===active);
 const identity=await getCurrentIdentity();
 const roles=identity?.roles??[];
 // Approved company membership can belong to a veterinarian or other professional.
 // The RPC scopes results to the current identity; never infer access from a label.
 const supabase=identity ? await createClient() : null;
 const [companyMembership,canOpenAdmin]=await Promise.all([
   supabase ? supabase.rpc('get_my_company_workspaces') : Promise.resolve(null),
   identity ? getEffectiveAdminPermission(identity,'admin.view') : Promise.resolve(false),
 ]);
 const capabilities=workspaceCapabilities(roles, !companyMembership?.error && Boolean(companyMembership?.data?.length));
 const personalWorkspace=capabilities.professional && module!=='company' && module!=='clinic' && module!=='laboratory';
 // Navigation visibility is only presentation; each destination retains its own
 // server-side authorization and ownership rules.
 const menu=WORKSPACE_LINKS.filter(link=>{
  if(link.id==='clinic')return capabilities.clinic;
  if(link.id==='company')return capabilities.company || active==='company';
  if(link.id==='laboratory')return capabilities.laboratory;
  if(['overview','profile','cv','letter','preferences','connections','applications'].includes(link.id))return capabilities.professional || link.id===active;
  return true;
 });
 const isVeterinaryPractitioner=roles.includes('veterinarian');
 const credential=isVeterinaryPractitioner&&identity
   ? await (await createClient()).from('veterinarian_profiles')
     .select('pvmc_number,pvmc_verification_status').eq('user_id',identity.userId).maybeSingle()
   : null;
 const hasPvmcNumber=Boolean(credential?.data?.pvmc_number?.trim());
 const credentialReviewed=credential?.data?.pvmc_verification_status==='approved';
 // Ignore older route-specific checklists: use one shared core-progress calculation.
 const sharedProgress=personalWorkspace ? await getCoreProfileProgress() : null;
 const completion=sharedProgress?.percent??null;
 const coreChecks=sharedProgress?.checks;
 const navigation=(mobile:boolean)=><nav className="vcx-navigation" aria-label={mobile?'Mobile workspace tools':'Workspace tools'}>
  {menu.filter(link=>approved||!link.requiresApproval||link.id===active).map(link=><Link
    key={link.id} href={link.href} aria-current={link.id===active?'page':undefined}
    className={link.id===active?'vcx-nav-link is-active':'vcx-nav-link'}>
    <span className="vcx-nav-symbol" aria-hidden="true">{SYMBOLS[link.id]}</span>
    <span>{link.label}</span>
  </Link>)}
 </nav>;
 const fallback=name.trim().split(/\s+/).slice(0,2).map(word=>word[0]?.toUpperCase()).join('')||'VC';
 return <main className="vcx-app" data-module={module}>
  <aside className="vcx-sidebar">
   <Link className="vcx-brand" href="/" aria-label="VetConnect public website"><Image src="/vetconnect-logo.png" alt="VetConnect" width={155} height={50} unoptimized/></Link>
   <span className="vcx-sidebar-eyebrow">{module==='company'?'ORGANIZATION WORKSPACE':'MY WORKSPACE'}</span>
   {navigation(false)}
   <div className="vcx-sidebar-foot">
    <b>One profile. Many opportunities.</b>
    <p>Manage your career, documents and company connections under your own identity.</p>
    <Link href="/dashboard">Account settings</Link>
    {canOpenAdmin&&<Link href="/admin">Admin control centre</Link>}
   </div>
  </aside>
  <div className="vcx-workspace">
   <header className="vcx-topbar">
    <details className="vcx-mobile-menu">
     <summary>☰ <span>Workspace menu</span></summary>
     {navigation(true)}
    </details>
    <div className="vcx-breadcrumb">My VetConnect <span aria-hidden="true">/</span> <b>{current?.label??'Workspace'}</b></div>
    <WorkspaceClock/><div className="vcx-top-actions">{canOpenAdmin&&<Link href="/admin">Admin</Link>}<Link href="/dashboard">Account</Link><Link href="/">Visit VetConnect</Link>{identity?<details className="vcx-account-menu"><summary aria-label="Open account menu"><span className="vcx-user-mark">{fallback}</span><span className="vcx-account-caption">My account ▾</span></summary><div className="vcx-account-popover"><strong>{identity.profile?.full_name||'My account'}</strong><span className="vcx-account-email">{identity.email||'Email unavailable'}</span><small>{roles.map(role=>role.replaceAll('_',' ')).join(' · ')||'Member'}</small><hr/><Link href="/dashboard">My dashboard</Link>{capabilities.professional&&<Link href="/dashboard/professional">My profile</Link>}{capabilities.clinic&&<Link href="/dashboard/clinics">Clinics and appointments</Link>}{capabilities.company&&<Link href="/dashboard/company">Company and products</Link>}{capabilities.laboratory&&<Link href="/dashboard/laboratory">Laboratory workspace</Link>}{roles.includes('veterinarian')&&<Link href="/dashboard/consultation">Consultation settings</Link>}{process.env.CONSULTATION_CALLS_TEST_MODE==='true'&&<Link href="/dashboard/consultation/history">Consultation history</Link>}{canOpenAdmin&&<Link href="/admin">Admin control centre</Link>}<hr/><form action={switchAccountAction}><button type="submit">Switch account</button></form><form action={signOutAction}><button type="submit">Sign out</button></form></div></details>:<Link href="/login">Sign in</Link>}</div>
   </header>
   <div className="vcx-content">
    <div className="vcx-intro">
     <div><span className="vcx-eyebrow">{module==='clinic'?'VETERINARY PRACTICE':module==='company'?'COMPANY WORKSPACE':module==='laboratory'?'LABORATORY WORKSPACE':module==='account'?'ACCOUNT & IDENTITY':'PROFESSIONAL WORKSPACE'}</span><h1>{title}</h1><p>{description}</p></div>
    {active==='overview'&&<Link className="vcx-button vcx-button-outline" href={cvStatus==='saved'?'/career/cv/print':'/career/cv'} target={cvStatus==='saved'?'_blank':undefined} rel={cvStatus==='saved'?'noopener noreferrer':undefined}>{cvStatus==='saved'?'View saved CV':'Create my CV'}</Link>}
    </div>
    <article className="vcx-identity-card">
     <div className="vcx-portrait-frame"><ProfilePhoto imageUrl={photoUrl??null} name={name} fallback={fallback}/></div>
     <div className="vcx-identity-main">
      <span className="vcx-eyebrow">{module==='company'||module==='laboratory'?'CURRENT ORGANIZATION':'YOUR PERSONAL PROFILE'}</span>
      <h2>{name||'My professional profile'}</h2>
      <p>{headline||'Veterinary & animal-health professional'}</p>
      {location&&<p>{location}</p>}
      <div className="vcx-pills"><span>{module==='company'||module==='laboratory'?`Organization review: ${verificationStatus??'pending'}`:capabilities.professional?profileReview(verificationStatus,isVeterinaryPractitioner):'Account access · assigned roles'}</span>
       {hasPvmcNumber&&<span className="vcx-credential-tag">{credentialReviewed?'PVMC credential reviewed':'PVMC number provided · verification pending'}</span>}
       {cvStatus&&<span>{cvStatus==='saved'?'CV details saved':cvStatus==='draft'?'CV draft started':'CV not saved yet'}</span>}
       {emailAlerts!==undefined&&<span>Job emails {emailAlerts?'on':'off'}</span>}
      </div>
      {capabilities.professional&&module!=='company'&&module!=='laboratory'&&<Link className="vcx-photo-link" href="/dashboard/professional?step=photo">Edit my profile photo</Link>}
     </div>
     {personalWorkspace&&completion!==null&&<div className="vcx-identity-progress">
      <strong>{completion}%</strong><small>Core profile information</small>
      <progress value={completion} max={100} aria-label="Core profile information completion"/>
     </div>}
    </article>
    <div className="vcx-content-grid">
     <div className="vcx-primary">{children}</div>
     <aside className="vcx-right-rail" aria-label="Workspace summary">
      {personalWorkspace&&<section className="vcx-side-card">
       <span className="vcx-eyebrow">YOUR PROGRESS</span><h2>Core profile checklist</h2>
       {coreChecks&&coreChecks.length?<ul className="vcx-checklist">{coreChecks.map(item=><li key={item.label}>
         <span className={item.done?'vcx-check is-done':'vcx-check'} aria-hidden="true">{item.done?'✓':'○'}</span>
         {item.label}
       </li>)}</ul>:<p className="vcx-secondary">Complete your details at your own pace. Verification is a separate review.</p>}
       <p className="vcx-secondary">Optional photos, CVs, credentials, and job interests do not affect core progress. This is not a verification score.</p>
      </section>}
      {isVeterinaryPractitioner&&module!=='company'&&<section className="vcx-side-card">
       <span className="vcx-eyebrow">VETERINARY CREDENTIAL</span>
       <h2>PVMC registration check</h2>
       <p className="vcx-secondary">Your CV and profile can be saved without PVMC approval. Licensed veterinary practice requires separate credential verification. VetConnect does not automatically verify the PVMC registry.</p>
       <a href="https://pvmc.gov.pk/Registration/Search" target="_blank" rel="noopener noreferrer" className="vcx-button vcx-button-outline">Check the official PVMC register</a>
      </section>}
      {module==='laboratory'?<section className="vcx-side-card">
       <span className="vcx-eyebrow">LABORATORY OPERATIONS</span><h2>Tests and enquiries</h2>
       <p className="vcx-secondary">Manage test-information requests and keep your facility details current.</p>
       <Link className="vcx-button vcx-button-outline" href="/dashboard">Account and facility details</Link>
      </section>:module==='clinic'?<section className="vcx-side-card">
       <span className="vcx-eyebrow">CLINIC PRACTICE</span><h2>Clinic operations</h2>
       <p className="vcx-secondary">Clinic publication requires a separate VetConnect facility review. A saved or completed personal profile is not a clinic approval.</p>
       <Link className="vcx-button vcx-button-outline" href="/dashboard/clinics">Manage my clinics</Link>
      </section>:module==='company'?<section className="vcx-side-card">
       <span className="vcx-eyebrow">SEPARATE IDENTITY</span><h2>Company workspace</h2>
       <p className="vcx-secondary">Company records and permissions remain separate from this user&apos;s professional CV and personal account.</p>
       {capabilities.professional&&<Link className="vcx-button vcx-button-outline" href="/career/connections">Professional connections</Link>}
      </section>:personalWorkspace&&active!=='cv'?<section className="vcx-side-card">
       <span className="vcx-eyebrow">YOUR CV</span><h2>VetConnect CV Builder</h2>
       <div className="vcx-tiny-cv" aria-hidden="true"><div><b>VETCONNECT</b><small>PROFESSIONAL CV</small></div><i/><i/><i/><i/><i/></div>
       <Link className="vcx-button vcx-button-outline" href="/career/cv">Create or edit CV</Link>
      </section>:<section className="vcx-side-card"><h2>My account</h2><p className="vcx-secondary">Use the tools available for your account and assigned responsibilities.</p>{canOpenAdmin&&<Link className="vcx-button vcx-button-outline" href="/admin">Open admin control centre</Link>}</section>}
     </aside>
    </div>
    <p className="vcx-privacy-note"><Link href="/about">About VetConnect</Link> · <Link href="/terms">Terms</Link> · <Link href="/privacy">Privacy</Link>. A personal profile and a company or clinic are separate records. Qualifications and employment require their own verification. Your private CV is shared only when you choose to use it in an application.</p>
   </div>
  </div>
 </main>;
}
