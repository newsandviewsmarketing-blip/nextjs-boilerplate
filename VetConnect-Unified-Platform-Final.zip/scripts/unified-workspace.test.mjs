import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('clock uses PKT and cleans up subscription',()=>{const s=read('app/components/WorkspaceClock.tsx');assert.match(s,/Asia\/Karachi/);assert.match(s,/clearInterval/);assert.match(s,/useSyncExternalStore/);});
test('member and admin share clock',()=>{for(const p of ['app/admin/layout.tsx','app/components/CareerWorkspaceFrame.tsx'])assert.match(read(p),/<WorkspaceClock\/>/);});
test('admin header uses effective permission and secure actions',()=>{const s=read('app/admin/layout.tsx');assert.match(s,/getEffectiveAdminPermission\(identity,"admin.view"\)/);assert.match(s,/allowed&&identity/);assert.match(s,/action=\{switchAccountAction\}/);assert.match(s,/action=\{signOutAction\}/);});
test('clinic summary does not bypass approval',()=>{const s=read('app/admin/directory/[kind]/[id]/page.tsx');assert.match(s,/Submitted credentials are not proof/);assert.match(s,/canReview&&<Link/);assert.match(s,/reviewProfileAction/);});
