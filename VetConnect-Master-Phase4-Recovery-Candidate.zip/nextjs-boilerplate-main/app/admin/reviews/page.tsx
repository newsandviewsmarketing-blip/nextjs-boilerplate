import { redirect } from "next/navigation";
import SiteHeader from "../../components/SiteHeader";
import SiteFooter from "../../components/SiteFooter";
import FormMessage from "../../components/FormMessage";
import FormSubmitButton from "../../components/FormSubmitButton";
import AdminNav from "../components/AdminNav";
import PrintReviewButton from "./PrintReviewButton";
import ReviewDocumentsPanel from "./ReviewDocumentsPanel";
import ReviewWorkspaceTabs from "./ReviewWorkspaceTabs";
import "./review-workspace.css";
import {
  reviewProductAction,
  reviewProfileAction,
  reviewVeterinarianCredentialAction,
  reviewJobAction,
  reviewProductRegulatoryAction,
  reviewRegistrationSubmissionAction,
} from "../actions";
import { getCurrentIdentity } from "@/lib/auth";
import { getEffectiveAdminPermissions } from "@/lib/admin";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";

export const dynamic = "force-dynamic";

type PendingRow = Record<string, unknown> & { user_id: string; entity_id?: string; record_source?: string };
type PendingDisplayRow = PendingRow & {
  profile_type: "veterinarian" | "company" | "professional" | "laboratory" | "clinic";
};
type PendingProduct = {
  id: string;
  company_user_id: string | null;
  company_id: string | null;
  product_name: string;
  brand_name: string | null;
  generic_name: string | null;
  category: string;
  sector: string | null;
  description: string | null;
  created_at: string;
};
type PendingJob = {
  id: string;
  company_user_id: string | null;
  company_id: string | null;
  title: string;
  description: string;
  sector: string | null;
  city: string | null;
  employment_type: string;
  minimum_qualification: string | null;
  minimum_experience: number | null;
  deadline: string | null;
};
type PendingRegulatory = {
  product_id: string;
  registration_number: string | null;
  registration_status: string | null;
  applicability: string | null;
};

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; message?: string }>;
}) {
  const params = await searchParams;
  if (!isSupabaseConfigured()) redirect("/dashboard");
  const identity = await getCurrentIdentity();
  if (!identity) redirect("/login?next=/admin");
  const effectivePermissions = await getEffectiveAdminPermissions(identity);
  if (
    !effectivePermissions.has("profiles.review") &&
    !effectivePermissions.has("products.manage") &&
    !effectivePermissions.has("jobs.manage") &&
    !effectivePermissions.has("regulatory.review")
  )
    redirect("/dashboard?error=Admin%20access%20is%20required.");

  const supabase = await createClient();
  const canReviewProfiles = effectivePermissions.has("profiles.review");
  const { data: registrationRows } = canReviewProfiles
    ? await supabase.from("registration_completion_gate").select("user_id,registration_intent,student_track,submitted_at,review_status").eq("review_status","pending").order("submitted_at")
    : { data: [] };
  const registrationIds=(registrationRows??[]).map(row=>row.user_id);
  const [{data:registrationProfiles},{data:registrationEvidence},{data:registrationDetailRows}] = registrationIds.length ? await Promise.all([
    supabase.from("profiles").select("id,full_name,email,primary_role,city,province").in("id",registrationIds),
    supabase.from("registration_evidence").select("user_id,document_type,original_filename,storage_path,content_type,verification_status,created_at").in("user_id",registrationIds).order("created_at",{ascending:false}),
    supabase.from("registration_profile_details").select("user_id,category_details").in("user_id",registrationIds),
  ]) : [{data:[]},{data:[]},{data:[]}];
  const registrationEvidenceWithUrls=await Promise.all((registrationEvidence??[]).map(async doc=>{
    const {data}=await supabase.storage.from("registration-evidence").createSignedUrl(doc.storage_path,900);
    return {...doc,signed_url:data?.signedUrl??null};
  }));
  const registrationProfileMap=new Map((registrationProfiles??[]).map(p=>[p.id,p]));
  const registrationDetailMap=new Map((registrationDetailRows??[]).map(row=>[row.user_id,row.category_details as Record<string,unknown>]));
  const registrationDocsMap=new Map<string,typeof registrationEvidenceWithUrls>();
  for(const doc of registrationEvidenceWithUrls){const list=registrationDocsMap.get(doc.user_id)??[];list.push(doc);registrationDocsMap.set(doc.user_id,list);}
  const [{ data: vets }, { data: credentialVets }, { data: companies }, { data: professionals }, { data: laboratories }, { data: products }, { data: jobs }] = await Promise.all([
    supabase
      .from("veterinarian_profiles")
      .select("*")
      .eq("verification_status", "pending")
      .order("created_at"),
    supabase
      .from("veterinarian_profiles")
      .select("user_id, pvmc_number, qualifications, specialization, city, pvmc_verification_status")
      .eq("verification_status", "approved")
      .eq("pvmc_verification_status", "pending")
      .order("created_at"),
    supabase
      .from("company_profiles")
      .select("*")
      .eq("verification_status", "pending")
      .order("created_at"),
    supabase
      .from("professional_profiles")
      .select("*")
      .eq("verification_status", "pending")
      .order("created_at"),
    supabase
      .from("laboratories")
      .select("*")
      .eq("verification_status", "pending")
      .order("created_at"),
    supabase
      .from("products")
      .select("id, company_user_id, company_id, product_name, brand_name, generic_name, category, sector, description, created_at")
      .eq("verification_status", "pending")
      .order("created_at"),
    supabase
      .from("jobs")
      .select("id, company_user_id, company_id, title, description, sector, city, employment_type, minimum_qualification, minimum_experience, deadline")
      .eq("verification_status", "pending")
      .order("created_at"),
  ]);
  const [{ data: managedPeople }, { data: canonicalCompanies }, { data: clinics }, { data: managedCredentialVets }] = await Promise.all([
    supabase.from("managed_people").select("*").eq("verification_status", "pending").order("created_at"),
    supabase.from("companies").select("*").is("legacy_company_user_id", null).eq("verification_status", "pending").eq("record_status", "active").order("created_at"),
    supabase.from("clinics").select("*").eq("verification_status", "pending").order("created_at"),
    supabase.from("managed_people").select("id,full_name,pvmc_number,qualifications,specialization,city,pvmc_verification_status").eq("profile_kind", "veterinarian").eq("verification_status", "approved").eq("pvmc_verification_status", "pending").order("created_at"),
  ]);

  const credentialRows: PendingRow[] = [
    ...((credentialVets ?? []) as PendingRow[]).map((row) => ({ ...row, record_source: "account" })),
    ...((managedCredentialVets ?? []) as Array<Record<string, unknown> & { id: string }>).map((row) => ({
      ...row,
      user_id: row.id,
      entity_id: row.id,
      record_source: "managed_people",
    })),
  ];

  const pending: PendingDisplayRow[] = [
    ...((vets ?? []) as PendingRow[]).map((row) => ({ ...row, profile_type: "veterinarian" as const, record_source: "account" })),
    ...((companies ?? []) as PendingRow[]).map((row) => ({ ...row, profile_type: "company" as const, record_source: "account" })),
    ...((professionals ?? []) as PendingRow[]).map((row) => ({ ...row, profile_type: "professional" as const, record_source: "account" })),
    ...((laboratories ?? []) as Array<Record<string, unknown> & { id: string; owner_id: string | null }>).map((row) => ({
      ...row, user_id: row.owner_id ?? row.id, entity_id: row.id, profile_type: "laboratory" as const, record_source: "laboratories",
    })),
    ...((managedPeople ?? []) as Array<Record<string, unknown> & { id: string; profile_kind: string }>).map((row) => ({
      ...row, user_id: row.id, entity_id: row.id, profile_type: row.profile_kind === "veterinarian" ? "veterinarian" as const : "professional" as const, record_source: "managed_people",
    })),
    ...((canonicalCompanies ?? []) as Array<Record<string, unknown> & { id: string }>).map((row) => ({
      ...row, user_id: row.id, entity_id: row.id, company_name: row.canonical_name, profile_type: "company" as const, record_source: "companies",
    })),
    ...((clinics ?? []) as Array<Record<string, unknown> & { id: string }>).map((row) => ({
      ...row, user_id: row.id, entity_id: row.id, profile_type: "clinic" as const, record_source: "clinics",
    })),
  ].filter(row => row.record_source !== "account" || !registrationIds.includes(row.user_id));
  const ids = [...new Set([
    ...pending.filter((row) => row.record_source === "account").map((row) => row.user_id),
    ...credentialRows.filter((row) => row.record_source === "account").map((row) => row.user_id),
  ])];
  // Legacy account-level pending profiles may have evidence even without a pending registration gate.
  const outstandingEvidenceIds = ids.filter(id => !registrationDocsMap.has(id));
  const {data:otherEvidence} = canReviewProfiles && outstandingEvidenceIds.length
    ? await supabase.from("registration_evidence")
        .select("user_id,document_type,original_filename,storage_path,content_type,verification_status,created_at")
        .in("user_id",outstandingEvidenceIds).order("created_at",{ascending:false})
    : {data:[]};
  for (const doc of otherEvidence ?? []) {
    const {data} = await supabase.storage.from("registration-evidence").createSignedUrl(doc.storage_path,900);
    const list = registrationDocsMap.get(doc.user_id) ?? [];
    list.push({...doc,signed_url:data?.signedUrl??null});
    registrationDocsMap.set(doc.user_id,list);
  }
  const { data: profiles } = ids.length
    ? await supabase
        .from("profiles")
        .select("id, full_name, email, phone, city")
        .in("id", ids)
    : { data: [] };
  const profileMap = new Map(
    (profiles ?? []).map((profile) => [profile.id, profile]),
  );
  const { data: specialtyReference } = canReviewProfiles
    ? await supabase.from("master_data_items").select("id,label,code,slug").eq("category","veterinary_specialization").eq("is_active",true)
    : { data: [] };
  const specialtyIdFor = (label: string) => {
    const normalized = label.trim().toLowerCase();
    return specialtyReference?.find(item => [item.label,item.code,item.slug].some(value => String(value || "").trim().toLowerCase() === normalized))?.id ?? null;
  };
  const productRows = (products ?? []) as PendingProduct[];
  const jobRows = (jobs ?? []) as PendingJob[];
  const {data:availableJobSectors}=await supabase.from("master_data_items")
    .select("label").eq("category","job_sector").eq("is_active",true).order("label");
  const {data:jobCoverageRows}=jobRows.length ? await supabase.from("job_coverage")
    .select("job_id,display_text").in("job_id",jobRows.map(j=>j.id)) : {data:[]};
  const jobLocations=new Map((jobCoverageRows ?? []).map(v=>[v.job_id,v.display_text]));
  const { data: regulatoryData } = await supabase
    .from("product_regulatory")
    .select("product_id, registration_number, registration_status, applicability")
    .eq("verification_status", "pending");
  const regulatoryRows = (regulatoryData ?? []) as PendingRegulatory[];
  const regulatoryProductIds = regulatoryRows.map((row) => row.product_id);
  const { data: regulatoryProducts } = regulatoryProductIds.length
    ? await supabase
        .from("products")
        .select("id, product_name, company_user_id, company_id, category")
        .in("id", regulatoryProductIds)
    : { data: [] };
  const regulatoryProductMap = new Map(
    (regulatoryProducts ?? []).map((product) => [product.id, product]),
  );
  const legacyCompanyIds = [...new Set([
    ...productRows.map((product) => product.company_user_id),
    ...jobRows.map((job) => job.company_user_id),
  ].filter((value): value is string => Boolean(value)))];
  const canonicalCompanyIds = [...new Set([
    ...productRows.map((product) => product.company_id),
    ...jobRows.map((job) => job.company_id),
  ].filter((value): value is string => Boolean(value)))];
  const [{ data: legacyProductCompanies }, { data: canonicalProductCompanies }] = await Promise.all([
    legacyCompanyIds.length
      ? supabase.from("public_companies").select("user_id, company_name").in("user_id", legacyCompanyIds)
      : Promise.resolve({ data: [] }),
    canonicalCompanyIds.length
      ? supabase.from("companies").select("id, canonical_name").in("id", canonicalCompanyIds)
      : Promise.resolve({ data: [] }),
  ]);
  const legacyProductCompanyMap = new Map(
    (legacyProductCompanies ?? []).map((company) => [company.user_id, company.company_name]),
  );
  const canonicalProductCompanyMap = new Map(
    (canonicalProductCompanies ?? []).map((company) => [company.id, company.canonical_name]),
  );
  const companyNameFor = (companyId: string | null, companyUserId: string | null) =>
    (companyId ? canonicalProductCompanyMap.get(companyId) : null) ||
    (companyUserId ? legacyProductCompanyMap.get(companyUserId) : null) ||
    "Verified company";
  const productIds = productRows.map((product) => product.id);
  const { data: complianceRows } = productIds.length
    ? await supabase
        .from("product_regulatory")
        .select("product_id, registration_number")
        .in("product_id", productIds)
    : { data: [] };
  const complianceMap = new Map(
    (complianceRows ?? []).map((row) => [row.product_id, row.registration_number]),
  );

  const { data: adminDocuments } = canReviewProfiles ? await supabase
    .from("admin_record_documents")
    .select("entity_type,entity_id,document_kind,original_name,storage_path")
    .order("created_at", { ascending: false })
    .limit(200) : {data: []};
  const signedDocuments = await Promise.all((adminDocuments ?? []).map(async (document) => {
    const { data } = await supabase.storage.from("record-documents").createSignedUrl(document.storage_path, 3600);
    return { ...document, signed_url: data?.signedUrl ?? null };
  }));
  const documentMap = new Map<string, typeof signedDocuments>();
  for (const document of signedDocuments) {
    const key = `${document.entity_type}:${document.entity_id}`;
    const list = documentMap.get(key) ?? [];
    list.push(document);
    documentMap.set(key, list);
  }

  return (
    <main className="vc-review-page">
      <SiteHeader />
      <section className="dashboard-hero">
        <div className="shell dashboard-hero-row">
          <div>
            <span className="section-kicker">VETCONNECT ADMIN</span>
            <h1>Verification and moderation.</h1>
            <p>Signed in as {identity.email}</p>
          </div>
        </div>
        </section>
     <section className="section compact-section">
  <div className="shell admin-control-layout">
    <AdminNav roles={identity.roles} />

    <div className="admin-control-content">
      <FormMessage {...params} />
      <div className="admin-summary">

            
            
            <article>
              <b>{pending.length}</b>
              <span>Pending profiles</span>
            </article>
            <article>
              <b>{(vets ?? []).length}</b>
              <span>Veterinarians</span>
            </article>
            <article>
              <b>{credentialRows.length}</b>
              <span>PVMC checks</span>
            </article>
            <article>
              <b>{(companies ?? []).length + (canonicalCompanies ?? []).length}</b>
              <span>Companies</span>
            </article>
            <article>
              <b>{(professionals ?? []).length}</b>
              <span>Professionals</span>
            </article>
            <article>
              <b>{(laboratories ?? []).length}</b>
              <span>Laboratories</span>
            </article>
            <article>
              <b>{productRows.length}</b>
              <span>Products</span>
            </article>
            <article>
              <b>{regulatoryRows.length}</b>
              <span>Regulatory checks</span>
            </article>
            <article>
              <b>{jobRows.length}</b>
              <span>Jobs</span>
            </article>
          </div>

      <ReviewWorkspaceTabs
        allowed={[
          ...(canReviewProfiles?["registration","profiles","credentials"] as const:[]),
          ...(effectivePermissions.has("products.manage")?["products"] as const:[]),
          ...(effectivePermissions.has("regulatory.review")?["regulatory"] as const:[]),
          ...(effectivePermissions.has("jobs.manage")?["jobs"] as const:[]),
        ]}
        counts={{
          registration:(registrationRows??[]).length,
          profiles:pending.length,
          credentials:credentialRows.length,
          products:productRows.length,
          regulatory:regulatoryRows.length,
          jobs:jobRows.length
        }}
      />


      <div className="vc-review-workspace" data-active={canReviewProfiles?"registration":effectivePermissions.has("products.manage")?"products":effectivePermissions.has("regulatory.review")?"regulatory":"jobs"}>
      <div id="review-panel-registration" data-review-panel="registration" role="tabpanel" aria-labelledby="review-tab-registration">
            {effectivePermissions.has("profiles.review") && <section className="admin-review-section">
        <div className="section-heading"><span className="section-kicker">REGISTRATION REVIEW</span><h2>New account applications</h2><p>Private identity and qualification files are visible only to authorized reviewers. Approval is required before the account profile becomes public.</p></div>
        {(registrationRows??[]).length===0 ? <p className="form-help">No registrations are waiting for review.</p> : (registrationRows??[]).map(row=>{
          const profile=registrationProfileMap.get(row.user_id);
          const docs=registrationDocsMap.get(row.user_id)??[];
          const submittedDetails=registrationDetailMap.get(row.user_id)??{};
          const detailEntries=Object.entries(submittedDetails).filter(([key,value])=>
            !["sector_ids","subcategory_ids"].includes(key) &&
            (typeof value==="string"?value.length>0:Array.isArray(value)&&value.length>0)
          );
          const displayList=(key:string)=>Array.isArray(submittedDetails[key])?
            (submittedDetails[key] as unknown[]).filter(value=>typeof value==="string"&&value.trim()).join(", "):"";
          const sectorLabel=displayList("practice_areas")||displayList("industry_sectors")||
            String(submittedDetails.industry_sector||"Not supplied");
          const categoryLabel=displayList("professional_types")||
            String(submittedDetails.professional_type||profile?.primary_role||"Not supplied");
          const subcategoryLabel=displayList("specializations")||
            String(submittedDetails.specialization_other||"Not supplied");
          return <article className="admin-review-card" key={row.user_id} id={`registration-review-${row.user_id}`}>
            <div className="review-header"><div><span className="module-tag">{profile?.primary_role??"Professional"}</span><h3>{profile?.full_name??profile?.email??"Applicant"}</h3><p>{profile?.email} · {[profile?.city||submittedDetails.city,profile?.province||submittedDetails.province].filter(Boolean).join(", ")||"City not provided"}</p><p>Application ID: {row.user_id}</p></div><span className="status-pill">Pending</span></div>
            <PrintReviewButton targetId={`registration-review-${row.user_id}`} />
            <details><summary><b>1. Profile · Sector / Category / Subcategory</b></summary>
            <p>Track: {row.registration_intent||row.student_track||"standard"}</p>
            <p><b>Sector:</b> {sectorLabel}</p><p><b>Category:</b> {categoryLabel}</p>
            <p><b>Subcategory / Expertise:</b> {subcategoryLabel}</p>
            <p>Sector reference ID(s): {Array.isArray(submittedDetails.sector_ids) && submittedDetails.sector_ids.length ? submittedDetails.sector_ids.join(", ") : "Not mapped"}</p>
            <p>Subcategory reference ID(s): {Array.isArray(submittedDetails.subcategory_ids) && submittedDetails.subcategory_ids.length ? submittedDetails.subcategory_ids.join(", ") : Array.isArray(submittedDetails.specializations) && submittedDetails.specializations.length ? submittedDetails.specializations.map((value:unknown)=>specialtyIdFor(String(value)) || "Not mapped").join(", ") : "Not mapped"}</p>
            {detailEntries.length>0&&<dl className="review-details">
              {detailEntries.map(([key,value])=><div key={key}><dt>{key.split("_").map(word=>word.charAt(0).toUpperCase()+word.slice(1)).join(" ")}</dt><dd>{Array.isArray(value)?value.join(", "):String(value)}</dd></div>)}
            </dl>}</details>
            <details><summary><b>2. Documents · {docs.length} attached</b></summary>
              <ReviewDocumentsPanel veterinarian={profile?.primary_role==="veterinarian"} documents={docs.map((doc,i)=>({key:doc.storage_path+"-"+i,kind:doc.document_type,filename:doc.original_filename,status:doc.verification_status,url:doc.signed_url}))}/>
            </details>
            <details><summary><b>3. Review &amp; Decision</b></summary>
            <form action={reviewRegistrationSubmissionAction}>
              <input type="hidden" name="user_id" value={row.user_id}/>
              <label>Reviewer note <textarea name="reason" maxLength={1000} placeholder="For clinic approval, record PVMC registry source, registration status and verification details (at least 25 characters)."/></label>
              {row.registration_intent==="clinic"&&<p className="form-help">Approving registration activates the organization account only. Its clinic stays private and pending until clinical services, opening hours and a separate PVMC facility review are completed.</p>}
              <div className="review-actions">
                <FormSubmitButton className="button button-primary" pendingLabel="Approving…" name="decision" value="approved">Approve registration</FormSubmitButton>
                <FormSubmitButton className="button button-secondary" pendingLabel="Returning…" name="decision" value="rejected">Return for changes</FormSubmitButton>
              </div>
            </form></details>
          </article>;
        })}
      </section>}
      </div>
      <div id="review-panel-profiles" data-review-panel="profiles" role="tabpanel" aria-labelledby="review-tab-profiles">
          {canReviewProfiles && <div id="pending-profiles" className="admin-review-list vc-review-target">
            {pending.length === 0 && (
              <div className="empty-state">
                <h2>No profiles are waiting for review.</h2>
                <p>
                  New veterinarian and company registrations will appear here.
                </p>
              </div>
            )}
            {pending.map((row) => {
              const profile = profileMap.get(row.user_id);
              const type = String(row.profile_type);
              const documentEntityType = row.record_source === "managed_people" ? "person" : row.record_source === "companies" ? "company" : row.record_source === "clinics" ? "clinic" : row.record_source === "laboratories" ? "laboratory" : null;
              const documents = documentEntityType ? documentMap.get(`${documentEntityType}:${String(row.entity_id || row.user_id)}`) ?? [] : [];
              const accountDocs = row.record_source === "account" ? registrationDocsMap.get(row.user_id) ?? [] : [];
              const sector = String(row.veterinary_sector || row.sector || "Not supplied");
              return (
                <article key={`${type}-${row.user_id}`} id={`profile-${row.record_source ?? "account"}-${String(row.entity_id || row.user_id)}`} className="vc-review-target">
                  <div className="review-header">
                    <div>
                      <span className="module-tag">{type}</span>
                      <h2>
                        {type === "company"
                          ? String(row.company_name || row.canonical_name || profile?.full_name || "Company")
                          : type === "laboratory"
                            ? String(row.laboratory_name || profile?.full_name || "Laboratory")
                            : type === "clinic"
                              ? String(row.clinic_name || "Clinic / Hospital")
                              : String(row.full_name || profile?.full_name || (type === "professional" ? "Professional" : "Veterinarian"))}
                      </h2>
                      <p>
                        {profile?.email} ·{" "}
                        {profile?.city || row.city || "City not provided"}
                      </p>
                    </div>
                    <span className="status-pill">Pending</span>
                  </div>
                  <PrintReviewButton targetId={`profile-${row.record_source ?? "account"}-${String(row.entity_id || row.user_id)}`} />
                  <details><summary><b>1. Profile · Sector / Category / Subcategory</b></summary>
                  <dl className="review-details">
                    <div><dt>Sector</dt><dd>{sector}</dd></div>
                    <div><dt>Category</dt><dd>{type}</dd></div>
                    <div><dt>Subcategory / specialty</dt><dd>{String(row.subcategory || row.sub_category || row.specialization || row.professional_type || "Not supplied")}</dd></div>
                    <div><dt>Subcategory reference ID</dt><dd>{specialtyIdFor(String(row.subcategory || row.sub_category || row.specialization || "")) || "Not mapped"}</dd></div>
                    {type === "veterinarian" ? (
                      <>
                        <div>
                          <dt>PVMC number</dt>
                          <dd>{String(row.pvmc_number || "Not provided")}</dd>
                        </div>
                        <div>
                          <dt>Qualifications</dt>
                          <dd>
                            {String(row.qualifications || "Not provided")}
                          </dd>
                        </div>
                        <div>
                          <dt>Specialization</dt>
                          <dd>
                            {String(row.specialization || "Not provided")}
                          </dd>
                        </div>
                      </>
                    ) : type === "company" ? (
                      <>
                        <div>
                          <dt>Business type</dt>
                          <dd>{String(row.business_type || "Not provided")}</dd>
                        </div>
                        <div>
                          <dt>Registration / NTN</dt>
                          <dd>
                            {String(row.registration_number || "Not provided")}
                          </dd>
                        </div>
                        <div>
                          <dt>Address</dt>
                          <dd>{String(row.address || "Not provided")}</dd>
                        </div>
                      </>
                    ) : type === "professional" ? (
                      <>
                        <div><dt>Professional type</dt><dd>{String(row.professional_type || "Not provided")}</dd></div>
                        <div><dt>Headline</dt><dd>{String(row.headline || "Not provided")}</dd></div>
                        <div><dt>Organization</dt><dd>{String(row.organization_name || "Not provided")}</dd></div>
                      </>
                    ) : type === "clinic" ? (
                      <>
                        <div><dt>Facility type</dt><dd>{String(row.facility_type || "Veterinary Clinic")}</dd></div>
                        <div><dt>Services</dt><dd>{Array.isArray(row.services) ? row.services.join(", ") : "Not provided"}</dd></div>
                        <div><dt>Address</dt><dd>{String(row.address || "Not provided")}</dd></div>
                      </>
                    ) : (
                      <>
                        <div><dt>Laboratory type</dt><dd>{String(row.laboratory_type || "Not provided")}</dd></div>
                        <div><dt>Technical head</dt><dd>{String(row.technical_head || "Not provided")}</dd></div>
                        <div><dt>Address</dt><dd>{String(row.address || "Not provided")}</dd></div>
                      </>
                    )}
                  </dl></details>
                  <details><summary><b>2. Documents · {documents.length+accountDocs.length} attached</b></summary>
                    <ReviewDocumentsPanel veterinarian={type==="veterinarian"} documents={[
                      ...documents.map(doc=>({key:doc.storage_path,kind:doc.document_kind,filename:doc.original_name,url:doc.signed_url,status:"Awaiting review"})),
                      ...accountDocs.map((doc,i)=>({key:doc.storage_path+"-"+i,kind:doc.document_type,filename:doc.original_filename,url:doc.signed_url,status:doc.verification_status}))
                    ]}/>
                  </details>
                  <details><summary><b>3. Review &amp; Decision</b></summary>
                  <form action={reviewProfileAction}>
                    <input type="hidden" name="profile_type" value={type} />
                    <input type="hidden" name="record_source" value={row.record_source ?? "account"} />
                    <input type="hidden" name="user_id" value={row.user_id} />
                    <input type="hidden" name="entity_id" value={String(row.entity_id || row.user_id)} />
                    <label htmlFor={`reason-${type}-${row.user_id}`}>
                      Review note, required when rejecting
                    </label>
                    <input
                      id={`reason-${type}-${row.user_id}`}
                      name="reason"
                      placeholder="Add correction or verification note"
                    />
                    {row.record_source==="clinics"&&<label className="checkbox-line"><input type="checkbox" name="pvmc_checked" />I checked the responsible veterinarian&apos;s PVMC registration against official evidence and recorded the source/status in the review note. Approval also requires at least one public service and one open day.</label>}
                    <div className="review-actions">
                      <FormSubmitButton
                        className="button button-primary"
                        pendingLabel="Saving..."
                        name="decision"
                        value="approved"
                      >
                        Approve
                      </FormSubmitButton>
                      <button
                        className="button button-secondary"
                        type="submit"
                        name="decision"
                        value="rejected"
                      >
                        Reject
                      </button>
                    </div>
                  </form></details>
                </article>
              );
            })}
          </div>}
      </div>
      <div id="review-panel-credentials" data-review-panel="credentials" role="tabpanel" aria-labelledby="review-tab-credentials">
          {canReviewProfiles && <div className="section-heading admin-product-heading">
            <span id="credential-checks" className="section-kicker vc-review-target">VETERINARY CREDENTIAL REVIEW</span>
            <h2>PVMC verification is separate from profile approval.</h2>
            <p>Registration numbers remain private. Only the verified status is published.</p>
          </div>}
          {canReviewProfiles && <div className="admin-review-list">
            {credentialRows.length === 0 && (
              <div className="empty-state"><h2>No PVMC credentials are waiting for review.</h2></div>
            )}
            {credentialRows.map((row) => {
              const profile = profileMap.get(row.user_id);
              const documents = row.record_source === "managed_people" ? documentMap.get(`person:${String(row.entity_id || row.user_id)}`) ?? [] : [];
              return (
                <article key={`credential-${row.user_id}`} id={`credential-${row.record_source ?? "account"}-${String(row.entity_id || row.user_id)}`} className="vc-review-target">
                  <div className="review-header"><div><span className="module-tag">PVMC</span><h2>{String(row.full_name || profile?.full_name || "Veterinarian")}</h2><p>{profile?.email} · {profile?.city || row.city || "City not provided"}</p></div><span className="status-pill">Pending</span></div>
                  <dl className="review-details"><div><dt>Private PVMC number</dt><dd>{String(row.pvmc_number || "Not provided")}</dd></div><div><dt>Qualification</dt><dd>{String(row.qualifications || "Not provided")}</dd></div><div><dt>Specialization</dt><dd>{String(row.specialization || "Not provided")}</dd></div></dl>
                  {documents.length > 0 && <div className="review-documents"><b>Credential evidence</b>{documents.map((document) => document.signed_url ? <a key={document.storage_path} href={document.signed_url} target="_blank" rel="noreferrer">{document.original_name}</a> : <span key={document.storage_path}>{document.original_name}</span>)}</div>}
                  <form action={reviewVeterinarianCredentialAction}>
                    <input type="hidden" name="user_id" value={row.user_id} />
                    <input type="hidden" name="record_source" value={row.record_source ?? "account"} />
                    <label htmlFor={`credential-reason-${row.user_id}`}>Verification source or review note</label>
                    <input id={`credential-reason-${row.user_id}`} name="reason" placeholder="Record the source used for this decision" />
                    <div className="review-actions"><FormSubmitButton className="button button-primary" pendingLabel="Saving..." name="decision" value="approved">Verify credential</FormSubmitButton><button className="button button-secondary" type="submit" name="decision" value="rejected">Return / reject</button></div>
                  </form>
                </article>
              );
            })}
          </div>}
      </div>
      <div id="review-panel-products" data-review-panel="products" role="tabpanel" aria-labelledby="review-tab-products">
      {effectivePermissions.has("products.manage") && <>
          <div className="section-heading admin-product-heading">
            <span id="pending-products" className="section-kicker vc-review-target">PRODUCT MODERATION</span>
            <h2>Marketplace submissions.</h2>
            <p>Approve complete company listings before they become public.</p>
          </div>
          <div className="admin-review-list">
            {productRows.length === 0 && (
              <div className="empty-state">
                <h2>No products are waiting for review.</h2>
                <p>New submissions from approved companies will appear here.</p>
              </div>
            )}
            {productRows.map((product) => (
              <article key={product.id} id={`product-${product.id}`} className="vc-review-target">
                <div className="review-header">
                  <div>
                    <span className="module-tag">{product.category}</span>
                    <h2>{product.product_name}</h2>
                    <p>
                      {companyNameFor(product.company_id, product.company_user_id)}
                      {product.sector ? ` · ${product.sector}` : ""}
                    </p>
                  </div>
                  <span className="status-pill">Pending</span>
                </div>
                <dl className="review-details">
                  <div><dt>Brand</dt><dd>{product.brand_name || "Not provided"}</dd></div>
                  <div><dt>Generic</dt><dd>{product.generic_name || "Not provided"}</dd></div>
                  <div><dt>Private regulatory reference</dt><dd>{complianceMap.get(product.id) || "Not provided"}</dd></div>
                </dl>
                <p>{product.description || "No product description was supplied."}</p>
                {(documentMap.get(`product:${product.id}`) ?? []).length > 0 && <div className="review-documents"><b>Supporting documents</b>{(documentMap.get(`product:${product.id}`) ?? []).map((document) => document.signed_url ? <a key={document.storage_path} href={document.signed_url} target="_blank" rel="noreferrer">{document.original_name}</a> : <span key={document.storage_path}>{document.original_name}</span>)}</div>}
                <form action={reviewProductAction}>
                  <input type="hidden" name="product_id" value={product.id} />
                  <label htmlFor={`product-reason-${product.id}`}>
                    Review note, required when rejecting
                  </label>
                  <input id={`product-reason-${product.id}`} name="reason" placeholder="Add correction or approval note" />
                  <div className="review-actions">
                    <FormSubmitButton className="button button-primary" pendingLabel="Saving..." name="decision" value="approved">
                      Approve and publish
                    </FormSubmitButton>
                    <button className="button button-secondary" type="submit" name="decision" value="rejected">Reject</button>
                  </div>
                </form>
              </article>
            ))}
          </div>
      </>}
      </div>
      <div id="review-panel-regulatory" data-review-panel="regulatory" role="tabpanel" aria-labelledby="review-tab-regulatory">
      {effectivePermissions.has("regulatory.review") && <>
          <div className="section-heading admin-product-heading"><span className="section-kicker">REGULATORY REVIEW</span><h2>Product registration evidence.</h2><p>Product-profile approval and regulatory verification are recorded separately.</p></div>
          <div className="admin-review-list">
            {regulatoryRows.length === 0 && <div className="empty-state"><h2>No regulatory records are waiting for review.</h2></div>}
            {regulatoryRows.map((row) => { const product = regulatoryProductMap.get(row.product_id); return <article key={`regulatory-${row.product_id}`}><div className="review-header"><div><span className="module-tag">REGULATORY</span><h2>{product?.product_name || "Product"}</h2><p>{product?.category || "Animal health product"}</p></div><span className="status-pill">Pending</span></div><dl className="review-details"><div><dt>Private registration reference</dt><dd>{row.registration_number || "Not provided"}</dd></div><div><dt>Submitted status</dt><dd>{row.registration_status || "Not provided"}</dd></div><div><dt>Applicability</dt><dd>{row.applicability || "Requires reviewer determination"}</dd></div></dl><form action={reviewProductRegulatoryAction}><input type="hidden" name="product_id" value={row.product_id} /><label htmlFor={`regulatory-note-${row.product_id}`}>Verification source and reviewer note</label><input id={`regulatory-note-${row.product_id}`} name="notes" placeholder="Record the source and basis for this decision" /><div className="review-actions"><FormSubmitButton className="button button-primary" pendingLabel="Saving..." name="decision" value="verified">Verify registration</FormSubmitButton><button className="button button-secondary" type="submit" name="decision" value="not_applicable">Mark reviewed: not applicable</button><button className="button button-secondary" type="submit" name="decision" value="returned">Return for correction</button></div></form></article>; })}
        
                   </div>

      </>}
      </div>
      <div id="review-panel-jobs" data-review-panel="jobs" role="tabpanel" aria-labelledby="review-tab-jobs">
      {effectivePermissions.has("jobs.manage") && <>
          <div className="section-heading admin-product-heading" id="jobs-review">
            <span className="section-kicker">JOB MODERATION</span>
            <h2>Employer opportunities.</h2>
            <p>Approve complete, credible job information before it becomes public.</p>
          </div>

          <div className="admin-review-list">
            {jobRows.length === 0 && (
              <div className="empty-state">
                <h2>No jobs are waiting for review.</h2>
                <p>New opportunities from approved companies will appear here.</p>
              </div>
            )}

            {jobRows.map((job) => (
              <article key={job.id} id={"job-"+job.id}>
                <div className="review-header">
                  <div>
                    <span className="module-tag">{job.sector || "JOB"}</span>
                    <h2>{job.title}</h2>
                    <p>
                      {companyNameFor(job.company_id, job.company_user_id)} ·{" "}
                      {jobLocations.get(job.id) || job.city || "Location not specified"}
                    </p>
                  </div>
                  <span className="status-pill">Pending</span>
                </div>

                <dl className="review-details">
                  <div>
                    <dt>Employment type</dt>
                    <dd>{job.employment_type}</dd>
                  </div>
                  <div>
                    <dt>Qualification</dt>
                    <dd>{job.minimum_qualification || "Not provided"}</dd>
                  </div>
                  <div>
                    <dt>Experience</dt>
                    <dd>{job.minimum_experience===null?"Not specified":job.minimum_experience+" years"}</dd>
                  </div>
                  <div>
                    <dt>Deadline</dt>
                    <dd>{job.deadline || "Not provided"}</dd>
                  </div>
                </dl>

                <p>{job.description}</p>
                {(documentMap.get(`job:${job.id}`) ?? []).length > 0 && <div className="review-documents"><b>Supporting documents</b>{(documentMap.get(`job:${job.id}`) ?? []).map((document) => document.signed_url ? <a key={document.storage_path} href={document.signed_url} target="_blank" rel="noreferrer">{document.original_name}</a> : <span key={document.storage_path}>{document.original_name}</span>)}</div>}

                <form action={reviewJobAction}>
                  <input type="hidden" name="job_id" value={job.id} />
                  <div className="form-grid">
                    <div><label htmlFor={"review_sector_"+job.id}>Correct Job Sector before publishing</label>
                      <select id={"review_sector_"+job.id} name="review_sector" defaultValue={job.sector && (availableJobSectors??[]).some(x=>x.label===job.sector)?job.sector:""}>
                        <option value="">Not specified</option>
                        {(availableJobSectors??[]).map(x=><option key={x.label} value={x.label}>{x.label}</option>)}
                      </select>
                      {job.sector && !(availableJobSectors??[]).some(x=>x.label===job.sector) && <small>Original sector &ldquo;{job.sector}&rdquo; is not an approved job sector. Select a valid one or leave unspecified.</small>}
                    </div>
                    <div><label htmlFor={"review_qualification_"+job.id}>Qualification (verify against advertisement)</label>
                      <input id={"review_qualification_"+job.id} name="review_qualification" defaultValue={job.minimum_qualification??""} placeholder="Not specified"/>
                    </div>
                    <div><label htmlFor={"review_experience_"+job.id}>Experience years (leave blank if not given)</label>
                      <input type="number" min="0" id={"review_experience_"+job.id} name="review_experience" defaultValue={job.minimum_experience??""}/>
                    </div>
                  </div>

                  <div className="review-actions">
                    <FormSubmitButton
                      className="button button-primary"
                      pendingLabel="Saving..."
                      name="decision"
                      value="approved"
                    >
                      Approve and publish
                    </FormSubmitButton>

                    <button
                      className="button button-secondary"
                      type="submit"
                      name="decision"
                      value="rejected"
                    >
                      Reject
                    </button>
                  </div>
                </form>
              </article>
            ))}
          </div>
      </>}
      </div>
      </div>
        </div>
      </div>
    </section>
      <SiteFooter />
    </main>
  );
}
