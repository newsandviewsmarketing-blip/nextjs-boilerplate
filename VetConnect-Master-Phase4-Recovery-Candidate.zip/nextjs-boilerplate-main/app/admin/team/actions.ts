"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireSuperAdminTeamAccess } from "@/lib/admin";
import { createClient } from "@/lib/supabase/server";
import { TEAM_GROUPS } from "@/lib/team-members";

const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
function field(form:FormData,name:string,max:number) {return String(form.get(name)??"").trim().slice(0,max);}
function urlField(form:FormData,name:string) {
  const value=field(form,name,500); if(!value)return null;
  try { const url=new URL(value);if(url.protocol!=="https:")throw Error();return url.href; }
  catch {throw Error("Provide a valid HTTPS link for "+name);}
}
export async function saveTeamMember(form:FormData){
  const identity=await requireSuperAdminTeamAccess();
  const db=await createClient();
  const id=field(form,"id",64);
  if(id && !uuid.test(id))throw Error("Invalid member ID.");
  const name=field(form,"full_name",120),title=field(form,"job_title",120);
  const slug=field(form,"slug",100).toLowerCase();
  if(name.length<2||title.length<2||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug))throw Error("Name, title and URL slug are required.");
  const summary=field(form,"summary",500),biography=field(form,"biography",8000);
  const sort=Number(field(form,"sort_order",8));
  if(!Number.isSafeInteger(sort)||sort<0||sort>99999)throw Error("Invalid display order.");
  let photoPath:string|null=null;
  if(id){
    const {data,error}=await db.from("team_members").select("photo_path").eq("id",id).maybeSingle();
    if(error||!data)throw Error("Member not found or permission denied.");
    photoPath=data.photo_path;
  }
  const image=form.get("photo");
  if(image instanceof File && image.size>0){
    if(image.size>5*1024*1024||!["image/jpeg","image/png","image/webp"].includes(image.type))throw Error("Choose a JPG, PNG or WebP image under 5 MB.");
    const ext={"image/jpeg":"jpg","image/png":"png","image/webp":"webp"}[image.type];
    const filePath=identity.userId+"/"+crypto.randomUUID()+"."+ext;
    const {error}=await db.storage.from("team-photos").upload(filePath,image,{contentType:image.type,upsert:false});
    if(error)throw Error("Photo upload failed.");
    photoPath=filePath;
  }
  const values={
    full_name:name,slug,job_title:title,department:field(form,"department",120),
    summary,biography,expertise:field(form,"expertise",1200),
    qualifications:field(form,"qualifications",1200),
    linkedin_url:urlField(form,"linkedin_url"),email_public:field(form,"email_public",254)||null,
    photo_path:photoPath,sort_order:sort,is_published:form.get("is_published")==="on",
    team_group:field(form,"team_group",30),
    seo_title:field(form,"seo_title",160),seo_description:field(form,"seo_description",300),
    website_url:urlField(form,"website_url"),facebook_url:urlField(form,"facebook_url"),
    photo_position_y:Number(field(form,"photo_position_y",3)),
    updated_at:new Date().toISOString()
  };
  if(!TEAM_GROUPS.some(g=>g.value===values.team_group))throw Error("Choose a valid leadership group.");
  if(!Number.isInteger(values.photo_position_y)||values.photo_position_y<0||values.photo_position_y>100)throw Error("Invalid photo positioning.");
  if(values.is_published && (!summary || !biography || !photoPath))throw Error("A portrait, summary and biography are required before publication.");
  if(values.email_public&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email_public))throw Error("Invalid public email.");
  const result=id?await db.from("team_members").update(values).eq("id",id).select("id").single():
     await db.from("team_members").insert(values).select("id").single();
  if(result.error||!result.data?.id)throw Error("Team profile was not saved. Check your permission, unique profile URL and database connectivity.");
  revalidatePath("/team");revalidatePath("/admin/team");
  redirect("/admin/team?message=Member%20profile%20saved");
}
export async function unpublishTeamMember(form:FormData){
  await requireSuperAdminTeamAccess();
  const id=field(form,"id",64);if(!uuid.test(id))throw Error("Invalid member ID.");
  const db=await createClient();
  const {data,error}=await db.from("team_members").update({is_published:false,updated_at:new Date().toISOString()}).eq("id",id).select("id").single();
  if(error||!data?.id)throw Error("The team profile could not be unpublished. Verify permission and retry.");
  revalidatePath("/team");revalidatePath("/admin/team");
  redirect("/admin/team?message=Member%20unpublished");
}
