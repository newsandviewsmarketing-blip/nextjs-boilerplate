import CareerWorkspaceFrame from '@/app/components/CareerWorkspaceFrame';
import {matchesJobLocation} from '@/lib/job-location';
import type {PublicJob} from '@/lib/jobs';
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentIdentity } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { uploadCareerCvAction,recordJobApplicationActivityAction } from "./actions";

export const dynamic = "force-dynamic";

type ApplicationRow = {
  id: string;
  job_id: string;
  status: string;
  cover_note: string | null;
  applied_at: string;
  cv_source?: string|null;
  cv_document_id?:string|null;
};

type SavedRow = { job_id: string; created_at: string };
type MatchRow = { job_id: string; match_score: number; explanation: string; calculated_at: string };

type JobRow = {
  id: string;
  slug: string;
  title: string;
  sector: string | null;
  city: string | null;
  province: string | null;
  employment_type: string;
  company_user_id: string | null;
  deadline: string | null;
};
type ApplicationActivity = {id:string;application_id:string;activity_type:string;direction:string;details:string;occurred_at:string};

export default async function CareerWorkspacePage({searchParams}:{searchParams:Promise<{error?:string;message?:string}>}) {
  const alerts=await searchParams;
  const identity = await getCurrentIdentity();
  if (!identity) redirect("/login?next=/dashboard/career");

  const eligible = identity.roles.some((role) =>
    ["veterinarian", "professional", "candidate"].includes(role),
  );
  if (!eligible) {
    redirect("/dashboard?error=Career%20workspace%20is%20available%20to%20veterinarians%20and%20professional%20candidates.");
  }

  const supabase = await createClient();
  const [applicationResult, savedResult, matchResult, cvDocumentsResult, cvProfileResult, professionalResult, preferencesResult, publicJobsResult] = await Promise.all([
    supabase
      .from("job_applications")
      .select("id, job_id, status, cover_note, applied_at, cv_source, cv_document_id")
      .eq("candidate_user_id", identity.userId)
      .order("applied_at", { ascending: false }),
    supabase
      .from("saved_jobs")
      .select("job_id, created_at")
      .eq("user_id", identity.userId)
      .order("created_at", { ascending: false }),
    supabase
      .from("job_matches")
      .select("job_id, match_score, explanation, calculated_at")
      .eq("candidate_user_id", identity.userId)
      .order("match_score", { ascending: false })
      .limit(12),
    supabase.from("career_documents").select("id,created_at,is_current")
      .eq("professional_user_id",identity.userId).eq("document_type","cv")
      .order("created_at",{ascending:false}).limit(25),
    supabase.from("career_cv_profiles").select("full_name,headline")
      .eq("user_id",identity.userId).maybeSingle(),
    supabase.from("professional_profiles").select("verification_status,headline,image_url").eq("user_id",identity.userId).maybeSingle(),
    supabase.from("candidate_preferences").select("preferred_sectors,desired_roles,preferred_cities,preferred_job_types").eq("professional_user_id",identity.userId).maybeSingle(),
    supabase.from("public_jobs").select("id,slug,title,description,sector,city,province,district,tehsil,employment_type,deadline,company_name").limit(100),
  ]);

  const pref=preferencesResult.data;
  const sectors=(pref?.preferred_sectors??[] as string[]).map((x:string)=>x.trim().toLowerCase()).filter(Boolean);
  const roles=(pref?.desired_roles??[] as string[]).map((x:string)=>x.trim().toLowerCase()).filter(Boolean);
  const cities=(pref?.preferred_cities??[] as string[]).filter(Boolean);
  const types=(pref?.preferred_job_types??[] as string[]).map((x:string)=>x.trim().toLowerCase()).filter(Boolean);
  const hasInterests=Boolean(sectors.length||roles.length||cities.length||types.length);
  const currentDate=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Karachi',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const interestMatches=hasInterests?(publicJobsResult.data??[]).filter(job=>{
    if(job.deadline&&job.deadline<currentDate)return false;
    if(sectors.length&&!sectors.includes((job.sector??'').trim().toLowerCase()))return false;
    if(roles.length&&!roles.some((role:string)=>(job.title+' '+(job.description??'')).toLowerCase().includes(role)))return false;
    if(types.length&&!types.includes((job.employment_type??'').trim().toLowerCase()))return false;
    if(cities.length&&!cities.some((city:string)=>matchesJobLocation(job as PublicJob,city)))return false;
    return true;
  }).slice(0,8):[];

  const applicationRows = (applicationResult.data ?? []) as ApplicationRow[];
  const savedRows = (savedResult.data ?? []) as SavedRow[];
  const matchRows = (matchResult.data ?? []) as MatchRow[];
  const jobIds = [...new Set([
    ...applicationRows.map((row) => row.job_id),
    ...savedRows.map((row) => row.job_id),
    ...matchRows.map((row) => row.job_id),
  ])];

  let jobs: JobRow[] = [];
  if (jobIds.length) {
    const { data } = await supabase
      .from("jobs")
      .select("id, slug, title, sector, city, province, employment_type, company_user_id, deadline")
      .in("id", jobIds);
    jobs = (data ?? []) as JobRow[];
  }
  const jobMap = new Map(jobs.map((job) => [job.id, job]));
  const activityResult=applicationRows.length ? await supabase.from("job_application_activity")
    .select("id,application_id,activity_type,direction,details,occurred_at")
    .in("application_id",applicationRows.map(a=>a.id)).eq("candidate_user_id",identity.userId)
    .order("occurred_at",{ascending:false}).limit(150) : {data:[],error:null};
  const activityRows=(activityResult.data??[]) as ApplicationActivity[];

  return (
    <CareerWorkspaceFrame
      active="applications"
      name={identity.profile?.full_name||identity.email}
      headline={professionalResult.data?.headline}
      photoUrl={professionalResult.data?.image_url}
      location={[identity.profile?.city,identity.profile?.province].filter(Boolean).join(', ')}
      verificationStatus={professionalResult.data?.verification_status}
      approved={professionalResult.data?.verification_status==='approved'}
      title="Applications and follow-ups."
      description="Your submitted applications, saved jobs and matching opportunities in one place.">
      <div className="vcx-application-tools"><Link className="vcx-button vcx-button-primary" href="/jobs">Browse jobs</Link><Link className="vcx-button vcx-button-outline" href="/career/preferences">Edit interests</Link></div>
          {(applicationResult.error || savedResult.error || matchResult.error) && (
            <div className="form-message form-message-error">{applicationResult.error?.message || savedResult.error?.message || matchResult.error?.message}</div>
          )}
          {alerts.error&&<p className="form-message form-message-error">{alerts.error}</p>}
          {alerts.message&&<p className="form-message form-message-success">{alerts.message}</p>}
          <details className="backend-form-card career-cv-library vcx-collapsible-library" id="my-cvs" open={(cvDocumentsResult.data??[]).length===0}>
            <summary>
              <strong>My private CV library</strong>
              <span>{(cvDocumentsResult.data??[]).length} saved CV files · Manage / upload</span>
            </summary>
            <div className="section-heading compact-heading">
              <span className="section-kicker">MY PRIVATE CV LIBRARY</span>
              <h2>Saved CVs and CV Builder</h2>
              <p>Upload your CV once. Choose it for each job application; it is not published on your public profile.</p>
            </div>
            <div className="career-cv-grid">
              <form action={uploadCareerCvAction} className="profile-form" encType="multipart/form-data">
                <label htmlFor="cv-file-upload">Upload CV (PDF, DOC, DOCX, JPG or PNG, maximum 5 MB)</label>
                <input id="cv-file-upload" type="file" name="cv_file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required/>
                <label htmlFor="cv-account-email">Confirm your verified account email *</label>
                <input id="cv-account-email" type="email" name="confirm_email" autoComplete="email" required maxLength={254} placeholder={identity.email||"Account email"}/>
                <p className="form-help">Email must match the verified address of your signed-in VetConnect account.</p>
                <button className="button button-primary" type="submit">Save CV privately</button>
              </form>
              <div>
                <h3>Saved CVs</h3>
                {(cvDocumentsResult.data??[]).length===0?<p>No CV files saved yet.</p>:
                  <ul className="career-cv-list">{(cvDocumentsResult.data??[]).map(cv=><li key={cv.id}>
                    <a href={"/api/career/documents/"+cv.id} target="_blank" rel="noopener noreferrer">
                      CV · {new Date(cv.created_at).toLocaleDateString("en-PK")}{cv.is_current?" (Current)":""}
                    </a>
                  </li>)}</ul>}
                <h3>VetConnect CV Builder</h3>
                <p>{cvProfileResult.data?.full_name?"Saved: "+cvProfileResult.data.full_name:"No profile CV created yet."}</p>
                <Link className="button button-secondary" href="/dashboard/career/cv">Create / Edit CV</Link>
              </div>
            </div>
          </details>
          <div className="admin-summary">
            <article><b>{applicationRows.length}</b><span>Total applications</span></article>
            <article><b>{applicationRows.filter((row) => row.status === "shortlisted").length}</b><span>Shortlisted</span></article>
            <article><b>{applicationRows.filter((row) => row.status === "interview").length}</b><span>Interview stage</span></article>
            <article><b>{savedRows.length}</b><span>Saved jobs</span></article>
            <article><b>{matchRows.length}</b><span>Calculated matches</span></article>
          </div>

          <div className="workspace-two-column workspace-heading-gap">
            <section>
              <div className="section-heading"><span className="section-kicker">MY APPLICATIONS</span><h2>Application status.</h2><p>Employers move applications through the recruitment pipeline.</p></div>
              {applicationRows.length === 0 ? (
                <div className="empty-state"><h2>No applications yet.</h2><p>Browse approved opportunities and apply with your VetConnect professional profile.</p><Link className="button button-primary" href="/jobs">Find jobs</Link></div>
              ) : (
                <div className="admin-data-list">
                  {applicationRows.map((application) => {
                    const job = jobMap.get(application.job_id);
                    return <article key={application.id}><div className="admin-data-main"><div className="admin-data-title"><span className="module-tag">{job?.sector || "Veterinary career"}</span><h2>{job?.title || "Job application"}</h2></div><p>{[job?.city, job?.province, job?.employment_type].filter(Boolean).join(" · ") || "VetConnect job"}</p><div className="status-cluster"><span className={`status-pill status-${application.status}`}>{application.status.replaceAll("_", " ")}</span><span className="status-pill">Applied {new Date(application.applied_at).toLocaleDateString("en-PK")}</span>
                        <span className="status-pill">{application.cv_source==="saved_cv"?"Saved CV attached":application.cv_source==="profile_cv"?"VetConnect CV attached":"Legacy application"}</span>
                        <span className="status-pill">Deadline: {job?.deadline?new Date(job.deadline+"T12:00:00").toLocaleDateString("en-PK"):"Not specified"}</span>
                      </div>
                      {application.cv_document_id&&<p><a className="text-link" href={"/api/career/documents/"+application.cv_document_id} target="_blank" rel="noopener noreferrer">View CV submitted with this application</a></p>}
                      {job?.slug&&<p><Link className="text-link" href={"/jobs/"+job.slug}>View original job advertisement</Link></p>}
                      <details className="backend-form-card">
                        <summary>Calls, messages & interviews ({activityRows.filter(a=>a.application_id===application.id).length})</summary>
                        <p className="form-help">Private notes entered by you. Calls and messages outside VetConnect are not automatically recorded.</p>
                        {activityRows.filter(a=>a.application_id===application.id).map(a=><div key={a.id} className="career-activity-entry">
                          <strong>{a.activity_type.replaceAll("_"," ")} · {a.direction.replaceAll("_"," ")}</strong>
                          <small> {new Date(a.occurred_at).toLocaleString("en-PK")}</small><p>{a.details}</p>
                        </div>)}
                        <form action={recordJobApplicationActivityAction} className="profile-form">
                          <input type="hidden" name="application_id" value={application.id}/>
                          <label htmlFor={"activity-kind-"+application.id}>Activity</label>
                          <select id={"activity-kind-"+application.id} name="activity_type" required defaultValue="phone_call">
                            <option value="phone_call">Phone call</option><option value="message">Message / WhatsApp</option>
                            <option value="interview">Interview</option><option value="follow_up">Follow-up</option><option value="note">Other note</option>
                          </select>
                          <label htmlFor={"activity-direction-"+application.id}>Direction</label>
                          <select id={"activity-direction-"+application.id} name="direction" defaultValue="received">
                            <option value="received">Received</option><option value="sent">Sent</option><option value="not_applicable">Not applicable</option>
                          </select>
                          <label htmlFor={"activity-details-"+application.id}>Notes (private)</label>
                          <textarea id={"activity-details-"+application.id} name="details" maxLength={2000} required placeholder="Record the contact, interview date or next step."/>
                          <button className="button button-secondary" type="submit">Save activity</button>
                        </form>
                      </details>
                    </div></article>;
                  })}
                </div>
              )}
            </section>

            <section>
              <div className="section-heading"><span className="section-kicker">SAVED JOBS</span><h2>Opportunities to revisit.</h2></div>
              {savedRows.length === 0 ? <div className="empty-state"><p>No saved jobs yet.</p></div> : <div className="admin-data-list">{savedRows.map((saved) => { const job = jobMap.get(saved.job_id); return <article key={saved.job_id}><div className="admin-data-main"><div className="admin-data-title"><span className="module-tag">{job?.sector || "Career"}</span><h2>{job?.title || "Saved job"}</h2></div><p>{[job?.city, job?.province, job?.employment_type].filter(Boolean).join(" · ")}</p><span className="status-pill">Saved {new Date(saved.created_at).toLocaleDateString("en-PK")}</span></div>{job?.slug && <Link className="button button-secondary" href={`/jobs/${job.slug}`}>Open</Link>}</article>; })}</div>}
            </section>
          </div>

          <section className="workspace-heading-gap" aria-labelledby="current-interest-jobs">
            <div className="section-heading"><span className="section-kicker">NEW JOBS FOR YOU</span><h2 id="current-interest-jobs">Jobs matching your saved interests.</h2><p>Fresh approved vacancies appear when you open your dashboard, even if you have not enabled email alerts.</p></div>
            {(preferencesResult.error||publicJobsResult.error)&&<p role="alert" className="form-message form-message-error">Could not load current interest matches. Please browse jobs and retry later.</p>}
            {!hasInterests?<div className="empty-state"><p>Choose sectors, roles, cities or employment types to see relevant opportunities.</p><Link className="button button-secondary" href="/career/preferences">Set job interests</Link></div>:
             interestMatches.length===0?<div className="empty-state"><p>No current jobs match these filters.</p><Link className="button button-secondary" href="/career/preferences">Update interests</Link></div>:
             <div className="company-grid">{interestMatches.map(job=><article key={job.id}><span className="module-tag">{job.sector||'Career'}</span><h3>{job.title}</h3><p>{[job.company_name,job.city,job.province,job.employment_type].filter(Boolean).join(' · ')}</p><Link className="button button-primary button-full" href={'/jobs/'+job.slug}>View opportunity</Link></article>)}</div>}
          </section>

          <section className="workspace-heading-gap">
            <div className="section-heading"><span className="section-kicker">JOB MATCHES</span><h2>Profile-based opportunity matches.</h2><p>Match records are calculated from the structured career data already stored in VetConnect.</p></div>
            {matchRows.length === 0 ? <div className="empty-state"><h2>No calculated matches yet.</h2><p>Complete your professional profile so future matching has standardized education, skills and experience data.</p><Link className="button button-primary" href="/dashboard/professional">Complete professional profile</Link></div> : <div className="company-grid">{matchRows.map((match) => { const job = jobMap.get(match.job_id); return <article key={match.job_id}><span className="module-tag">{job?.sector || "Veterinary career"}</span><h3>{job?.title || "Matched opportunity"}</h3><p>{match.explanation}</p><div className="status-cluster"><span className="status-pill status-approved">{Number(match.match_score).toFixed(0)}% match</span><span className="status-pill">{[job?.city, job?.province].filter(Boolean).join(", ") || "Pakistan"}</span></div>{job?.slug && <Link className="button button-primary button-full" href={`/jobs/${job.slug}`}>View opportunity</Link>}</article>; })}</div>}
          </section>
    </CareerWorkspaceFrame>
  );
}
