"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentIdentity } from "@/lib/auth";
import { profileNameProblem } from "@/lib/profile-name";
import {PRACTICE_AREAS,SPECIALIZATIONS} from "@/lib/registration-categories";

function value(formData: FormData, name: string) {
  return String(formData.get(name) ?? "").trim();
}

function message(kind: "error" | "message", text: string) {
  return `/dashboard?${kind}=${encodeURIComponent(text)}`;
}

export async function updateProfileAction(formData: FormData) {
  const identity = await getCurrentIdentity();

  if (!identity) {
    redirect("/login?next=/dashboard");
  }

  const supabase = await createClient();
  const fullName = value(formData, "full_name");
  const nameProblem = profileNameProblem(fullName);
  if (nameProblem) redirect(message("error", nameProblem));
  const phone = value(formData, "phone");
  const city = value(formData, "city");
  const province = value(formData, "province");
  const district = value(formData, "district");
  const tehsil = value(formData, "tehsil");

  if (!fullName) {
    redirect(
      message(
        "error",
        "Full name is required.",
      ),
    );
  }

  const { error: profileError } = await supabase
    .from("profiles")
    .update({
      full_name: fullName,
      phone: phone || null,
      city: city || null,
      province: province || null,
      district: district || null,
      tehsil: tehsil || null,
    })
    .eq("id", identity.userId);

  if (profileError) {
    redirect(
      message(
        "error",
        profileError.message,
      ),
    );
  }

  if (
    identity.profile?.primary_role ===
    "veterinarian"
  ) {
    const pvmcNumber=value(formData,"pvmc_number");
    if(!pvmcNumber) redirect(message("error","PVMC registration number is required to save a veterinarian profile. For a student or allied professional, contact support to correct the account category."));
    const mainSector=value(formData,"veterinary_sector");
    const extraAreas=formData.getAll("practice_areas").map(String).filter(x=>(PRACTICE_AREAS as readonly string[]).includes(x));
    const chosenServices=formData.getAll("services").map(String).map(x=>x.trim()).filter(Boolean);
    const services=[...new Set([...chosenServices.filter(x=>!x.startsWith("Practice area: ")),...extraAreas.map(x=>"Practice area: "+x),...(mainSector?["Practice area: "+mainSector]:[])])];
    const baseSpec=value(formData,"specialization");
    const otherSpecs=formData.getAll("specializations_extra").map(String).filter(x=>(SPECIALIZATIONS as readonly string[]).includes(x));
    const specializations=[...new Set([baseSpec,...otherSpecs].filter(Boolean))].join(", ");

    const { error } = await supabase
      .from("veterinarian_profiles")
      .update({
        pvmc_number:
          pvmcNumber,

        qualifications:
          value(formData, "qualifications") ||
          null,

        veterinary_sector: value(formData, "veterinary_sector") || null,

        specialization: specializations || null,

        years_experience: Number(
          value(
            formData,
            "years_experience",
          ) || 0,
        ),

        city: city || null,
        province: province || null,
        district: district || null,
        tehsil: tehsil || null,

        services,
      })
      .eq(
        "user_id",
        identity.userId,
      );

    if (error) {
      redirect(
        message(
          "error",
          error.message,
        ),
      );
    }

    // Every veterinarian also has a canonical professional identity.
    // Keep shared location and experience fields synchronized without
    // overwriting the richer LinkedIn-style professional summary.
    const { error: professionalSyncError } = await supabase
      .from("professional_profiles")
      .update({
        professional_type: "Veterinarian",
        city: city || null,
        province: province || null,
        district: district || null,
        tehsil: tehsil || null,
        years_experience: Number(value(formData, "years_experience") || 0),
      })
      .eq("user_id", identity.userId);

    if (professionalSyncError) {
      redirect(message("error", professionalSyncError.message));
    }
  }

  if (
    identity.profile?.primary_role ===
    "company"
  ) {
    const { error } = await supabase
      .from("company_profiles")
      .update({
        company_name:
          value(
            formData,
            "company_name",
          ),

        business_type:
          value(
            formData,
            "business_type",
          ) || null,

        registration_number:
          value(
            formData,
            "registration_number",
          ) || null,

        city: city || null,
        province: province || null,
        district: district || null,
        tehsil: tehsil || null,

        address:
          value(
            formData,
            "address",
          ) || null,

        description:
          value(
            formData,
            "description",
          ) || null,

        website:
          value(
            formData,
            "website",
          ) || null,

        contact_email:
          value(
            formData,
            "contact_email",
          ) || null,

        logo_url:
          value(
            formData,
            "logo_url",
          ) || null,
      })
      .eq(
        "user_id",
        identity.userId,
      );

    if (error) {
      redirect(
        message(
          "error",
          error.message,
        ),
      );
    }

    const selectedRoles = formData
      .getAll("company_roles")
      .map((item) => String(item))
      .filter(Boolean);

    // Reconcile company roles.
    // First deactivate previous selections so unchecked roles
    // do not remain active in the database.
    const {
      error: deactivateRolesError,
    } = await supabase
      .from("company_roles")
      .update({
        is_active: false,
      })
      .eq(
        "company_user_id",
        identity.userId,
      );

    if (deactivateRolesError) {
      redirect(
        message(
          "error",
          deactivateRolesError.message,
        ),
      );
    }

    // Reactivate/upsert only roles currently selected by the user.
    for (
      const roleType of selectedRoles
    ) {
      const details = value(
        formData,
        `role_details_${roleType}`,
      );

      const {
        error: roleError,
      } = await supabase
        .from("company_roles")
        .upsert(
          {
            company_user_id:
              identity.userId,

            role_type: roleType,

            details,

            is_active: true,
          },
          {
            onConflict:
              "company_user_id,role_type",
          },
        );

      if (roleError) {
        redirect(
          message(
            "error",
            roleError.message,
          ),
        );
      }
    }

    const selectedSectors =
      formData
        .getAll("company_sectors")
        .map((item) =>
          String(item),
        )
        .filter(Boolean);

    // company_sectors has no active/inactive flag.
    // Rebuild the current selection so removed sectors
    // do not remain stored after editing.
    const {
      error: clearSectorsError,
    } = await supabase
      .from("company_sectors")
      .delete()
      .eq(
        "company_user_id",
        identity.userId,
      );

    if (clearSectorsError) {
      redirect(
        message(
          "error",
          clearSectorsError.message,
        ),
      );
    }

    if (
      selectedSectors.length > 0
    ) {
      const {
        error: sectorError,
      } = await supabase
        .from("company_sectors")
        .insert(
          selectedSectors.map(
            (sector) => ({
              company_user_id:
                identity.userId,
              sector,
            }),
          ),
        );

      if (sectorError) {
        redirect(
          message(
            "error",
            sectorError.message,
          ),
        );
      }
    }
  }

  if (
    [
      "professional",
      "candidate",
    ].includes(
      identity.profile?.primary_role ??
        "",
    )
  ) {
    const skills = value(
      formData,
      "skills",
    )
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

    const { error } = await supabase
      .from(
        "professional_profiles",
      )
      .update({
        professional_type:
          value(
            formData,
            "professional_type",
          ) ||
          "Animal Health Professional",

        headline:
          value(
            formData,
            "headline",
          ) || null,

        public_summary:
          value(
            formData,
            "public_summary",
          ) || null,

        current_position:
          value(
            formData,
            "current_position",
          ) || null,

        organization_name:
          value(
            formData,
            "organization_name",
          ) || null,

        city: city || null,

        province: province || null,
        district: district || null,
        tehsil: tehsil || null,

        years_experience: Number(
          value(
            formData,
            "years_experience",
          ) || 0,
        ),

        skills,

        profile_visibility:
          value(
            formData,
            "profile_visibility",
          ) ||
          "owner_only",
      })
      .eq(
        "user_id",
        identity.userId,
      );

    if (error) {
      redirect(
        message(
          "error",
          error.message,
        ),
      );
    }
  }

  if (
    identity.profile?.primary_role ===
    "laboratory"
  ) {
    const testsOffered = value(
      formData,
      "tests_offered",
    )
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

    const speciesServed = value(
      formData,
      "species_served",
    )
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

    const { error } = await supabase
      .from("laboratories")
      .update({
        laboratory_name:
          value(
            formData,
            "laboratory_name",
          ),

        laboratory_type:
          value(
            formData,
            "laboratory_type",
          ) ||
          "Diagnostic Laboratory",

        description:
          value(
            formData,
            "description",
          ) || null,

        technical_head:
          value(
            formData,
            "technical_head",
          ) || null,

        city: city || null,

        province: province || null,
        district: district || null,
        tehsil: tehsil || null,

        address:
          value(
            formData,
            "address",
          ) || null,

        public_phone:
          value(
            formData,
            "public_phone",
          ) || null,

        public_email:
          value(
            formData,
            "public_email",
          ) || null,

        website:
          value(
            formData,
            "website",
          ) || null,

        working_hours:
          value(
            formData,
            "working_hours",
          ) || null,

        emergency_service:
          formData.get(
            "emergency_service",
          ) === "on",

        tests_offered:
          testsOffered,

        species_served:
          speciesServed,
      })
      .eq(
        "owner_id",
        identity.userId,
      );

    if (error) {
      redirect(
        message(
          "error",
          error.message,
        ),
      );
    }
  }

  revalidatePath(
    "/dashboard",
  );

  redirect(
    message(
      "message",
      "Profile saved successfully.",
    ),
  );
}
