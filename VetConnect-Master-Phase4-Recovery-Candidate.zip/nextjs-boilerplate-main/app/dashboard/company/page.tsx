import JobCompensationFields from "@/app/components/JobCompensationFields";
import Link from "next/link";
import { redirect } from "next/navigation";
import CareerWorkspaceFrame from "@/app/components/CareerWorkspaceFrame";
import CompanyProfileFields from "@/app/components/CompanyProfileFields";
import type { ManagementContact } from "@/lib/company-profile-editor";
import FormMessage from "../../components/FormMessage";
import FormSubmitButton from "../../components/FormSubmitButton";
import MasterDataInput from "../../components/MasterDataInput";
import JobMasterChoice from "../../components/JobMasterChoice";
import PakistanLocationFields from "../../components/PakistanLocationFields";
import JobTerritoryFields from "../../admin/create/JobTerritoryFields";
import JobSubmissionReceipt from "../../components/JobSubmissionReceipt";
import {
  createJobAction,
  createProductAction,
  deletePendingJobAction,
  deletePendingProductAction,
  updateCompanyProfileAction,
  updateInquiryStatusAction,
} from "./actions";
import {
  getCurrentCompanyWorkspace,
  workspaceHasPermission,
} from "./workspace";

export const dynamic = "force-dynamic";

type CompanyProfileRow = {
  company_name: string;
  legal_name: string | null;
  trade_name: string | null;
  business_type: string | null;
  registration_number: string | null;
  owner_name: string | null;
  chief_executive_name: string | null;
  year_established: number | null;
  country: string | null;
  city: string | null;
  address: string | null;
  description: string | null;
  short_description: string | null;
  website: string | null;
  contact_email: string | null;
  logo_url: string | null;
  cover_image_url: string | null;
  verification_status: string;
  rejection_reason: string | null;
};

type ProductRow = {
  id: string;
  slug: string;
  product_name: string;
  category: string;
  verification_status: string;
  rejection_reason: string | null;
  is_published: boolean;
  created_at: string;
};

type InquiryRow = {
  id: string;
  product_id: string;
  inquiry_type: string;
  contact_name: string;
  contact_email: string;
  contact_phone: string | null;
  organization: string | null;
  message: string;
  status: string;
  created_at: string;
};

type JobRow = {
  id: string;
  slug: string;
  title: string;
  sector: string | null;
  city: string | null;
  province: string | null;
  employment_type: string;
  coverage_display?: string | null;
  verification_status: string;
  is_published: boolean;
  created_at: string;
};

type ApplicationRow = {
  id: string;
  job_id: string;
  candidate_user_id: string;
  status: string;
  applied_at: string;
  cv_document_id?:string|null;
  cv_source?:string|null;
  cv_snapshot?:{full_name?:string;contact_email?:string;phone?:string;headline?:string;education?:string;experience?:string;skills?:string}|null;
};

function roleLabel(role: string) {
  return role
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function permissionLabel(permission: string) {
  return permission
    .replace("company.", "Company: ")
    .replace("products.", "Products: ")
    .replace("jobs.", "Jobs: ")
    .replace("applicants.", "Applicants: ")
    .replace("members.", "Members: ")
    .replace(/_/g, " ");
}

export default async function CompanyDashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; message?: string; submitted?: string; company?: string }>;
}) {
  const params = await searchParams;
  const { supabase, workspace, workspaces } = await getCurrentCompanyWorkspace(params.company);

  const canManageCompany = workspaceHasPermission(workspace, "company.manage");
  const canViewPrivateCompany = workspaceHasPermission(
    workspace,
    "company.view_private",
  );
  const canManageProducts = workspaceHasPermission(workspace, "products.manage");
  const canManageJobs = workspaceHasPermission(workspace, "jobs.manage");
  const canManageApplicants = workspaceHasPermission(
    workspace,
    "applicants.manage",
  );
  const canManageMembers = workspaceHasPermission(workspace, "members.manage");

  let company: CompanyProfileRow | null = null;
  let productRows: ProductRow[] = [];
  let inquiryRows: InquiryRow[] = [];
  let jobRows: JobRow[] = [];
  let applicationRows: ApplicationRow[] = [];


  if (canManageCompany || canViewPrivateCompany) {
    const { data, error } = await supabase
      .from("company_profiles")
      .select(
        "company_name, legal_name, trade_name, business_type, registration_number, owner_name, chief_executive_name, year_established, country, city, address, description, short_description, website, contact_email, logo_url, cover_image_url, verification_status, rejection_reason",
      )
      .eq("user_id", workspace.legacy_company_user_id)
      .maybeSingle();

    if (error) {
      redirect(`/dashboard/company?error=${encodeURIComponent(error.message)}`);
    }

    company = data as CompanyProfileRow | null;
  }

  let canonicalCompany: Record<string, unknown> | null = null;
  let publicPresentation: Record<string, unknown> | null = null;
  let internalContacts: ManagementContact[] = [];
  if (canManageCompany || canViewPrivateCompany) {
    const [canonicalResult, presentationResult, contactResult] = await Promise.all([
      supabase.from("companies").select("canonical_name,legal_name,trade_name,business_type,registration_number,public_email,public_phone,province,district,tehsil,city,address,website,google_maps_url,logo_url,cover_image_url,description").eq("id",workspace.company_id).maybeSingle(),
      supabase.from("company_profile_content").select("*").eq("company_id",workspace.company_id).maybeSingle(),
      supabase.from("company_private_contacts").select("full_name,designation,department,office_phone,mobile_phone,email,reports_to,notes")
        .eq("company_id",workspace.company_id).order("sort_order",{ascending:true}),
    ]);
    if (canonicalResult.error) redirect("/dashboard/company?error="+encodeURIComponent(canonicalResult.error.message));
    if (presentationResult.error || contactResult.error) {
      redirect("/dashboard/company?error=Company%20profile%20migration%20is%20not%20ready.");
    }
    canonicalCompany = canonicalResult.data;
    publicPresentation = presentationResult.data;
    internalContacts = (contactResult.data ?? []) as ManagementContact[];
  }

  if (canManageProducts) {
    const [{ data: products, error: productsError }, { data: inquiries, error: inquiriesError }] =
      await Promise.all([
        supabase
          .from("products")
          .select(
            "id, slug, product_name, category, verification_status, rejection_reason, is_published, created_at",
          )
          .eq("company_user_id", workspace.legacy_company_user_id)
          .order("created_at", { ascending: false }),
        supabase
          .from("product_inquiries")
          .select(
            "id, product_id, inquiry_type, contact_name, contact_email, contact_phone, organization, message, status, created_at",
          )
          .eq("company_user_id", workspace.legacy_company_user_id)
          .order("created_at", { ascending: false }),
      ]);

    if (productsError) {
      redirect(`/dashboard/company?error=${encodeURIComponent(productsError.message)}`);
    }
    if (inquiriesError) {
      redirect(`/dashboard/company?error=${encodeURIComponent(inquiriesError.message)}`);
    }

    productRows = (products ?? []) as ProductRow[];
    inquiryRows = (inquiries ?? []) as InquiryRow[];
  }

  if (canManageJobs) {
    const { data, error } = await supabase
      .from("jobs")
      .select(
        "id, slug, title, sector, city, province, employment_type, verification_status, is_published, created_at",
      )
      .eq("company_id", workspace.company_id)
      .order("created_at", { ascending: false });

    if (error) {
      redirect(`/dashboard/company?error=${encodeURIComponent(error.message)}`);
    }

    jobRows = (data ?? []) as JobRow[];
    if (jobRows.length) {
      const {data: locationRows} = await supabase.from("job_coverage")
        .select("job_id,display_text").in("job_id",jobRows.map(job=>job.id));
      const descriptions = new Map((locationRows ?? []).map(x=>[x.job_id,x.display_text]));
      jobRows = jobRows.map(job=>({...job,coverage_display:descriptions.get(job.id)??null}));
    }
  }

  if (canManageApplicants) {
    const { data: scopedJobs, error: scopedJobsError } = await supabase.from("jobs").select("id").eq("company_id", workspace.company_id);
    if (scopedJobsError) redirect(`/dashboard/company?company=${encodeURIComponent(workspace.company_id)}&error=Unable%20to%20load%20company%20jobs`);
    const scopedJobIds = (scopedJobs ?? []).map(job => job.id);
    if (scopedJobIds.length > 0) {
    const { data, error } = await supabase
      .from("job_applications")
      .select("id, job_id, candidate_user_id, status, applied_at, cv_document_id, cv_source, cv_snapshot")
      .in("job_id", scopedJobIds)
      .order("applied_at", { ascending: false })
      .limit(25);

    if (error) {
      redirect(`/dashboard/company?error=${encodeURIComponent(error.message)}`);
    }

    applicationRows = (data ?? []) as ApplicationRow[];
    }
  }

  const productMap = new Map(
    productRows.map((product) => [product.id, product]),
  );
  const {data:submittedJob} = canManageJobs && params.submitted
    ? await supabase.from("jobs").select("id,title,sector,description,company_id,city,province,employment_type,minimum_qualification,minimum_experience,deadline,verification_status")
       .eq("id",params.submitted).eq("company_id",workspace.company_id).eq("verification_status","pending").maybeSingle()
    : {data:null};
  const {data:submittedCoverage}=submittedJob
    ? await supabase.from("job_coverage").select("display_text").eq("job_id",submittedJob.id).maybeSingle()
    : {data:null};
  const jobMap = new Map(jobRows.map((job) => [job.id, job]));
  const approved = workspace.company_verification_status === "approved";
  const displayName = company?.company_name || workspace.canonical_name;
  const grantedPermissions = workspace.permissions ?? [];
  const hasOperationalAccess =
    canManageCompany ||
    canManageProducts ||
    canManageJobs ||
    canManageApplicants ||
    canManageMembers;

  return (
    <CareerWorkspaceFrame
      active="company" module="company"
      name={displayName}
      headline={[roleLabel(workspace.member_role),workspace.designation].filter(Boolean).join(" · ")}
      photoUrl={company?.logo_url}
      verificationStatus={workspace.company_verification_status}
      title="Manage your company workspace."
      description="An approved organization has its own profile, jobs, products and team permissions. Your personal account stays separate.">
       <div className="vcx-company-body">
          <FormMessage {...params} />
           {workspaces.length>1&&<div className="management-links"><strong>Current company: {workspace.canonical_name}</strong><Link className="button button-secondary" href="/dashboard/company/select">Switch company</Link></div>}
          {submittedJob && <JobSubmissionReceipt closeHref={`/dashboard/company?company=${encodeURIComponent(workspace.company_id)}`}
            job={{id:submittedJob.id,title:submittedJob.title,sector:submittedJob.sector,
              company:workspace.canonical_name,description:submittedJob.description,
              employment_type:submittedJob.employment_type,minimum_qualification:submittedJob.minimum_qualification,
              minimum_experience:submittedJob.minimum_experience,deadline:submittedJob.deadline,
              location:submittedCoverage?.display_text ?? submittedJob.city ?? submittedJob.province ?? "Not specified",
              verification_status:submittedJob.verification_status}}/>}

          <div className="backend-form-card">
            <div className="section-heading">
              <span className="section-kicker">WORKSPACE ACCESS</span>
              <h2>{roleLabel(workspace.member_role)}</h2>
              <p>
                Access is controlled by the approved company membership and
                server-side database permissions.
              </p>
            </div>
            <div className="management-links">
              {workspace.member_role === "owner" ? (
                <span className="status-pill">Owner access</span>
              ) : grantedPermissions.length > 0 ? (
                grantedPermissions.map((permission) => (
                  <span className="status-pill" key={permission}>
                    {permissionLabel(permission)}
                  </span>
                ))
              ) : (
                <span className="status-pill">No operational permissions</span>
              )}
            </div>
          </div>

          {!approved && (
            <div className="setup-notice">
              <h2>Company approval is required.</h2>
              <p>
                Product and job submissions remain unavailable until the
                canonical company record is approved by VetConnect.
              </p>
              {company?.rejection_reason && (
                <p>
                  <b>Review note:</b> {company.rejection_reason}
                </p>
              )}
            </div>
          )}

          {!hasOperationalAccess && (
            <div className="setup-notice">
              <h2>Workspace access is limited.</h2>
              <p>
                Your company membership is active, but no management permission
                has been assigned to this account.
              </p>
            </div>
          )}

          <nav className="vc-customer-shortcuts" aria-label="Company workspace sections">
  {canManageCompany && <a href="#company-details">Company profile</a>}
  {canManageProducts && <a href="#company-products">Products & inquiries</a>}
  {canManageJobs && <a href="#company-jobs">Job postings</a>}
  {canManageApplicants && <a href="#company-applications">Applications</a>}
  {canManageMembers && <a href="#company-team">Team access</a>}
</nav>
<div className="admin-summary company-summary vc-company-metrics">
            {canManageProducts && (
              <>
                <article>
                  <a className="vc-metric-link" href="#company-products"><b>{productRows.length}</b><span>Total products</span></a>
                </article>
                <article>
                  <b>
                    {
                      productRows.filter(
                        (item) => item.verification_status === "approved",
                      ).length
                    }
                  </b>
                  <span>Approved products</span>
                </article>
                <article>
                  <a className="vc-metric-link" href="#company-products"><b>{inquiryRows.length}</b><span>Information requests</span></a>
                </article>
              </>
            )}
            {canManageJobs && (
              <article>
                <a className="vc-metric-link" href="#company-jobs"><b>{jobRows.length}</b><span>Job posts</span></a>
              </article>
            )}
            {canManageApplicants && (
              <article>
                <a className="vc-metric-link" href="#company-applications"><b>{applicationRows.length}</b><span>Recent applications</span></a>
              </article>
            )}
          </div>

          {canManageCompany && (
            <div id="company-details" className="backend-form-card vc-review-target">
              <form action={updateCompanyProfileAction}>
                <input type="hidden" name="company_id" value={workspace.company_id}/>
                <CompanyProfileFields mode="company-edit"
                  initial={{...(company ?? {}),...(canonicalCompany ?? {}),
                    company_name:company?.company_name ?? workspace.canonical_name,
                    contact_email:company?.contact_email ?? canonicalCompany?.public_email ?? "",
                    description:canonicalCompany?.description ?? company?.description ?? "",
                    year_established:company?.year_established ?? ""}}
                  presentation={publicPresentation}
                  contacts={internalContacts}/>
                <div className="vc-company-export-actions">
                  <FormSubmitButton pendingLabel="Saving company...">Save company profile</FormSubmitButton>
                  <Link className="button button-secondary" href={"/dashboard/company/export?company="+encodeURIComponent(workspace.company_id)}>Internal PDF / print profile</Link>
                </div>
              </form>
            </div>
          )}

          {canManageProducts && (
            <div className="company-workspace-grid">
              <form className="backend-form-card" action={createProductAction}><input type="hidden" name="company_id" value={workspace.company_id} />
                <div className="section-heading">
                  <span className="section-kicker">PRODUCT SUBMISSION</span>
                  <h2>Add a structured product.</h2>
                  <p>Every submission stays pending until administrator approval.</p>
                </div>
                <fieldset disabled={!approved}>
                  <div className="form-grid">
                    <div><label htmlFor="product_name">Product name</label><input id="product_name" name="product_name" required /></div>
                    <MasterDataInput category="product_category" name="category" label="Category" required allowCustom={false} />
                    <div><label htmlFor="brand_name">Brand</label><input id="brand_name" name="brand_name" /></div>
                    <div><label htmlFor="generic_name">Generic name</label><input id="generic_name" name="generic_name" /></div>
                    <div><label htmlFor="product_code">Product code / SKU</label><input id="product_code" name="product_code" /></div>
                    <div><label htmlFor="subclass">Product subclass</label><input id="subclass" name="subclass" placeholder="Live vaccine, feed additive..." /></div>
                    <div><label htmlFor="therapeutic_class">Therapeutic / functional class</label><input id="therapeutic_class" name="therapeutic_class" /></div>
                    <MasterDataInput category="veterinary_sector" name="sectors" label="Primary sector" />
                    <div><label htmlFor="species">Species</label><input id="species" name="species" placeholder="Chicken, cattle, buffalo" /></div>
                    <div><label htmlFor="production_systems">Production systems</label><input id="production_systems" name="production_systems" placeholder="Broiler, layer, breeder" /></div>
                    <div><label htmlFor="use_areas">Disease / use areas</label><input id="use_areas" name="use_areas" placeholder="Respiratory disease, gut health" /></div>
                    <MasterDataInput category="administration_route" name="routes" label="Administration route" />
                    <MasterDataInput category="product_dosage_form" name="dosage_form" label="Dosage / product form" />
                    <div><label htmlFor="strength">Strength</label><input id="strength" name="strength" /></div>
                    <MasterDataInput category="product_presentation" name="presentation" label="Presentation" />
                    <MasterDataInput category="product_packaging" name="packaging_type" label="Packaging type" />
                    <div><label htmlFor="pack_size_value">Pack size value</label><input id="pack_size_value" name="pack_size_value" placeholder="100 / 500 / 1000" /></div>
                    <MasterDataInput category="product_packaging" name="pack_size_unit" label="Pack size unit" />
                    <MasterDataInput category="vaccine_type" name="vaccine_type" label="Vaccine type (if applicable)" />
                    <div><label htmlFor="concentration_value">Concentration</label><input id="concentration_value" name="concentration_value" placeholder="10 / 20 / 100" /></div>
                    <MasterDataInput category="concentration_unit" name="concentration_unit" label="Concentration unit" />
                    <MasterDataInput category="administration_route" name="administration_route" label="Administration route" />
                    <div><label htmlFor="pack_sizes">Pack sizes</label><input id="pack_sizes" name="pack_sizes" placeholder="100 ml, 500 ml" /></div>
                    <div className="form-span-2"><label htmlFor="composition">Composition</label><textarea id="composition" name="composition" /></div>
                    <div className="form-span-2"><label htmlFor="indications">Indications / intended use</label><textarea id="indications" name="indications" /></div>
                    <div className="form-span-2"><label htmlFor="precautions">Precautions</label><textarea id="precautions" name="precautions" /></div>
                    <div><label htmlFor="contraindications">Contraindications</label><textarea id="contraindications" name="contraindications" /></div>
                    <div><label htmlFor="warnings">Warnings</label><textarea id="warnings" name="warnings" /></div>
                    <div><label htmlFor="meat_withdrawal">Meat withdrawal</label><input id="meat_withdrawal" name="meat_withdrawal" /></div>
                    <div><label htmlFor="milk_withdrawal">Milk withdrawal</label><input id="milk_withdrawal" name="milk_withdrawal" /></div>
                    <div><label htmlFor="egg_withdrawal">Egg withdrawal</label><input id="egg_withdrawal" name="egg_withdrawal" /></div>
                    <div className="form-span-2"><label htmlFor="description">Public description</label><textarea id="description" name="description" required /></div>
                    <div className="form-span-2"><label htmlFor="storage_instructions">Storage instructions</label><input id="storage_instructions" name="storage_instructions" /></div>
                    <div><label htmlFor="temperature_range">Temperature range</label><input id="temperature_range" name="temperature_range" /></div>
                    <div><label htmlFor="shelf_life">Shelf life</label><input id="shelf_life" name="shelf_life" /></div>
                    <div><label htmlFor="country_of_origin">Country of origin</label><input id="country_of_origin" name="country_of_origin" /></div>
                    <label className="checkbox-line"><input type="checkbox" name="cold_chain" /> Cold chain required</label>
                    <div><label htmlFor="regulatory_number">Regulatory reference</label><input id="regulatory_number" name="regulatory_number" /></div>
                    <div><label htmlFor="availability">Availability</label><input id="availability" name="availability" placeholder="In stock / contact company" /></div>
                    <div className="form-span-2"><label htmlFor="image_url">Public image URL</label><input id="image_url" name="image_url" type="url" placeholder="https://..." /></div>
                  </div>
                  <FormSubmitButton pendingLabel="Submitting product...">Submit for approval</FormSubmitButton>
                </fieldset>
              </form>

              <div className="backend-form-card product-management">
                <div className="section-heading">
                  <span id="company-products" className="section-kicker vc-review-target">MY PRODUCTS</span>
                  <h2>Approval status.</h2>
                </div>
                {productRows.length === 0 ? (
                  <div className="empty-state"><p>No products submitted yet.</p></div>
                ) : (
                  <div className="management-list">
                    {productRows.map((product) => (
                      <article key={product.id}>
                        <div>
                          <span className={`status-pill status-${product.verification_status}`}>{product.verification_status}</span>
                          <h3>{product.product_name}</h3>
                          <p>{product.category}</p>
                          {product.rejection_reason && <small>{product.rejection_reason}</small>}
                        </div>
                        <div className="management-links">
                          <Link href={`/dashboard/company/products/${product.id}?company=${encodeURIComponent(workspace.company_id)}`}>Edit</Link>
                          {product.verification_status === "approved" ? (
                            <Link href={`/marketplace/${product.slug}`}>View listing</Link>
                          ) : (
                            <form action={deletePendingProductAction}><input type="hidden" name="company_id" value={workspace.company_id} />
                              <input type="hidden" name="product_id" value={product.id} />
                              <button className="text-button" type="submit">Remove</button>
                            </form>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {canManageJobs && (
            <div className="company-workspace-grid">
              <form className="backend-form-card" action={createJobAction}><input type="hidden" name="company_id" value={workspace.company_id} />
                <div className="section-heading">
                  <span className="section-kicker">JOB POSTING</span>
                  <h2>Publish a structured opportunity.</h2>
                  <p>Every vacancy remains pending until administrator approval.</p>
                </div>
                <fieldset disabled={!approved}>
                  <div className="form-grid">
                    <div><label htmlFor="title">Job title</label><input id="title" name="title" required /></div>
                    <JobCompensationFields/><MasterDataInput category="employment_type" name="employment_type" label="Employment type" defaultValue="" allowCustom />
                    <JobMasterChoice category="job_sector" name="job_sector" label="Job sector" />
                    <JobTerritoryFields />
                    <JobMasterChoice category="job_qualification" name="minimum_qualification" label="Minimum qualification" />
                    <div><label htmlFor="minimum_experience">Minimum experience</label><input id="minimum_experience" name="minimum_experience" type="number" min="0" /></div>
                    <div><label htmlFor="deadline">Application deadline</label><input id="deadline" name="deadline" type="date" /></div>
                    <div className="form-span-2"><label htmlFor="job_description">Job description and requirements</label><textarea id="job_description" name="job_description" required /></div>
                  </div>
                  <div className="form-span-2"><label htmlFor="company_job_ad_image">Original job advertisement image (optional)</label>
     <input id="company_job_ad_image" name="job_ad_image" type="file" accept="image/jpeg,image/png,image/webp" />
     <p className="form-help">JPG, PNG or WebP up to 5 MB. Visible to the public only after approval.</p>
   </div>
   <FormSubmitButton pendingLabel="Submitting job...">Submit for approval</FormSubmitButton>
                </fieldset>
              </form>

              <div className="backend-form-card product-management">
                <div className="section-heading"><span id="company-jobs" className="section-kicker vc-review-target">MY JOBS</span><h2>Recruitment status.</h2></div>
                {jobRows.length === 0 ? (
                  <div className="empty-state"><p>No jobs submitted yet.</p></div>
                ) : (
                  <div className="management-list">
                    {jobRows.map((job) => (
                      <article key={job.id}>
                        <div>
                          <span className={`status-pill status-${job.verification_status}`}>{job.verification_status}</span>
                          <h3>{job.title}</h3>
                          <p>{job.sector || "Animal health"} · {job.coverage_display || job.city || job.province || "Location not specified"} · {job.employment_type}</p>
                        </div>
                        {job.verification_status === "approved" ? (
                          <Link href={`/jobs/${job.slug}`}>View listing</Link>
                        ) : (
                          <form action={deletePendingJobAction}><input type="hidden" name="company_id" value={workspace.company_id} />
                            <input type="hidden" name="job_id" value={job.id} />
                            <button className="text-button" type="submit">Remove</button>
                          </form>
                        )}
                      </article>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {canManageProducts && (
            <div className="backend-form-card inquiry-panel">
              <div className="section-heading">
                <span className="section-kicker">CUSTOMER REQUESTS</span>
                <h2>Product inquiries and quotations.</h2>
              </div>
              {inquiryRows.length === 0 ? (
                <div className="empty-state"><p>No product inquiries yet.</p></div>
              ) : (
                <div className="inquiry-grid">
                  {inquiryRows.map((inquiry) => (
                    <article key={inquiry.id}>
                      <div className="review-header">
                        <div>
                          <span className="module-tag">{inquiry.inquiry_type}</span>
                          <h3>{productMap.get(inquiry.product_id)?.product_name || "Product inquiry"}</h3>
                        </div>
                        <span className="status-pill">{inquiry.status}</span>
                      </div>
                      <p><b>{inquiry.contact_name}</b> · {inquiry.contact_email}</p>
                      {inquiry.contact_phone && <p>{inquiry.contact_phone}</p>}
                      {inquiry.organization && <p>{inquiry.organization}</p>}
                      <p>{inquiry.message}</p>
                      <form className="inline-status-form" action={updateInquiryStatusAction}><input type="hidden" name="company_id" value={workspace.company_id} />
                        <input type="hidden" name="inquiry_id" value={inquiry.id} />
                        <select name="status" defaultValue={inquiry.status === "new" ? "reviewing" : inquiry.status}>
                          <option value="reviewing">Reviewing</option>
                          <option value="responded">Responded</option>
                          <option value="closed">Closed</option>
                        </select>
                        <button className="button button-secondary" type="submit">Update</button>
                      </form>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}

          {canManageApplicants && (
            <div className="backend-form-card product-management">
              <div className="section-heading">
                <span id="company-applications" className="section-kicker vc-review-target">APPLICANTS</span>
                <h2>Recent applications.</h2>
                <p>
                  Applicant visibility is enforced by the canonical
                  applicants.manage permission. Status-changing controls are not
                  exposed here because the current database policy only grants
                  employer-side read access.
                </p>
              </div>
              {applicationRows.length === 0 ? (
                <div className="empty-state"><p>No applications are available yet.</p></div>
              ) : (
                <div className="management-list">
                  {applicationRows.map((application) => (
                    <article key={application.id}>
                      <div>
                        <span className="status-pill">{application.status}</span>
                        <h3>{jobMap.get(application.job_id)?.title || "Job application"}</h3>
                        <p>Candidate reference: {application.candidate_user_id}</p>
                        <small>Applied {new Date(application.applied_at).toLocaleDateString("en-PK")}</small>
                        {application.cv_document_id&&<p><a href={"/api/career/documents/"+application.cv_document_id}
                          target="_blank" rel="noopener noreferrer">View candidate-submitted CV ↗</a></p>}
                        {application.cv_source==="profile_cv" && application.cv_snapshot&&
                          <details><summary>View submitted profile CV</summary>
                            <p><strong>{application.cv_snapshot.full_name}</strong> · {application.cv_snapshot.headline}</p>
                            <p>{[application.cv_snapshot.contact_email,application.cv_snapshot.phone].filter(Boolean).join(" · ")}</p>
                            <p className="cv-preserve-lines">{application.cv_snapshot.education}</p>
                            <p className="cv-preserve-lines">{application.cv_snapshot.experience}</p>
                            <p className="cv-preserve-lines">{application.cv_snapshot.skills}</p>
                          </details>}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}


          {canManageMembers && (
            <div className="backend-form-card">
              <div className="section-heading">
                <span id="company-team" className="section-kicker vc-review-target">TEAM ACCESS</span>
                <h2>Company member management is enabled.</h2>
                <p>
                  The database already protects member invitations and permission
                  changes. A dedicated team-management screen can be added without
                  changing the company security model.
                </p>
              </div>
            </div>
          )}

       </div>
    </CareerWorkspaceFrame>
  );
}
