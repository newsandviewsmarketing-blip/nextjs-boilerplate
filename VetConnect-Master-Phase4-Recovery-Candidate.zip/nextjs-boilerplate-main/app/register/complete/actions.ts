"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { persistRegisteredCategoryDetails, registrationDraftMetadata } from "@/lib/registration-persistence";
import {
  REGISTRATION_EVIDENCE_BUCKET,
  isAcceptedEvidenceFile,
  registrationEvidenceRequirements,
} from "@/lib/registration-evidence";
import { notifyRegistrationSubmitted } from "@/lib/registration-notifications";

const safeName = (name: string) => name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100) || "evidence";
function signatureMatches(type: string, b: Uint8Array): boolean {
  if (type === "application/pdf") return b.length >= 4 && b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46;
  if (type === "image/jpeg") return b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
  if (type === "image/png") return b.length >= 8 && b.slice(0, 8).join(",") === "137,80,78,71,13,10,26,10";
  if (type === "image/webp") return b.length >= 12 && String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP";
  return false;
}
async function currentRegistration() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) redirect("/login?next=/register/complete");
  const [{ data: profile }, { data: gate }, details] = await Promise.all([
    supabase.from("profiles").select("primary_role").eq("id", data.user.id).maybeSingle(),
    supabase.from("registration_completion_gate").select("registration_intent,student_track,review_status,completed_at").eq("user_id", data.user.id).maybeSingle(),
    supabase.from("registration_profile_details").select("category_details").eq("user_id", data.user.id).maybeSingle(),
  ]);
  if (!profile?.primary_role || !gate || details.error) redirect("/register/complete?error=Registration%20record%20not%20found.");
  if (gate.review_status === "approved") redirect("/dashboard");
  if (gate.completed_at && gate.review_status === "pending") redirect("/register/status");
  return { supabase, user: data.user, role: profile.primary_role, gate, metadata: registrationDraftMetadata(data.user.user_metadata,details.data?.category_details) };
}

export async function saveRegistrationEvidenceDraftAction(formData: FormData) {
  const { supabase, user, role, gate } = await currentRegistration();
  const type = String(formData.get("type") ?? ""), path = String(formData.get("path") ?? "");
  const filename = safeName(String(formData.get("filename") ?? ""));
  const requirements = registrationEvidenceRequirements(role, gate.registration_intent, gate.student_track);
  const allowed = new Set(requirements.map(item => item.type));
  if (!allowed.has(type) || !path.startsWith(user.id + "/") || !filename) throw new Error("This file does not match your registration.");
  const requirement = requirements.find((item) => item.type === type);
  const { data: blob, error: downloadError } = await supabase.storage.from(REGISTRATION_EVIDENCE_BUCKET).download(path);
  if (downloadError || !blob) throw new Error("The private upload could not be verified.");
  const contentType = blob.type.toLowerCase();
  const imageOnly = Boolean(requirement?.imageOnly);
  if (!isAcceptedEvidenceFile(contentType, blob.size, imageOnly)) {
    throw new Error(imageOnly ? "Profile photos and company logos must be JPG, PNG or WebP and no larger than 5 MB." : "Documents must be PDF, JPG, PNG or WebP and no larger than 8 MB.");
  }
  if (!signatureMatches(contentType, new Uint8Array(await blob.arrayBuffer()))) throw new Error("The file contents do not match its file type.");
  const { error } = await supabase.from("registration_evidence").insert({
    user_id: user.id, document_type: type, storage_path: path,
    original_filename: filename, content_type: contentType, file_size: blob.size, verification_status: "draft",
  });
  if (error) throw new Error("Your draft document could not be saved. Please retry.");
  revalidatePath("/register/complete");
}

export async function completeRegistrationAction() {
  const { supabase, user, role, metadata } = await currentRegistration();
  if(role==="veterinarian" && !String(metadata.pvmc_number??"").trim()) redirect("/register/complete?error="+encodeURIComponent("Your education draft is saved. Add your PVMC number and evidence before submitting for practitioner verification."));
  const { data: profile } = await supabase.from("profiles").select("primary_role").eq("id", user.id).maybeSingle();
  const issue = await persistRegisteredCategoryDetails(supabase, user.id, user.user_metadata);
  if (issue) redirect("/register/complete?error=" + encodeURIComponent(issue));
  const { error } = await supabase.rpc("complete_registration_submission");
  if (error) redirect("/register/complete?error=" + encodeURIComponent(error.message));
  await supabase.auth.updateUser({ data: { registration_details_pending: false } });
  await notifyRegistrationSubmitted({ email: user.email ?? "", name: String(user.user_metadata?.full_name ?? user.user_metadata?.organization_name ?? user.email ?? "New registrant"), category: String(profile?.primary_role ?? "member"), userId: user.id });
  redirect("/register/status");
}

export async function saveRegistrationProfileDraftAction(formData: FormData) {
  const { supabase, user, role, metadata: savedMetadata } = await currentRegistration();
  if (!["veterinarian", "candidate", "professional"].includes(role)) throw new Error("This category does not use a professional experience draft.");
  const draft: Record<string, string> = {};
  for (const key of ["current_designation", "current_workplace", "professional_summary", "experience_years"]) {
    const value = String(formData.get(key) ?? "").trim();
    const limit = key === "professional_summary" ? 250 : 180;
    if (value.length > limit || /[<>\u0000-\u001f]/.test(value)) redirect("/register/complete?error=Please%20check%20your%20professional%20details.");
    draft[key] = value;
  }
  if (draft.experience_years && (!/^\d{1,2}$/.test(draft.experience_years) || Number(draft.experience_years) > 80)) redirect("/register/complete?error=Experience%20must%20be%20a%20whole%20number%20from%200%20to%2080.");
  if(role==="veterinarian"){
    const number=String(formData.get("pvmc_number")??savedMetadata.pvmc_number??"").trim();
    const pending=formData.get("pvmc_number_pending")==="true";
    if(number && (number.length>70 || !/^[a-z0-9\s/\\_.-]+$/i.test(number)))redirect("/register/complete?error=Check%20your%20PVMC%20number.");
    if(!number&&!pending)redirect("/register/complete?error=Enter%20your%20PVMC%20number%20or%20mark%20it%20as%20pending.");
    draft.pvmc_number=number;draft.pvmc_number_pending=number?"false":"true";
  }
  const metadata = { ...savedMetadata, ...draft };
  const issue = await persistRegisteredCategoryDetails(supabase, user.id, metadata, {replaceSavedDetails:true});
  if (issue) redirect("/register/complete?error="+encodeURIComponent(issue));
  const { error } = await supabase.auth.updateUser({ data: draft });
  if (error) redirect("/register/complete?message="+encodeURIComponent("Professional draft saved. Account synchronization is delayed; your saved details will be used when you return."));
  revalidatePath("/register/complete");
  redirect("/register/complete?message=Professional%20draft%20saved.");
}
