import { uniqueCities, matchesCity } from "@/lib/city-normalization";
import type { Metadata } from "next";
import Link from "next/link";
import SiteHeader from "../components/SiteHeader";
import SiteFooter from "../components/SiteFooter";
import JobPosterThumbnail from "../components/JobPosterThumbnail";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { createClient } from "@/lib/supabase/server";
import { type PublicJob } from "@/lib/jobs";
import { matchesJobLocation } from "@/lib/job-location";

export const metadata: Metadata = {
  title: "Veterinary Jobs in Pakistan",
  description: "Find veterinary, livestock, poultry, dairy, animal-health, feed and allied jobs in Pakistan.",
  alternates: { canonical: "/jobs" },
  openGraph: {
    title: "Veterinary & Animal Health Jobs in Pakistan | VetConnect",
    description: "Find current veterinary, poultry, livestock, dairy, feed and animal-health opportunities across Pakistan.",
    url: "/jobs",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Veterinary & Animal Health Jobs in Pakistan",
    description: "Browse current veterinary and animal-health employment opportunities on VetConnect Pakistan.",
  },
};

export const dynamic = "force-dynamic";

async function loadJobs(): Promise<PublicJob[]> {
  if (!isSupabaseConfigured()) return [];
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("public_jobs")
    .select("id, slug, title, description, sector, city, province, district, tehsil, address, employment_type, minimum_qualification, minimum_experience, deadline, company_user_id, company_id, company_name")
    .order("deadline", { ascending: true, nullsFirst: false });
  if (error || !data?.length) return [];
  const {data:categories}=await supabase.from("master_data_items").select("label")
    .eq("category","job_sector").eq("is_active",true);
  const valid=new Set((categories??[]).map(x=>x.label.toLowerCase()));
  const today=new Date().toISOString().slice(0,10);
  const open=data.filter(x=>!x.deadline||x.deadline>=today);
  if(!open.length)return [];
  const ids = open.map(job => job.id).filter(Boolean) as string[];
  const [{data: coverage}, {data: areas}, {data: posted,error:mediaError}] = await Promise.all([
    supabase.from("job_coverage").select("job_id,scope,province,display_text").in("job_id",ids),
    supabase.from("job_coverage_areas").select("job_id,label,city,district,province").in("job_id",ids),
    supabase.from("jobs").select("id,created_at,advert_image_path,advert_image_mime,is_published,verification_status").in("id",ids)
  ]);
  const created = new Map((posted??[]).map(row=>[row.id,row.created_at]));
  const media = new Map((mediaError?[]:(posted??[])).map(row=>[row.id,
    Boolean(row.advert_image_path && row.is_published && row.verification_status==="approved" &&
      ["image/jpeg","image/png","image/webp"].includes(row.advert_image_mime??""))]));
  return open.sort((a,b)=>String(created.get(b.id)||"").localeCompare(String(created.get(a.id)||""))).map(job => ({
    ...job,
    sector: job.sector && valid.has(job.sector.trim().toLowerCase()) ? job.sector.trim() : "Sector pending classification",
    coverage: coverage?.find(c => c.job_id===job.id) ?? null,
    coverage_areas: areas?.filter(a => a.job_id===job.id) ?? [],
    image_available: media.get(job.id)??false
  })) as PublicJob[];
}

export default async function JobsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; city?: string; sector?: string; page?: string }>;
}) {
  const params = await searchParams;
  const jobs = await loadJobs();
  const query = (params.q ?? "").trim().toLowerCase();
  const hasFilters = Boolean(query || (params.city && params.city !== "All cities") || (params.sector && params.sector !== "All sectors"));
  const visibleJobs = jobs.filter(
    job => (!query || 
      [job.title,job.company_name,job.sector ?? "",job.coverage?.display_text ?? ""].join(" ").toLowerCase().includes(query)) &&
      matchesJobLocation(job, params.city ?? "") &&
      (!params.sector || params.sector==="All sectors" || job.sector===params.sector),
  );
  const requestedPage = Math.max(1,Math.min(100,Number.parseInt(params.page??"1",10)||1));
  const pageSize = 10;
  const pages = Math.max(1,Math.ceil(visibleJobs.length/pageSize));
  const page = Math.min(requestedPage,pages);
  const shownJobs = visibleJobs.slice((page-1)*pageSize,page*pageSize);
  const pageUrl=(next:number)=>"/jobs?"+new URLSearchParams({...(params.q?{q:params.q}:{}),...(params.city&&params.city!=="All cities"?{city:params.city}:{}),...(params.sector&&params.sector!=="All sectors"?{sector:params.sector}:{}),page:String(next)}).toString()+"#jobs";
  const cities = uniqueCities([
    ...jobs.flatMap(job => [job.city, job.coverage?.province, ...(job.coverage_areas?.map(a=>a.city || a.district || a.label) ?? [])]),
  ]);
  const sectors=[...new Set(jobs.map(j=>j.sector).filter((x):x is string=>Boolean(x)))].sort();
  const preferredSectors=["Poultry","Dairy","Livestock","Sales & Marketing","Veterinary Services","Feed & Nutrition","Pharmaceutical / Industry","Animal Health","Fisheries / Aquaculture","Academia / Research","Laboratory / Diagnostics","Pets / Companion Animals","Agriculture","Food Safety","Wildlife / Conservation"];
  const browseSectors=[...new Set([...preferredSectors,...sectors])];
  return (
    <main>
      <SiteHeader />
      <section className="page-hero jobs-hero">
        <div className="shell">
          <span className="section-kicker">VETERINARY JOBS & TALENT</span>
          <h1>Connect employers with the right veterinary talent.</h1>
          <p>
            Designed for animal-health companies, clinics, farms, universities,
            research teams, NGOs, students and experienced professionals.
          </p>
          <div className="hero-actions">
            <Link className="button button-primary" href="#jobs">
              Find jobs
            </Link>
            <Link
              className="button button-secondary"
              href={"/login?next=" + encodeURIComponent("/dashboard/company")}
            >
              Post a job
            </Link>
          </div>
        </div>
      </section>
      <section className="section compact-section">
        <div className="shell role-grid">
          <article>
            <span className="module-tag">EMPLOYER / HR</span>
            <h2>Recruitment workspace</h2>
            <ul>
              <li>Create a verified company/employer profile</li>
              <li>Post jobs and internships by sector, region and selected locations</li>
              <li>Define qualification, experience and skill requirements</li>
              <li>Search candidate profiles and CVs</li>
              <li>Shortlist and track applications</li>
            </ul>
            <Link
              href="/register?role=company#registration"
              className="button button-dark"
            >
              Register as employer
            </Link>
          </article>
          <article>
            <span className="module-tag">CANDIDATE</span>
            <h2>Professional career profile</h2>
            <ul>
              <li>Upload CV and create a structured profile</li>
              <li>Add education, PVMC information, experience and skills</li>
              <li>Select preferred sectors, roles and locations</li>
              <li>Discover matching jobs and internships</li>
              <li>Track saved jobs and applications</li>
            </ul>
            <Link
              href="/register?role=candidate#registration"
              className="button button-primary"
            >
              Create candidate profile
            </Link>
          </article>
        </div>
      </section>
      <section id="jobs" className="section section-soft">
        <div className="shell">
          <div className="directory-top">
            <div>
              <b>{visibleJobs.length} opportunities · Latest first</b>
              <span>Approved employer vacancies currently open for applications</span>
            </div>
            <form className="market-search" method="get">
              <label className="builder-sr-only" htmlFor="jobs-search-query">Search by job title or company</label>
              <input
                id="jobs-search-query"
                name="q"
                defaultValue={params.q ?? ""}
                placeholder="Search role or company"
              />
              <label className="builder-sr-only" htmlFor="jobs-search-city">Location</label>
              <select id="jobs-search-city" name="city" defaultValue={params.city ?? "All cities"}>
                <option>All cities</option>
                {cities.map((city) => <option key={city}>{city}</option>)}
              </select>
              <label className="builder-sr-only" htmlFor="jobs-search-sector">Job sector</label>
              <select id="jobs-search-sector" name="sector" defaultValue={params.sector??"All sectors"}>
                <option>All sectors</option>
                {sectors.map(sector=><option key={sector}>{sector}</option>)}
              </select>
              <button className="button button-primary" type="submit">
                Search
              </button>
            </form>
          </div>
          {visibleJobs.length === 0 ? (
            <div className="empty-state">
              <h2>{hasFilters ? "No jobs match your search." : "No current vacancies are listed."}</h2>
              <p>{hasFilters ? "Try removing a filter or searching another role or location." : "Employers can submit vacancies through their verified company workspace. Please check again for new opportunities."}</p>
              {hasFilters ? <Link href="/jobs#jobs">Clear filters</Link> : <Link href="/login?next=%2Fdashboard%2Fcompany">Employer: post a job</Link>}
            </div>
          ) : (
            <div className="job-board">
              {shownJobs.map((job) => (
                <article key={job.slug}>
                  <JobPosterThumbnail
                    id={job.id} slug={job.slug} title={job.title}
                    company={job.company_name} available={Boolean(job.image_available)}
                  />
                  <div className="job-main">
                    <span>{job.sector || "Animal health"}</span>
                    <h3>{job.title}</h3>
                    <p>
                      {job.company_name} • {job.coverage?.display_text || job.city || job.province || "Pakistan"}
                    </p>
                    <div className="profile-chips">
                      <span>{job.employment_type}</span>
                      <span>Employer vacancy</span>
                    </div>
                  </div>
                  <div className="job-apply">
                    <small>{job.deadline?"Apply by "+job.deadline:"Open vacancy"}</small>
                    <Link
                      className="button button-primary"
                      href={`/jobs/${job.slug}`}
                    >
                      View & apply
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          )}
          {visibleJobs.length>pageSize&&<nav aria-label="Job results pages" className="job-sector-filters">
            {page>1&&<Link className="button button-secondary" href={pageUrl(page-1)}>Previous</Link>}
            <span>Page {page} of {pages}</span>
            {page<pages&&<Link className="button button-secondary" href={pageUrl(page+1)}>Next 10 jobs</Link>}
          </nav>}
          <div className="section-heading compact-heading" id="jobs-by-sector">
            <span className="section-kicker">EXPLORE BY SPECIALTY</span>
            <h2>Browse jobs by sector</h2>
            <p>Choose Poultry, Dairy, Livestock, Marketing or another field to view relevant vacancies.</p>
          </div>
          <nav className="job-sector-filters" aria-label="Browse jobs by sector">
            <Link href="/jobs#jobs" className="job-sector-pill">All sectors ({jobs.length})</Link>
            {browseSectors.map(name=><Link key={name} className={"job-sector-pill"+(params.sector===name?" active":"")} href={"/jobs?sector="+encodeURIComponent(name)+"#jobs"}>{name} ({jobs.filter(j=>j.sector===name).length})</Link>)}
          </nav>
        </div>
      </section>
      <section className="section">
        <div className="shell">
          <div className="section-heading">
            <span className="section-kicker">MATCHING LOGIC</span>
            <h2>Build a career profile and explore opportunities.</h2>
            <p>
              Browse current job advertisements, create your professional profile and manage your applications in your account.
            </p>
          </div>
          <div className="feature-columns">
            <div>
              <h3>Profile data</h3>
              <p>
                Education, discipline, graduation year, PVMC status, experience,
                skills, certifications and CV.
              </p>
            </div>
            <div>
              <h3>Job data</h3>
              <p>
                Role, sector, location, employment type, education, experience,
                skills and deadline.
              </p>
            </div>
            <div>
              <h3>Matching</h3>
              <p>
                Rank opportunities using sector, qualification, skills, location
                and experience.
              </p>
            </div>
            <div>
              <h3>Career pipeline</h3>
              <p>
                Saved jobs, applications, shortlist status, interview stage and
                communication.
              </p>
            </div>
          </div>
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
