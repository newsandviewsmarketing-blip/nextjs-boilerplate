import "./marketplace.css";
import { uniqueCities, matchesCity } from "@/lib/city-normalization";
import type { Metadata } from "next";
import Link from "next/link";
import SiteHeader from "../components/SiteHeader";
import SiteFooter from "../components/SiteFooter";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { createClient } from "@/lib/supabase/server";
import {
  productCategories,
  productMark,
  type PublicProduct,
} from "@/lib/marketplace";

export const metadata: Metadata = {
  title: "Veterinary Product Directory Pakistan",
  description: "Browse approved veterinary medicines, vaccines, feed, nutrition, diagnostics, equipment and animal-health product information.",
  alternates: { canonical: "/marketplace" },
};

export const dynamic = "force-dynamic";

async function loadProducts() {
  if (!isSupabaseConfigured()) return [];
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("verification_status", "approved")
    .eq("is_published", true)
    .order("created_at", { ascending: false });
  if (!data?.length) return [];
  const canonicalIds = [...new Set(data.map((row) => row.company_id).filter(Boolean))] as string[];
  const legacyIds = [...new Set(data.map((row) => row.company_user_id).filter(Boolean))] as string[];
  const [{ data: canonicalCompanies }, { data: legacyCompanies }] = await Promise.all([
    canonicalIds.length
      ? supabase.from("public_company_directory").select("id, user_id, company_name, city").in("id", canonicalIds)
      : Promise.resolve({ data: [] }),
    legacyIds.length
      ? supabase.from("public_companies").select("user_id, company_name, city").in("user_id", legacyIds)
      : Promise.resolve({ data: [] }),
  ]);
  const canonicalMap = new Map((canonicalCompanies ?? []).map((company) => [company.id, company]));
  const legacyMap = new Map((legacyCompanies ?? []).map((company) => [company.user_id, company]));
  return data.map((row): PublicProduct => {
    const company = (row.company_id ? canonicalMap.get(row.company_id) : null) ?? legacyMap.get(row.company_user_id);
    return {
      id: row.id,
      slug: row.slug,
      product_name: row.product_name,
      brand_name: row.brand_name,
      generic_name: row.generic_name,
      category: row.category,
      sector: row.sector,
      composition: row.composition,
      strength: row.strength,
      dosage_form: row.dosage_form,
      pack_sizes: row.pack_sizes ?? [],
      indications: row.indications,
      description: row.description,
      storage_instructions: row.storage_instructions,
      image_url: row.image_url,
      availability: row.availability,
      product_code: row.product_code,
      subclass: row.subclass,
      therapeutic_class: row.therapeutic_class,
      sectors: row.sectors ?? [],
      species: row.species ?? [],
      production_systems: row.production_systems ?? [],
      use_areas: row.use_areas ?? [],
      routes: row.routes ?? [],
      precautions: row.precautions,
      contraindications: row.contraindications,
      warnings: row.warnings,
      meat_withdrawal: row.meat_withdrawal,
      milk_withdrawal: row.milk_withdrawal,
      egg_withdrawal: row.egg_withdrawal,
      cold_chain: row.cold_chain,
      temperature_range: row.temperature_range,
      shelf_life: row.shelf_life,
      country_of_origin: row.country_of_origin,
      regulatory_review_status: row.regulatory_review_status,
      company_user_id: row.company_user_id,
      company_id: row.company_id,
      company_name: company?.company_name ?? "Company profile unavailable",
      company_city: company?.city ?? null,
    };
  });
}

type MarketplaceSupplier={id:string;user_id:string|null;company_name:string;business_type:string|null;city:string|null;province:string|null;logo_url:string|null};
async function loadSuppliers():Promise<MarketplaceSupplier[]>{
 if(!isSupabaseConfigured())return [];
 const supabase=await createClient();
 const {data,error}=await supabase.from("public_company_directory").select("id,user_id,company_name,business_type,city,province,logo_url").order("company_name");
 if(error)return [];
 return (data??[]) as MarketplaceSupplier[];
}
export default async function MarketplacePage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; city?: string; sector?: string; category?: string }>;
}) {
  const params = await searchParams;
  const [products,suppliers] = await Promise.all([loadProducts(),loadSuppliers()]);
  const query = (params.q ?? "").trim().toLowerCase();
  const city = (params.city ?? "").trim().toLowerCase();
  const selectedSector = (params.sector ?? "").trim().toLowerCase();
  const selectedCategories = (params.category ?? "").split(",").map((item)=>item.trim().toLowerCase()).filter(Boolean);
  const visibleProducts = products.filter(
    (product) =>
      (!query ||
        `${product.product_name} ${product.brand_name ?? ""} ${product.company_name} ${product.category} ${product.generic_name ?? ""}`
          .toLowerCase()
          .includes(query)) &&
      (!city || city === "all cities" || product.company_city?.trim().toLowerCase() === city) &&
      (!selectedSector || selectedSector === "all sectors" ||
        product.sector?.trim().toLowerCase() === selectedSector ||
        product.sectors?.some((item) => item.trim().toLowerCase() === selectedSector)) &&
      (!selectedCategories.length || selectedCategories.includes(product.category.trim().toLowerCase())),
  );
  const visibleSuppliers=suppliers.filter((company)=>{
   const matchesKeyword=!query||[company.company_name,company.business_type??""].join(" ").toLowerCase().includes(query);
   const matchesCityFilter=!city||city==="all cities"||matchesCity(company.city,city);
   const matchesSector=!selectedSector||selectedSector==="all sectors"||company.business_type?.toLowerCase().includes(selectedSector);
   return matchesKeyword&&matchesCityFilter&&matchesSector;
  });
  const sectors = [...new Set(products.flatMap((product) => [product.sector,...(product.sectors ?? [])]).filter(Boolean))] as string[];
  const cities = uniqueCities([...products.map((product) => product.company_city),...suppliers.map((company) => company.city)]);

  return (
    <main className="marketplace-page">
      <SiteHeader />
      <section className="page-hero marketplace-hero">
        <div className="shell">
          <span className="section-kicker">B2B + B2C MARKETPLACE</span>
          <h1>Animal-health products, organized by sector and supplier.</h1>
          <p>
            Browse administrator-approved company products and send information
            or quotation requests directly to the supplier.
          </p>
          <div className="hero-actions">
            <Link className="button button-primary" href="#suppliers">Find suppliers</Link>
            <Link className="button button-secondary" href="#products">Browse products</Link>
            <Link className="button button-secondary" href="/register?role=company#registration">List your company</Link>
          </div>
        </div>
      </section>
      <section className="section compact-section">
        <div className="shell">
          <div className="section-heading">
            <span className="section-kicker">EXPLORE CATEGORIES</span>
            <h2>Search by product need.</h2>
          </div>
          <div className="category-grid">
            {productCategories.map((category) => (
              <Link key={category} href={`/marketplace?category=${encodeURIComponent(category)}#products`}>
                <b>{category}</b>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section id="suppliers" className="section compact-section">
        <div className="shell">
          <div className="section-heading"><span className="section-kicker">APPROVED COMPANY DIRECTORY</span><h2>Find animal-health suppliers</h2>
            <p>Public company profiles are listed separately from product approvals. City is the company&apos;s registered public location, not confirmed product availability.</p>
          </div>
          {visibleSuppliers.length===0?<div className="empty-state"><h3>No public companies match these filters.</h3><Link href="/companies">Browse all companies</Link></div>:
            <div className="company-grid">
              {visibleSuppliers.map((company)=><article key={company.id}>
                {company.logo_url?<img className="company-mark large company-logo" src={company.logo_url} alt={company.company_name+" logo"} loading="lazy" decoding="async" />:
                <div className="company-mark large">VC</div>}
                <h3>{company.company_name}</h3><p>{company.business_type||"Animal-health company"} · {company.city||company.province||"Pakistan"}</p>
                <Link className="button button-secondary button-full" href={`/companies/${company.id}`}>View company profile</Link>
              </article>)}
            </div>}
        </div>
      </section>
      <section id="products" className="section section-soft">
        <div className="shell">
          <div className="directory-top">
            <div>
              <b>{visibleProducts.length} product listings</b>
              <span>Only approved published product listings. Supplier city does not confirm local stock.</span>
            </div>
            <form className="market-search" method="get" action="/marketplace#products" aria-label="Filter marketplace products">
              <input name="q" defaultValue={params.q ?? ""} placeholder="Product, brand or company" aria-label="Search products" />
              <input name="city" list="marketplace-supplier-cities" defaultValue={params.city ?? ""} placeholder="All cities" aria-label="Supplier city" />
              <datalist id="marketplace-supplier-cities">{cities.map((item)=><option key={item} value={item}/>)}</datalist>
              <select name="sector" defaultValue={params.sector ?? "All sectors"} aria-label="Product sector">
                <option>All sectors</option>
                {sectors.map((sector) => <option key={sector}>{sector}</option>)}
              </select>
              {params.category && <input type="hidden" name="category" value={params.category} />}
              <button className="button button-primary" type="submit">Search</button>
            </form>
          </div>
          {params.category && (
            <div className="active-filter">
              Categories: <b>{(params.category??"").split(",").join(", ")}</b> <Link href="/marketplace#products">Clear</Link>
            </div>
          )}
          {visibleProducts.length === 0 ? (
            <div className="empty-state"><h2>{products.length ? "No approved products match these filters." : "No approved product listings are available yet."}</h2><p>Explore published company profiles or adjust your search. Product information appears after review and publication.</p><Link href="/companies">Browse companies</Link> · <Link href="/marketplace#products">Clear filters</Link></div>
          ) : (
            <div className="product-grid">
              {visibleProducts.map((product) => (
                <article className="product-card" key={product.slug}>
                  {product.image_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img className="product-visual product-image" src={product.image_url} alt={`${product.product_name} product image`} loading="lazy" decoding="async" />
                  ) : (
                    <div className="product-visual">{productMark(product)}</div>
                  )}
                  <span>{product.category}</span>
                  <h3>{product.product_name}</h3>
                  <p>{product.company_name}</p>
                  <small>{[product.generic_name, product.dosage_form, ...product.pack_sizes].filter(Boolean).join(" • ") || "Structured company listing"}</small>
                  <div className="product-meta"><b>{product.sector || "Animal health"}</b><b>{product.availability || "Contact company"}</b></div>
                  <div className="card-actions">
                    <Link className="button button-primary" href={`/marketplace/${product.slug}`}>View details</Link>
                    <Link className="button button-secondary" href={`/marketplace/${product.slug}#request`}>Request quotation</Link>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
      <section className="section">
        <div className="shell two-col">
          <div><span className="section-kicker">COMPANY PANEL</span><h2>Controlled product publishing.</h2><p>Verified companies submit structured product information for administrative approval. This module is informational and does not process payments.</p></div>
          <div className="spec-list">
            <div><b>Company profile</b><span>Verified business identity and public contact details.</span></div>
            <div><b>Product information</b><span>Product, generic, composition, packing and availability.</span></div>
            <div><b>Customer requests</b><span>Information, company contact and quotation inquiries.</span></div>
            <div><b>Admin workflow</b><span>Approval is required before a listing becomes public.</span></div>
          </div>
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
