import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const sql = readFileSync(new URL('../supabase/migrations/20261126000100_account_form_drafts.sql', import.meta.url), 'utf8');
test('draft schema has account-scoped composite identity and bounded object payload', () => {
  assert.match(sql, /primary key \(owner_id, draft_key\)/);
  assert.match(sql, /jsonb_typeof\(payload\) = 'object'/);
  assert.match(sql, /65536/);
});
test('draft policies scope all operations to authenticated owner', () => {
  assert.match(sql, /enable row level security/);
  assert.match(sql, /revoke all .* from public, anon, authenticated/);
  for (const operation of ['select','insert','update','delete']) assert.match(sql, new RegExp(`for ${operation} to authenticated.*owner_id = \\(select auth.uid\\(\\)\\)`));
});
