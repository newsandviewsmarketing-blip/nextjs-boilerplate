-- Additive private draft storage; no changes to canonical records.
create table public.account_form_drafts (
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  draft_key text not null check (length(draft_key) between 1 and 160),
  payload jsonb not null check (jsonb_typeof(payload) = 'object' and octet_length(payload::text) <= 65536),
  updated_at timestamptz not null default now(),
  primary key (owner_id, draft_key)
);
alter table public.account_form_drafts enable row level security;
revoke all on public.account_form_drafts from public, anon, authenticated;
grant select, insert, update, delete on public.account_form_drafts to authenticated;
create policy account_draft_select on public.account_form_drafts for select to authenticated using (owner_id = (select auth.uid()));
create policy account_draft_insert on public.account_form_drafts for insert to authenticated with check (owner_id = (select auth.uid()));
create policy account_draft_update on public.account_form_drafts for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
create policy account_draft_delete on public.account_form_drafts for delete to authenticated using (owner_id = (select auth.uid()));
