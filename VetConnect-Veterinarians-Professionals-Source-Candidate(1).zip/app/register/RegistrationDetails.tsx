"use client";
import CompanyClassificationFields from "@/app/components/CompanyClassificationFields";
import AwardingInstitutionField from "./AwardingInstitutionField";
import { useRef, useState } from "react";
import { PRACTICE_AREAS, SPECIALIZATIONS, PROFESSIONAL_CATEGORIES, VETERINARY_QUALIFICATIONS, ACADEMIC_QUALIFICATIONS, STUDENT_PROGRAMS_BY_TRACK } from "@/lib/registration-categories";
import { hasDocumentedVeterinaryQualification } from "@/lib/veterinary-verification";
import { PAKISTAN_LOCATION_OPTIONS, PAKISTAN_PROVINCES } from "@/lib/pakistan-locations";

function visibleLocations(query: string) {
  const term = query.trim().toLowerCase();
  if (!term) return [];
  return PAKISTAN_LOCATION_OPTIONS.filter(option =>
    option.label.toLowerCase().includes(term) || option.value.toLowerCase().includes(term)
  ).slice(0, 60);
}

export function PakistanCityField({ id, name, label, required = false, singleInput = false }: {
  id: string;
  name: string;
  label: string;
  required?: boolean;
  singleInput?: boolean;
}) {
  const [province, setProvince] = useState("");
  const [query, setQuery] = useState("");
  const [value, setValue] = useState("");
  const term = query.trim().toLowerCase();
  const choices = PAKISTAN_LOCATION_OPTIONS.filter(option => option.province === province &&
    (option.value === value || !term || option.label.toLowerCase().includes(term)));

  return <>
    <div>
      <label htmlFor={id + "-province"}>Province / territory *</label>
      <select id={id + "-province"} name="province" required={required} value={province}
        onChange={event => { setProvince(event.target.value); setValue(""); setQuery(""); }}>
        <option value="" disabled>Select province / territory</option>
        {PAKISTAN_PROVINCES.map(item => <option key={item}>{item}</option>)}
      </select>
    </div>
    <div>
      <label htmlFor={id}>{label}</label>
      {singleInput ? <>
        <input id={id} name={name} list={id + "-locations"} required={required}
          disabled={!province} autoComplete="off" value={value}
          placeholder={province ? "Type and select city / town" : "Choose province first"}
          onChange={event => setValue(event.target.value)}/>
        <datalist id={id + "-locations"}>
          {PAKISTAN_LOCATION_OPTIONS.filter(option => option.province === province)
            .map(option => <option value={option.value} label={option.label} key={option.label}/>)}
        </datalist>
        <small>Choose a listed locality. Changing province clears your city.</small>
      </> : <><label htmlFor={id + "-search"} className="form-help">Search within the selected province</label>
      <input id={id + "-search"} type="search" autoComplete="off" disabled={!province}
        placeholder="Search city, town or district" value={query} onChange={event => setQuery(event.target.value)} />
      <select id={id} name={name} required={required} value={value} disabled={!province}
        aria-describedby={id + "-help"} onChange={event => { setValue(event.target.value); setQuery(""); }}>
        <option value="" disabled>{province ? "Select city / town" : "Select province first"}</option>
        {choices.map(option => <option value={option.value} key={option.label}>{option.label}</option>)}
      </select>
      <small id={id + "-help"}>Choose a listed locality in your province. Changing province clears the city. Contact support if your locality is missing.</small>
      </>}
    </div>
  </>;
}

function QualificationField({ id, name, label, options, onChange }: {
  id: string;
  name: string;
  label: string;
  options: readonly string[];
  onChange?: (value: string) => void;
}) {
  const [choice, setChoice] = useState("");
  return <div>
    <label htmlFor={id}>{label}</label>
    <select id={id} name={name + "_choice"} required value={choice} onChange={event => { setChoice(event.target.value); onChange?.(event.target.value === "__other__" ? "" : event.target.value); }}>
      <option value="" disabled>Select qualification</option>
      {options.map(option => <option value={option} key={option}>{option}</option>)}
      <option value="__other__">Other qualification (specify; admin verification required)</option>
    </select>
    {choice === "__other__" && <input name={name + "_other"} maxLength={173} required
      aria-label="Specify qualification title" placeholder="Enter the exact qualification title" onChange={event => onChange?.(event.target.value)} />}
  </div>;
}


const COMPANY_ACTIVITIES = [
  "Veterinary Pharmaceuticals", "Veterinary Medicines", "Vaccines / Biologicals",
  "Feed Manufacturing", "Feed Additives", "Animal Nutrition", "Poultry",
  "Livestock / Dairy", "Aquaculture / Fisheries", "Pet Products / Services",
  "Diagnostics / Laboratory", "Veterinary Equipment", "Distribution / Retail",
  "Farm / Producer", "Research / Education", "Recruitment / HR",
] as const;

function CompanyRegistrationFields() {
  const [selected,setSelected] = useState<string[]>([]);
  const [custom,setCustom] = useState("");
  const activities = [...selected, ...(custom.trim() ? [custom.trim()] : [])];
  return <>
    <div><label htmlFor="company-name">Registered company name *</label>
      <input id="company-name" name="organization_name" required maxLength={180}
        autoComplete="organization" placeholder="Legal registered company name"/></div>
    <div><label htmlFor="company-reg">Registration / NTN number (optional)</label>
      <input id="company-reg" name="company_registration_number" maxLength={180}
        placeholder="Official registration or NTN"/></div>
    <fieldset className="form-span-2 vc-company-activities">
      <legend>Company business activities *</legend>
      <p className="form-help">Select all relevant activities. Your company can later manage jobs, products and services from one account.</p>
      <div className="service-checkbox-grid">
        {COMPANY_ACTIVITIES.map(activity => <label className="checkbox-line" key={activity}>
          <input type="checkbox" checked={selected.includes(activity)}
            onChange={event=>setSelected(current=>event.target.checked
              ? [...current,activity] : current.filter(item=>item!==activity))}/>
          {activity}
        </label>)}
      </div>
      <label htmlFor="company-activity-other">Other business activity (optional)</label>
      <input id="company-activity-other" maxLength={100} value={custom}
        onChange={event=>setCustom(event.target.value)} placeholder="Specify another activity"/>
      <input type="hidden" name="company_type" value={activities[0] ?? ""}/>
      <input type="hidden" name="industry_sector" value={activities[0] ?? ""}/>
      {activities.map(activity=><input type="hidden" name="company_types" value={activity} key={"type-"+activity}/>)}
      {activities.map(activity=><input type="hidden" name="industry_sectors" value={activity} key={"sector-"+activity}/>)}
      <small>At least one activity is required. Management contacts are added after registration.</small>
    </fieldset>
    <CompanyClassificationFields/>
  </>;
}

export function AcademicQualifications({ id, name, label, options, practitioner = false, completed = true }: {
  id: string; name: string; label: string; options: readonly string[]; practitioner?: boolean; completed?: boolean;
}) {
  const [primary, setPrimary] = useState("");
  const [degrees, setDegrees] = useState<Array<{ id: number; title: string }>>([]);
  const [pvmcPending,setPvmcPending] = useState(false);
  const nextId = useRef(0);
  const needsPvmc = practitioner || [...(completed ? [primary] : []), ...degrees.map(item => item.title)].some(hasDocumentedVeterinaryQualification);
  return <fieldset className="form-span-2 vc-education">
    <legend>Education & qualifications</legend>
    <p className="form-help">{completed ? "Start with your first / foundational degree, then add later qualifications in order." : "Choose your current study program. You may add completed degrees below."}</p>
    <div className="vc-education-row vc-education-row--primary">
      <QualificationField id={id} name={name} label={label} options={options} onChange={setPrimary} />
      <AwardingInstitutionField key={primary} id={id + "-institution"} name="institution" degree={primary} />
    </div>
    {degrees.map((degree,index) => <div className="vc-education-row" key={degree.id}>
      <input type="hidden" name="additional_qualification_index" value={degree.id} />
      <QualificationField id={id + "-additional-" + degree.id} name={"additional_qualification_" + degree.id}
        label={"Additional completed degree " + (index+1) + " *"} options={ACADEMIC_QUALIFICATIONS}
        onChange={title => setDegrees(previous => previous.map(item => item.id === degree.id ? { ...item, title } : item))} />
      <AwardingInstitutionField key={degree.title} id={id + "-institution-" + degree.id}
        name={"additional_institution_" + degree.id} degree={degree.title} />
      <button type="button" className="vc-degree-remove" aria-label={"Remove additional degree " + (index+1)}
        onClick={() => setDegrees(previous => previous.filter(item => item.id !== degree.id))}>Remove</button>
    </div>)}
    <button type="button" className="button button-secondary vc-degree-add" disabled={degrees.length >= 10}
      onClick={() => { const id = nextId.current++; setDegrees(previous => [...previous, { id, title: "" }]); }}>+ Add another degree</button>
    {needsPvmc && <div className="vc-pvmc-row">
      <div><label htmlFor={id + "-pvmc"}>PVMC practitioner registration number{pvmcPending ? "" : " *"}</label>
        <input id={id + "-pvmc"} name="pvmc_number" required={!pvmcPending} disabled={pvmcPending} maxLength={70} autoComplete="off" /></div>
      <label className="checkbox-line"><input type="checkbox" name="pvmc_number_pending" value="true"
        checked={pvmcPending} onChange={event=>setPvmcPending(event.target.checked)} />PVMC number not yet available</label>
      {practitioner && !pvmcPending && <label className="checkbox-line form-span-2"><input type="checkbox" name="pvmc_declaration" value="true" required />I declare that my PVMC registration details are accurate and authorize independent verification. My registration remains unverified until reviewed.</label>}
      <small className="form-span-2">{pvmcPending ? "You may save your education as a draft. Practitioner verification requires a PVMC number and supporting evidence." : "A degree or university selection does not automatically verify practice rights."}</small>
    </div>}
  </fieldset>;
}

function ClinicCityField() {
  const [query, setQuery] = useState("");
  const [cities, setCities] = useState<string[]>([]);
  const matches = visibleLocations(query);
  const groups = [...new Set(matches.map(option => option.province))];
  const addCity = (city: string) => {
    if (city && cities.length < 20 && !cities.some(item => item.toLowerCase() === city.toLowerCase())) {
      setCities(previous => [...previous, city]);
    }
    setQuery("");
  };

  return <div className="form-span-2">
    <label htmlFor="clinic-city-search">Additional service cities</label>
    <input id="clinic-city-search" type="search" autoComplete="off"
      placeholder="Search a Pakistan city, town or district"
      value={query} onChange={event => setQuery(event.target.value)} />
    <select aria-label="Choose an additional clinic service city" value=""
      disabled={!query.trim() || cities.length >= 20}
      onChange={event => addCity(event.target.value)}>
      <option value="">{query ? "Choose a location from the results" : "Search above to add a city"}</option>
      {groups.map(province => <optgroup label={province} key={province}>
        {matches.filter(option => option.province === province).map(option =>
          <option value={option.value} key={option.label}>{option.label}</option>
        )}
      </optgroup>)}
    </select>
    {cities.length > 0 && <div className="service-checkbox-grid" aria-label="Additional clinic cities">
      {cities.map(city => <span className="checkbox-line" key={city}>
        {city}
        <button type="button" aria-label={"Remove " + city} onClick={() => setCities(previous => previous.filter(item => item !== city))}>×</button>
        <input type="hidden" name="clinic_cities" value={city} />
      </span>)}
    </div>}
    <small>Choose each additional city from the list. You can remove locations before submitting.</small>
  </div>;
}

function ExperienceFields() {
  return <>
    <div><label htmlFor="experience-years">Years of professional experience</label><input id="experience-years" name="experience_years" type="number" min="0" max="80" step="1" /></div>
    <div><label htmlFor="current-designation">Current designation / role</label><input id="current-designation" name="current_designation" maxLength={180} /></div>
    <div><label htmlFor="workplace">Current workplace / institution</label><input id="workplace" name="current_workplace" maxLength={180} /></div>
    <div className="form-span-2"><label htmlFor="professional-summary">Professional experience / profile summary</label><textarea id="professional-summary" name="professional_summary" maxLength={250} rows={3} /></div>
  </>;
}

export default function RegistrationDetails({ role, clinic = false }: { role: string; clinic?: boolean }) {
  const [track, setTrack] = useState("");
  if (role === "veterinarian") return <>
    <ExperienceFields />
    <AcademicQualifications practitioner id="vet-degree" name="qualifications" label="Veterinary qualification *" options={VETERINARY_QUALIFICATIONS} />
    <fieldset className="form-span-2 service-selector-fieldset"><legend>Practice areas / animal sectors * (select several)</legend><div className="service-checkbox-grid">{PRACTICE_AREAS.map(x => <label className="checkbox-line" key={x}><input type="checkbox" name="practice_areas" value={x} />{x}</label>)}</div></fieldset>
    <fieldset className="form-span-2 service-selector-fieldset"><legend>Specializations (select several)</legend><div className="service-checkbox-grid">{SPECIALIZATIONS.map(x => <label className="checkbox-line" key={x}><input type="checkbox" name="specializations" value={x} />{x}</label>)}</div></fieldset>
    <div className="form-span-2"><label htmlFor="vet-other-specialization">Additional specialization (optional)</label><input id="vet-other-specialization" name="specialization_other" maxLength={120} placeholder="Specify another area of expertise" /></div>
    <p className="form-help form-span-2">Practice rights are not granted until the administrator verifies your qualification and PVMC status.</p>
  </>;
  if (role === "candidate") return <>
    <ExperienceFields />
    <div><label htmlFor="student-track">Career status *</label><select name="student_track" id="student-track" required value={track} onChange={event => setTrack(event.target.value)}><option value="" disabled>Select status</option><option value="dvm_student">DVM student</option><option value="postgraduate_student">Postgraduate student (MPhil / MSc)</option><option value="phd_student">PhD student</option><option value="job_seeker">Graduate / job seeker</option></select></div>
    {track === "job_seeker" ? <>
      <AcademicQualifications id="job-qualification" name="highest_qualification" label="First / foundational qualification *" options={ACADEMIC_QUALIFICATIONS} />
      <div><label htmlFor="career-interest">Career interests / desired role</label><input name="career_interest" id="career-interest" maxLength={180} placeholder="Internships, animal health, nutrition, research" /></div>
    </> : track ? <>
      <AcademicQualifications key={track} completed={false} id="student-program" name="study_program" label="Program / field *" options={STUDENT_PROGRAMS_BY_TRACK[track as keyof typeof STUDENT_PROGRAMS_BY_TRACK]} />
      <div><label htmlFor="college-reg">College / university registration number *</label><input name="student_college_registration_number" id="college-reg" maxLength={75} required /></div>
      {track === "dvm_student" && <div><label htmlFor="pvmc-student">PVMC student reference (optional, if issued)</label><input name="pvmc_student_reference" id="pvmc-student" maxLength={75} /><small>This is not an RVMP practitioner licence.</small></div>}
      <div><label htmlFor="student-year">Academic year / semester</label><input name="academic_year" id="student-year" maxLength={180} /></div>
    </> : <p className="form-help form-span-2">Select a career status to see the information required for your pathway.</p>}
    <p className="form-help form-span-2">Students submit current institutional evidence. Graduates and job seekers submit their highest qualification. Neither pathway authorizes veterinary practice.</p>
  </>;
  if (role === "professional") return <>
    <ExperienceFields />
    <details className="form-span-2 service-selector-fieldset">
      <summary>Professional categories * <span>(choose all that apply)</span></summary>
      <div className="service-checkbox-grid">{PROFESSIONAL_CATEGORIES.map((x, i) => <label className="checkbox-line" key={x}><input type="checkbox" name="professional_types" value={x} id={"allied-role-" + i} />{x}</label>)}</div>
    </details>
    <AcademicQualifications id="allied-qualification" name="highest_qualification" label="First / foundational qualification *" options={ACADEMIC_QUALIFICATIONS} />
    <details className="form-span-2 service-selector-fieldset">
      <summary>Industry sectors * <span>(choose all that apply)</span></summary>
      <div className="service-checkbox-grid">{PRACTICE_AREAS.map((x, i) => <label className="checkbox-line" key={x}><input type="checkbox" name="industry_sectors" value={x} id={"allied-sector-" + i} />{x}</label>)}</div>
    </details>
    <div><label htmlFor="allied-org">Organization / employer</label><input name="organization_name" id="allied-org" maxLength={180} /></div>
    <div className="form-span-2"><label htmlFor="allied-spec">Area of expertise *</label><input id="allied-spec" name="specialization_other" maxLength={120} required /></div>
    <p className="form-help form-span-2">Select every relevant category and sector. Your profile will use the first selected category as its main heading and retain the full list for search and profile display.</p>
    <p className="form-help form-span-2">Upload evidence for your education and credentials. Allied-professional registration does not authorize veterinary practice.</p>
  </>;
  if (role === "company" && clinic) return <>
    <div><label htmlFor="clinic-name">Clinic / veterinary hospital name *</label><input name="organization_name" id="clinic-name" required maxLength={180} /></div>
    <div><label htmlFor="facility-type">Facility type *</label><select name="facility_type" id="facility-type" required><option>Veterinary Clinic</option><option>Pet Clinic</option><option>Veterinary Hospital</option><option>Mobile Veterinary Service</option><option>Farm Veterinary Clinic</option></select></div>
    <div><label htmlFor="company-reg-clinic">Business registration / NTN *</label><input name="company_registration_number" id="company-reg-clinic" maxLength={180} required /></div>
    <div><label htmlFor="clinic-address">Primary facility address *</label><input name="facility_address" id="clinic-address" maxLength={250} required /></div>
    <ClinicCityField />
    <div><label htmlFor="clinic-vet">Responsible veterinarian full name *</label><input name="responsible_veterinarian" id="clinic-vet" maxLength={180} required /></div>
    <div><label htmlFor="clinic-pvmc">Responsible veterinarian PVMC registration number (optional at account registration)</label><input name="pvmc_number" id="clinic-pvmc" maxLength={70} /><small>This must be provided and independently reviewed before the clinic is published for veterinary practice.</small></div>
    <label className="checkbox-line form-span-2"><input type="checkbox" name="pvmc_declaration" value="true" required />I declare that the responsible veterinarian details I provide are accurate to the best of my knowledge and that I am authorized to provide them for independent verification. This is not PVMC confirmation.</label>
  </>;
  if (role === "company") return <CompanyRegistrationFields/>;
  if (role === "laboratory") return <>
    <div><label htmlFor="lab-name">Diagnostic laboratory name *</label><input name="organization_name" id="lab-name" required maxLength={180} /></div>
    <div><label htmlFor="lab-type">Laboratory type *</label><select id="lab-type" name="laboratory_type" required><option>Veterinary Diagnostic Laboratory</option><option>Poultry Diagnostic Laboratory</option><option>Animal Health / Research Laboratory</option><option>Other</option></select></div>
    <div><label htmlFor="lab-registration">Laboratory registration / licence number *</label><input id="lab-registration" name="laboratory_registration_number" maxLength={120} required /></div>
    <div><label htmlFor="lab-tests">Tests / services offered *</label><input id="lab-tests" name="tests_offered" maxLength={250} required /></div>
    <div><label htmlFor="lab-location">Laboratory street address *</label><input id="lab-location" name="lab_location" maxLength={250} required /></div>
  </>;
  return <>
    <div><label htmlFor="customer-type">Customer profile *</label><select id="customer-type" name="customer_type" required><option>Pet Owner</option><option>Farmer / Livestock Owner</option><option>Poultry Farmer</option><option>Shopkeeper / Retailer</option><option>Other Animal Owner</option></select></div>
    <div><label htmlFor="animal-interest">Animal species / service interests</label><input name="animal_interest" id="animal-interest" maxLength={180} /></div>
  </>;
}
