import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "VetConnect Pakistan",
    short_name: "VetConnect",
    description: "Veterinary professionals, companies, products, jobs and knowledge for Pakistan.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#0b2b4c",
    icons: [
      { src: "/vc-icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/vc-icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
