import { uniqueCities, matchesCity } from "@/lib/city-normalization";
import type { Metadata } from "next";
import Link from "next/link";
import SiteHeader from "../components/SiteHeader";
import SiteFooter from "../components/SiteFooter";
import ProfilePhoto from "../components/ProfilePhoto";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { createClient } from "@/lib/supabase/server";
import { initials, type PublicClinic } from "@/lib/directories";

export const metadata: Metadata = {
  title: "Veterinary Clinics & Hospitals in Pakistan",
  description: "Find veterinary clinics and hospitals in Pakistan by location, facility type and service.",
  alternates: { canonical: "/clinics" },
};

export const dynamic = "force-dynamic";

async function loadClinics(): Promise<PublicClinic[]> {
  if (!isSupabaseConfigured()) return [];
  const supabase = await createClient();
  const { data, error } = await supabase.from("public_clinics").select("id, slug, clinic_name, facility_type, description, city, province, district, tehsil, logo_url, cover_image_url, address, public_phone, public_email, website, working_hours, emergency_service, services, species, profile_verified, other_cities").order("clinic_name");
  if (error || !data?.length) return [];
  return (data as PublicClinic[]).filter(row=>row.profile_verified && !row.is_sample);
}

export default async function ClinicsPage({ searchParams }: { searchParams: Promise<{ q?: string; city?: string; type?: string }> }) {
  const params = await searchParams;
  const clinics = await loadClinics();
  const q = (params.q ?? "").toLowerCase();
  const visible = clinics.filter((clinic) => {
    const serviceCities=[clinic.city,...(clinic.other_cities??[])].filter(Boolean);
    const text = `${clinic.clinic_name} ${clinic.facility_type} ${serviceCities.join(" ")} ${clinic.services.join(" ")} ${clinic.species.join(" ")}`.toLowerCase();
    return (!q || text.includes(q)) && (!params.city || params.city === "All cities" || serviceCities.some(value => matchesCity(value,params.city))) && (!params.type || params.type === "All facility types" || clinic.facility_type === params.type);
  });
  const cities = uniqueCities(clinics.flatMap((item) => [item.city,...(item.other_cities??[])]));
  const types = [...new Set(clinics.map((item) => item.facility_type))];
  const showingSamples = clinics.some((item) => item.is_sample);

  return <main><SiteHeader />
    <section className="page-hero"><div className="shell"><span className="section-kicker">CLINICS & HOSPITALS</span><h1>Find veterinary facilities by location and service.</h1><p>Search public, administrator-approved clinic and hospital profiles without exposing private verification documents.</p><div className="hero-actions"><Link className="button button-primary" href="/register?role=company&intent=clinic#registration">
      Register a veterinary facility</Link></div></div></section>
    <section className="section compact-section"><div className="shell"><div className="directory-top"><div><b>{visible.length} facility profiles</b><span>{showingSamples ? "Sample profiles until facilities are approved" : "Administrator-approved clinic directory"}</span></div><form className="market-search" method="get"><input name="q" defaultValue={params.q ?? ""} placeholder="Clinic, service or species" /><select name="city" defaultValue={params.city ?? "All cities"}><option>All cities</option>{cities.map((item) => <option key={item}>{item}</option>)}</select><select name="type" defaultValue={params.type ?? "All facility types"}><option>All facility types</option>{types.map((item) => <option key={item}>{item}</option>)}</select><button className="button button-primary" type="submit">Search</button></form></div>
      {visible.length === 0 ? <div className="empty-state"><h2>No facility matches these filters.</h2><Link href="/clinics">Clear search</Link></div> : <div className="company-grid">{visible.map((clinic) => <article key={clinic.slug}><div className="company-mark large profile-photo-frame"><ProfilePhoto imageUrl={clinic.logo_url ?? null} name={clinic.clinic_name} fallback={initials(clinic.clinic_name)} /></div>{clinic.is_sample && <span className="sample-label">Sample facility</span>}<h3>{clinic.clinic_name}</h3><p>{clinic.facility_type} • {clinic.city || "Pakistan"}</p>{clinic.other_cities?.length ? <small>Also serves: {clinic.other_cities.join(", ")}</small> : null}<div className="profile-chips">{clinic.species.slice(0, 3).map((item) => <span key={item}>{item}</span>)}</div><dl><div><dt>Services</dt><dd>{clinic.services.slice(0, 2).join(", ") || "Not listed"}</dd></div><div><dt>Emergency</dt><dd>{clinic.emergency_service ? "Available" : "Not listed"}</dd></div><div><dt>Status</dt><dd>{clinic.profile_verified ? "Facility approved" : clinic.is_sample ? "Sample" : "Pending"}</dd></div></dl><Link className="button button-primary button-full" href={`/clinics/${clinic.slug}`}>View facility</Link></article>)}</div>}
    </div></section>
    <section className="section section-soft"><div className="shell two-col"><div><span className="section-kicker">FACILITY INFORMATION</span><h2>Public details controlled by the facility.</h2><p>Approved profiles can show services, species, working hours, service location and public contacts. Verification evidence and internal review notes remain private.</p></div><div className="spec-list"><div><b>Clinic or hospital</b><span>Facility type is stated clearly on every profile.</span></div><div><b>Veterinary leadership</b><span>Veterinarian credentials can be linked and verified separately.</span></div><div><b>Contact control</b><span>Only designated public phone, email and address fields are displayed.</span></div></div></div></section>
    <SiteFooter /></main>;
}
