import Link from "next/link";
import SiteHeader from "../../components/SiteHeader";
import SiteFooter from "../../components/SiteFooter";
import FormMessage from "../../components/FormMessage";
import AdminNav from "../components/AdminNav";
import { isSuspiciousProfileName } from "@/lib/profile-name";
import { credentialDataFlags } from "@/lib/veterinary-verification";
import { requireAdminPermission, staffRoleOptions } from "@/lib/admin";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type UserRow = {
  id: string;
  email: string;
  full_name: string;
  city: string | null;
  province: string | null;
  district: string | null;
  tehsil: string | null;
  primary_role: string;
  account_status: string;
  created_at: string;
};

type VetRow = {
  user_id: string;
  pvmc_number: string | null;
  veterinary_sector: string | null;
  specialization: string | null;
  verification_status: string | null;
  pvmc_verification_status: string | null;
  qualifications: string | null;
};

type Params = {
  error?: string;
  message?: string;
  q?: string;
  role?: string;
  province?: string;
  district?: string;
  sector?: string;
  verification?: string;
};

export default async function AdminUsersPage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const identity = await requireAdminPermission("users.manage", "/admin/users");
  const supabase = await createClient();

  const [{ data: profiles, error: profilesError }, { data: roles, error: rolesError }, { data: vets, error: vetsError }] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, email, full_name, city, province, district, tehsil, primary_role, account_status, created_at")
      .order("created_at", { ascending: false })
      .limit(1000),
    supabase.from("user_roles").select("user_id, role"),
    supabase
      .from("veterinarian_profiles")
      .select("user_id, pvmc_number, veterinary_sector, specialization, verification_status, pvmc_verification_status, qualifications"),
  ]);

  const roleMap = new Map<string, string[]>();
  for (const row of roles ?? []) {
    const current = roleMap.get(row.user_id) ?? [];
    current.push(String(row.role));
    roleMap.set(row.user_id, current);
  }

  const vetMap = new Map<string, VetRow>();
  for (const row of (vets ?? []) as VetRow[]) vetMap.set(row.user_id, row);

  const allRows = (profiles ?? []) as UserRow[];
  const query = (params.q ?? "").trim().toLowerCase();
  const rows = allRows.filter((profile) => {
    const vet = vetMap.get(profile.id);
    const haystack = `${profile.full_name} ${profile.email} ${profile.city ?? ""} ${profile.tehsil ?? ""} ${profile.district ?? ""} ${profile.province ?? ""} ${profile.primary_role} ${vet?.pvmc_number ?? ""} ${vet?.veterinary_sector ?? ""} ${vet?.specialization ?? ""}`.toLowerCase();
    return (
      (!query || haystack.includes(query)) &&
      (!params.role || params.role === "all" || profile.primary_role === params.role) &&
      (!params.province || params.province === "all" || profile.province === params.province) &&
      (!params.district || params.district === "all" || profile.district === params.district) &&
      (!params.sector || params.sector === "all" || vet?.veterinary_sector === params.sector) &&
      (!params.verification || params.verification === "all" || vet?.verification_status === params.verification)
    );
  });

  const provinces = [...new Set(allRows.map((row) => row.province).filter(Boolean))].sort() as string[];
  const districts = [...new Set(allRows.filter((row) => !params.province || params.province === "all" || row.province === params.province).map((row) => row.district).filter(Boolean))].sort() as string[];
  const sectors = [...new Set(((vets ?? []) as VetRow[]).map((row) => row.veterinary_sector).filter(Boolean))].sort() as string[];
  const primaryRoles = [...new Set(allRows.map((row) => row.primary_role).filter(Boolean))].sort();
  const exportParams = new URLSearchParams();
  for (const key of ["q", "role", "province", "district", "sector", "verification"] as const) {
    const value = params[key];
    if (value && value !== "all") exportParams.set(key, value);
  }
  const exportHref = `/admin/users/export${exportParams.size ? `?${exportParams.toString()}` : ""}`;

  return (
    <main>
      <SiteHeader />
      <section className="dashboard-hero">
        <div className="shell dashboard-hero-row">
          <div>
            <span className="section-kicker">ACCESS CONTROL & DIRECTORY</span>
            <h1>Users, veterinarians and administrator hierarchy.</h1>
            <p>Searchable operational directory with standardized geography and Excel-compatible export.</p>
          </div>
        </div>
      </section>
      <section className="section compact-section">
        <div className="shell admin-control-layout">
          <AdminNav roles={identity.roles} />
          <div className="admin-control-content">
            <FormMessage
              error={params.error || profilesError?.message || vetsError?.message || rolesError?.message}
              message={params.message}
            />

            <div className="admin-summary">
              <article><b>{allRows.length}</b><span>Loaded accounts (up to 1,000)</span></article>
              <article><b>{allRows.filter((row) => row.primary_role === "veterinarian").length}</b><span>Veterinarians</span></article>
              <article><b>{((vets ?? []) as VetRow[]).filter((row) => row.verification_status === "approved").length}</b><span>Profile approvals (not PVMC licence)</span></article>
              <article><Link href="/admin/credential-recheck"><b>{((vets ?? []) as VetRow[]).filter(row => credentialDataFlags(row).length>0).length}</b><span>PVMC data rechecks ↗</span></Link></article>
              <article><b>{rows.length}</b><span>Current filtered results</span></article>
            </div>

            <div className="management-links">
              <Link className="button button-primary" href={exportHref}>Download CSV / Excel-compatible list</Link>
              <Link className="button button-secondary" href="/admin/users">Clear filters</Link>
            </div>

            <form className="admin-directory-filters" method="get">
              <div><label htmlFor="q">Search</label><input id="q" name="q" defaultValue={params.q ?? ""} placeholder="Name, email, PVMC, location or specialization" /></div>
              <div><label htmlFor="role">Role</label><select id="role" name="role" defaultValue={params.role ?? "all"}><option value="all">All roles</option>{primaryRoles.map((role) => <option key={role} value={role}>{role.replaceAll("_", " ")}</option>)}</select></div>
              <div><label htmlFor="province">Province</label><select id="province" name="province" defaultValue={params.province ?? "all"}><option value="all">All provinces</option>{provinces.map((province) => <option key={province}>{province}</option>)}</select></div>
              <div><label htmlFor="district">District</label><select id="district" name="district" defaultValue={params.district ?? "all"}><option value="all">All districts</option>{districts.map((district) => <option key={district}>{district}</option>)}</select></div>
              <div><label htmlFor="sector">Veterinary sector</label><select id="sector" name="sector" defaultValue={params.sector ?? "all"}><option value="all">All sectors</option>{sectors.map((sector) => <option key={sector}>{sector}</option>)}</select></div>
              <div><label htmlFor="verification">Verification</label><select id="verification" name="verification" defaultValue={params.verification ?? "all"}><option value="all">All verification</option><option value="approved">Approved</option><option value="pending">Pending</option><option value="rejected">Rejected</option></select></div>
              <button className="button button-primary" type="submit">Apply filters</button>
            </form>

            <div className="admin-directory-table-wrap">
              <table className="admin-directory-table">
                <thead>
                  <tr>
                    <th>Name / Email</th>
                    <th>Role</th>
                    <th>Province</th>
                    <th>District</th>
                    <th>Tehsil / City</th>
                    <th>PVMC</th>
                    <th>Sector / Specialization</th>
                    <th>Verification</th>
                    <th>Account</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((user) => {
                    const vet = vetMap.get(user.id);
                    return (
                      <tr key={user.id}>
                        <td><Link href={`/admin/users/${user.id}`} className="vc-dossier-link" target="_blank" rel="noopener noreferrer"><b>{isSuspiciousProfileName(user.full_name||"") ? `Flagged account · ${user.id.slice(0,8)}` : (user.full_name || "Unnamed account").slice(0,90)}</b></Link><small>{user.email}</small></td>
                        <td>{user.primary_role.replaceAll("_", " ")}{!rolesError && (roleMap.get(user.id) ?? []).filter(role => role !== user.primary_role).map(role => <small key={role}>{role.replaceAll("_", " ")}</small>)}</td>
                        <td>{user.province || "—"}</td>
                        <td>{user.district || "—"}</td>
                        <td>{user.tehsil || user.city || "—"}</td>
                        <td>{vet?.pvmc_number || "—"}</td>
                        <td>{vet ? <><b>{vet.veterinary_sector || "—"}</b><small>{vet.specialization || ""}</small></> : "—"}</td>
                        <td>{vet?.verification_status || "—"}{vet && credentialDataFlags(vet).length>0&&<small className="vc-credential-warning">Credential recheck required</small>}</td>
                        <td>{user.account_status}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="section-heading admin-role-heading">
              <span className="section-kicker">ADMINISTRATOR HIERARCHY</span>
              <h2>Staff roles and account control.</h2>
              <p>Super Administrators can assign controlled staff roles without changing the user-owned professional record.</p>
            </div>

            <div className="role-hierarchy-grid">
              {staffRoleOptions.map((role) => (
                <article key={role.value}>
                  <b>Level {role.level}</b>
                  <h3>{role.label}</h3>
                  <p>{role.summary}</p>
                </article>
              ))}
            </div>

            <section className="vc-admin-panel" aria-labelledby="dossier-navigation-heading">
              <div className="section-heading"><h2 id="dossier-navigation-heading">One account, one management dossier</h2>
                <p>Select a name in the directory table to open that account in a separate tab. Editing, review, suspension, staff roles, activity records and linked documents are managed on its own page rather than repeated here.</p>
              </div>
            </section>
          </div>
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
