import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const read=p=>readFileSync(new URL("../"+p,import.meta.url),"utf8");
test("independent badges in veterinary directory",()=>{const s=read("app/vets/page.tsx");assert.match(s,/vet\.pvmc_verified&&/);assert.match(s,/vet\.profile_verified&&/)});
test("professional headline and verified badge",()=>{const s=read("app/professionals/page.tsx");assert.match(s,/p\.headline\|\|p\.current_position/);assert.match(s,/p\.profile_verified&&/);assert.doesNotMatch(s,/vc-trust-pvmc/)});
test("responsive people grid",()=>{const s=read("app/components/people-directory.css");for(const n of ["repeat(3","repeat(2","grid-template-columns:minmax(0,1fr)"])assert.ok(s.includes(n));});
test("official icon files exist",()=>{for(const n of [32,180,192,512])assert.ok(readFileSync(new URL(`../public/vc-icon-${n}.png`,import.meta.url)).length>100)});
