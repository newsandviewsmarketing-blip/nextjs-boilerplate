# VetConnect | Unified Veterinarian and Professional Services Engineering Contract

## 1. Mandatory outcome and scope
Implement both Find a Vet and Professionals modules as one integrated release, including public UI, individual dashboards, student accounts, customer booking, admin, database, authorization, testing and rollout. Companies are explicitly excluded from this redesign; preserve their existing functionality. Do not split delivery into separate priority releases. Use the two attached reference images for layout only: their faces, names, counts, credentials, experience and availability are illustrative and must never be imported as real data.

Repository: https://github.com/newsandviewsmarketing-blip/nextjs-boilerplate
Vercel: https://vercel.com/vet-connectpk/vetconnect/deployments
Production: https://www.vetconnect.com.pk and https://vetconnect.com.pk
Start from the latest main commit, compare active production and all open/merged PRs, including #167 if still relevant. Reuse one appropriate integration branch/PR. Preserve the existing favicon work and other approved changes. Do not assume previous merged code is complete. Review existing source and database before changing anything.

## 2. Role and service eligibility contract
Separate account identity, professional qualification, verification, publication, service onboarding, schedule and real-time presence. Roles are additive only where permitted by existing authentication rules; a role label is not a credential.

| Account type | Public professional profile | Find a Vet | Service controls |
|---|---|---|---|
| Registered veterinarian | If approved and public | Only when PVMC and VetConnect verification requirements pass and at least one approved service is enabled with a functioning booking/request mechanism | Veterinary services, clinic/home/farm visits, online consultations subject to provider readiness |
| Student | If approved and public, clearly labeled Student | Never on student status alone | Career profile, education, skills, supervised learning and permitted non-clinical services only; no independent veterinary diagnosis, prescriptions or clinical booking |
| Industry professional | If approved and public | Only if independently holds eligible verified veterinarian identity and enables veterinary services | Optional non-clinical advisory, nutrition, research, training, technical or business services within verified scope |
| Customer | No provider listing by default | Search and book eligible providers | Own appointments, notifications, cancellation and history |
| Authorized admin | Not automatically a public provider | Review and control publication and eligibility | Review evidence, service requests, schedules, affiliations, audit and suspension within permissions |

A veterinarian without active bookable services remains discoverable in the approved professional directory where appropriate, not Find a Vet. Do not delete or unpublish their underlying approved profile merely because booking is disabled. Distinguish temporarily fully booked from permanently disabled: show next valid slot or no slots currently; never fabricate availability. Do not require creation of a clinic to offer legitimate independent services. Clinical facility records and person records remain distinct.

## 3. Shared UI and public directories
Use existing header/footer and navy/orange brand. Build shared typed DirectoryCard, VerificationBadge, ServiceChips, AvailabilitySummary, BookingActions and filter components where existing equivalents cannot be reused. Three columns desktop, two tablet, one mobile; equal-height cards per row, flexible content area, aligned CTA bottoms, no overflow at 320px. Use actual approved profile photos or initials; no generated portraits, invented bios or credentials. Reserve consistent identity space, show one-line saved headline/expertise with ellipsis, optional two-line summary and full details on profile. Limit chips to three plus count; wrap or truncate safely. Display city, province, country, public workplace/clinic, actual experience if supplied, otherwise omit or label not provided. No default invented years. Accessible keyboard navigation, visible focus, meaningful alt text, contrast, readable text and loading/error/empty states. Remove duplicate verification rows where badges communicate the same fact.

Find a Vet: search by name/expertise, sector, species, city, service, appointment mode and availability. Return only eligible service providers as defined in section 2. Display exact filtered count, pagination, clear filters and stable sorting. Cards include genuine next available slot in local timezone, clinic affiliation where verified, enabled service modes, Book appointment and View profile. Online call buttons only when provider readiness and actual presence permit; a schedule is not online presence. If no available slot, show accurate status and offer request only if enabled. Profiles must reflect same eligibility and booking data as cards.

Professionals: search by role (including student), sector, skill, city, employer/institution and optional advisory availability. Display approved professional role and institution, headline, public summary, skills and relevant experience. View profile always; Book consultation only for explicitly enabled, approved, non-clinical advisory services or separately eligible veterinary services routed through the clinical workflow. No forced booking on every professional card. Student accounts must not be mislabeled as veterinarians or independent clinical consultants.

## 4. Verification badges and evidence
Small blue check badge with literal label PVMC Verified only for veterinarian credentials actually approved under existing PVMC verification policy; full name of credential and verification explanation on profile. Small green check badge VetConnect Verified only when profile review is approved. Neither implies the other. No badges based merely on entered registration number, degree, role text or paid account. Show private evidence only to authorized reviewers; do not expose registration number by default. Public registration number only if approved lawful publication and explicit existing consent/policy allow it. Revocation/suspension immediately removes affected badge and clinical eligibility; retain audit records. Company module untouched; never apply PVMC badge to companies. No fake government registration or NTN claims.

## 5. Provider onboarding and account dashboards
Reuse existing authentication, profile builder, roles and appointment infrastructure. For veterinarians, expose Services & Appointments workspace: enable/disable bookings, select approved service types and species, description, modes (clinic visit, home visit, farm visit, online audio/video), public service area, clinic affiliations, fees/currency, duration, capacity, weekly schedule, timezone, breaks, holidays, leave, lead time, cancellation and request/confirmation policy. Save drafts reliably and validate required fields before submission. Separate pending changes from approved public service settings; show precise review status. Owner can pause service without losing history. Professionals have equivalent opt-in advisory settings limited to authorized scope. Students have education, skills, CV/career and supervised/approved non-clinical options; no clinical provider activation. Provide dashboard links, upcoming bookings, day/week/month calendar, status changes, notifications, history and safe cancellation/rescheduling. All mutations server-authorized; no role escalation through form values.

## 6. Clinic versus independent service relationships
A doctor may work at one or more clinics and provide independent services. Canonical veterinarian ID and canonical clinic ID must remain separate. Reuse existing affiliation tables and approval workflows. Example: Dr Murtaza and Al-Shafi Clinic are separate illustrative records; a verified affiliation links them in both directions. Do not create either record from this example. Clinic profile lists only approved affiliations with location-specific schedules and services; doctor profile links approved clinics. A booking identifies the provider, service, location/mode and clinic when applicable. Independent bookings have no clinic ID. Prevent doctor double-booking across clinics, home/farm visits and online appointments; clinic capacity rules apply separately. Allow authorized clinic managers to propose affiliations and schedules, never impersonate a doctor or override unrelated schedules. Remove affiliation safely without deleting histories. Distinguish clinic hours from doctor availability.

## 7. Booking lifecycle and customer experience
Customer selects provider, enabled service, location/mode, date/time and sees duration, fee, currency, timezone and cancellation policy before confirmation. Require authentication and return safely to same booking after login. Capture only necessary contact/animal details with consent, keep exact home/farm addresses private. Validate eligibility and availability server-side at submission; transactional locking/unique constraints prevent conflicting bookings, duplicate requests and retry duplication. Use existing status model or explicitly migrate to mapped states: requested, confirmed, declined, cancelled, rescheduled, completed, no-show; audit transitions. Distinguish requests awaiting confirmation from confirmed appointments. Notifications for both parties, failure retry without duplicate booking, secure links. No real payments without existing authorized payment infrastructure. No guarantee of clinical outcome. Integrate existing Daily provider-independent consultation layer only when secure room/token, quota, provider connectivity and feature gates pass; otherwise hide/disable actual calls while legitimate in-person bookings remain usable. Do not record calls by default.

## 8. Admin operating workspace
Add or reuse permission-scoped Services & Appointments admin section. Separate counts for registered veterinarians, students, professionals, approved public profiles, eligible Find a Vet providers, enabled services, available slots, genuine online presence and booking states. Counts and drill-down filters must reconcile with exact underlying records, not capped arrays. Show newest created/updated date/time, review status, location, role, service, booking status, affiliations and verification evidence access where authorized. Actions: view, edit authorized fields, request corrections, approve/reject services, publish/unpublish, pause/resume, suspend/revoke credentials with reason, archive/restore where supported; no destructive operations by default. Audit actor, timestamp, old/new values and reason. Admin cannot invent verified credentials or override appointment conflict rules. Provide authorized CSV/Excel/print exports with private fields excluded by default. Use consistent admin table layout, date filters, activity calendar, role-based access and clear empty/error states. Avoid claiming online from last login alone.

## 9. Database and backend engineering
Inspect current schema, public views, migrations, storage, RLS and appointment functions first. Relevant discovery targets include app/vets/page.tsx, app/vets/[id]/page.tsx, app/professionals/page.tsx, app/professionals/[slug]/page.tsx, app/dashboard, app/dashboard/clinics, app/admin, app/components/ProfilePhoto.tsx, lib/directories.ts, lib/admin.ts, lib/supabase, consultation services and supabase/migrations. Confirm actual paths; inventory is not proof all exist. Reuse canonical IDs and existing tables/views for profiles, veterinarian/professional records, managed people, clinics, affiliations, appointments, consultation preferences and master geography. Avoid duplicate schema. If necessary add reversible additive migrations for service catalog/offers, location-specific schedules, booking policy, exceptions, provider links, audit and notifications. Use server-side safe public projection excluding email, phone unless approved, private addresses, evidence and CVs. Explicit RLS for owners, assigned clinic staff, booking participants and authorized admins; anonymous read only approved public projection. Validate IDs, role, scopes, ownership, publication and approved services in every server action/API. Use transaction-level conflict protection across provider and clinic capacity. Index eligible filters and schedule queries; database paging and counts; no N+1 queries. Test timezones, DST where relevant, local-day boundaries, overnight schedules, cancellation, idempotency, stale presence and simultaneous requests. Never expose service role/API secrets. Previously shared Daily credentials should be rotated if not already done; do not put them in source or archive.

## 10. Branding, share previews and preservation
Preserve official VC monogram favicon work and full header logo. Each eligible public profile uses actual approved photo (or initials-based branded fallback), public name/headline and canonical URL for social metadata. Use crawler-accessible versioned HTTPS image URLs and 1200x630 generated preview with small VC mark without obscuring the source. Never expose private files or unpublished profiles. Preserve existing Jobs, Companies, Products, Labs, Clinics, authentication, approved records, SEO, AdSense, and current release gates. Do not alter company card design in this task.

## 11. Acceptance matrix (all mandatory)
Execute each case with evidence and actual test accounts in isolated staging; use synthetic records only. Record PASS/FAIL/BLOCKED and commit/file/test references. Do not mark unexecuted tests passed.

- T01: Latest main and live commit reconciled.
- T02: Both reference layouts matched without importing mock data.
- T03: Desktop three-column aligned cards.
- T04: Tablet two-column layout.
- T05: Mobile 320px no overflow.
- T06: Keyboard and screen-reader access.
- T07: Approved real avatar or initials fallback.
- T08: One-line headline truncation.
- T09: Actual filtered counts and pagination.
- T10: City/sector/service filters accurate.
- T11: PVMC badge only for approved credential.
- T12: VetConnect badge independent of PVMC.
- T13: Revocation removes clinical eligibility.
- T14: Private evidence inaccessible to anonymous user.
- T15: Student label accurate.
- T16: Student cannot activate clinical services.
- T17: Non-vet professional cannot activate clinical services.
- T18: Dual-role veterinarian eligible only after verification.
- T19: Unbookable vet excluded from Find a Vet.
- T20: Approved non-bookable professional still discoverable.
- T21: Bookable verified vet included.
- T22: Paused service not bookable.
- T23: Fully booked schedule accurately represented.
- T24: No invented online status.
- T25: Expired heartbeat removes online indicator.
- T26: Provider onboarding persists after reload.
- T27: Draft settings preserved.
- T28: Admin approval workflow audited.
- T29: Unauthorized settings mutation rejected.
- T30: Clinic affiliation requires approval.
- T31: Doctor and clinic profile links reciprocal.
- T32: Independent doctor can book without clinic.
- T33: Location-specific schedules accurate.
- T34: Holiday and leave respected.
- T35: Timezone and overnight schedule correct.
- T36: Customer login returns to original booking.
- T37: Fee/duration shown before confirmation.
- T38: Concurrent bookings cannot double-book provider.
- T39: Cross-clinic conflicts rejected.
- T40: Clinic capacity enforced.
- T41: Repeated request idempotent.
- T42: Customer cannot access other bookings.
- T43: Employer/clinic staff access scoped.
- T44: Cancellation and rescheduling audited.
- T45: Notifications retry without duplicate appointment.
- T46: Calendar and history reconcile.
- T47: Admin filtered counts reconcile.
- T48: Exports exclude private data by default.
- T49: Daily call gated until secure connectivity passes.
- T50: Private token and quota enforcement verified if calls enabled.
- T51: Profile sharing thumbnail uses approved image.
- T52: Unpublished profile metadata does not leak.
- T53: Existing job/company/product/clinic workflows regressions pass.
- T54: Migration upgrade and rollback rehearsal pass.
- T55: CI audit lint types tests build security checks pass.
- T56: Both production aliases and post-release smoke tests verified after approval.

## 12. Single release and final deliverable
Use Node version and package scripts specified by the repository. Run npm ci and actual audit, lint, source safety, typecheck, unit/integration/E2E, build and dependency security checks. Execute existing consultation acceptance tests if touching consultation. Fix failures rather than weakening tests. Validate migrations on isolated staging database; no paid infrastructure or production mutations without approval. Provide protected preview and mobile/desktop screenshots. Keep untested features disabled. One consolidated PR and one controlled promotion after explicit release approval. Verify both domains point at exact tested deployment, then smoke test. Preserve rollback deployment; application rollback does not roll back database.

Return ONE actual integrated source ZIP named VetConnect-Veterinarians-Professionals-Final.zip outside GitHub, containing source, additive migrations, lockfiles, tests, release manifest, before/after evidence, migration and rollback instructions, SHA-256 and requirement-to-test matrix. Commit actual source files only, never ZIPs, secrets, production records or build caches. If blocked, report precise blocker and do not call the package Final. The present engineering contract is an instruction artifact, not implemented source.
