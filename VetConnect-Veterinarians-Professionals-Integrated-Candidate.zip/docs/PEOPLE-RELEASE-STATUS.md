# Consolidated source candidate — NOT production approved

Updated from user-supplied 468-file archive. Includes original directory styling, official VC icons, member account dropdown, local sign-out account switch, and account-scoped appointment and consultation request counts. Admin and company directory redesign excluded. Existing company workspace links preserved. No sales or order totals fabricated.

Verification: Node 22 static tests (7/7 passed), repository structure audit (96 required entries passed). npm ci --offline failed ENOTCACHED; full lint, TypeScript, build and integration testing not performed. No GitHub commit of these local changes, no database mutation, no Vercel promotion. Not an exact GitHub checkout; reconcile with PR #169 before integration.

Still pending: independent provider onboarding and eligibility, cross-clinic booking conflict enforcement, individual availability calendar, clinic affiliation integration, student/customer appointment workflows, actual store/sales/order management, dynamic social thumbnails, migration/index validation and 56 end-to-end acceptance tests. No new schema deployed. Do not upload ZIP directly to GitHub or Vercel.

## Prior acceptance matrix (unchanged end-to-end status)
Acceptance matrix: all 56 cases BLOCKED for end-to-end acceptance (static checks are not equivalent).
- T01: Latest main and live commit reconciled. — BLOCKED / not executed end-to-end
- T02: Both reference layouts matched without importing mock data. — BLOCKED / not executed end-to-end
- T03: Desktop three-column aligned cards. — BLOCKED / not executed end-to-end
- T04: Tablet two-column layout. — BLOCKED / not executed end-to-end
- T05: Mobile 320px no overflow. — BLOCKED / not executed end-to-end
- T06: Keyboard and screen-reader access. — BLOCKED / not executed end-to-end
- T07: Approved real avatar or initials fallback. — BLOCKED / not executed end-to-end
- T08: One-line headline truncation. — BLOCKED / not executed end-to-end
- T09: Actual filtered counts and pagination. — BLOCKED / not executed end-to-end
- T10: City/sector/service filters accurate. — BLOCKED / not executed end-to-end
- T11: PVMC badge only for approved credential. — BLOCKED / not executed end-to-end
- T12: VetConnect badge independent of PVMC. — BLOCKED / not executed end-to-end
- T13: Revocation removes clinical eligibility. — BLOCKED / not executed end-to-end
- T14: Private evidence inaccessible to anonymous user. — BLOCKED / not executed end-to-end
- T15: Student label accurate. — BLOCKED / not executed end-to-end
- T16: Student cannot activate clinical services. — BLOCKED / not executed end-to-end
- T17: Non-vet professional cannot activate clinical services. — BLOCKED / not executed end-to-end
- T18: Dual-role veterinarian eligible only after verification. — BLOCKED / not executed end-to-end
- T19: Unbookable vet excluded from Find a Vet. — BLOCKED / not executed end-to-end
- T20: Approved non-bookable professional still discoverable. — BLOCKED / not executed end-to-end
- T21: Bookable verified vet included. — BLOCKED / not executed end-to-end
- T22: Paused service not bookable. — BLOCKED / not executed end-to-end
- T23: Fully booked schedule accurately represented. — BLOCKED / not executed end-to-end
- T24: No invented online status. — BLOCKED / not executed end-to-end
- T25: Expired heartbeat removes online indicator. — BLOCKED / not executed end-to-end
- T26: Provider onboarding persists after reload. — BLOCKED / not executed end-to-end
- T27: Draft settings preserved. — BLOCKED / not executed end-to-end
- T28: Admin approval workflow audited. — BLOCKED / not executed end-to-end
- T29: Unauthorized settings mutation rejected. — BLOCKED / not executed end-to-end
- T30: Clinic affiliation requires approval. — BLOCKED / not executed end-to-end
- T31: Doctor and clinic profile links reciprocal. — BLOCKED / not executed end-to-end
- T32: Independent doctor can book without clinic. — BLOCKED / not executed end-to-end
- T33: Location-specific schedules accurate. — BLOCKED / not executed end-to-end
- T34: Holiday and leave respected. — BLOCKED / not executed end-to-end
- T35: Timezone and overnight schedule correct. — BLOCKED / not executed end-to-end
- T36: Customer login returns to original booking. — BLOCKED / not executed end-to-end
- T37: Fee/duration shown before confirmation. — BLOCKED / not executed end-to-end
- T38: Concurrent bookings cannot double-book provider. — BLOCKED / not executed end-to-end
- T39: Cross-clinic conflicts rejected. — BLOCKED / not executed end-to-end
- T40: Clinic capacity enforced. — BLOCKED / not executed end-to-end
- T41: Repeated request idempotent. — BLOCKED / not executed end-to-end
- T42: Customer cannot access other bookings. — BLOCKED / not executed end-to-end
- T43: Employer/clinic staff access scoped. — BLOCKED / not executed end-to-end
- T44: Cancellation and rescheduling audited. — BLOCKED / not executed end-to-end
- T45: Notifications retry without duplicate appointment. — BLOCKED / not executed end-to-end
- T46: Calendar and history reconcile. — BLOCKED / not executed end-to-end
- T47: Admin filtered counts reconcile. — BLOCKED / not executed end-to-end
- T48: Exports exclude private data by default. — BLOCKED / not executed end-to-end
- T49: Daily call gated until secure connectivity passes. — BLOCKED / not executed end-to-end
- T50: Private token and quota enforcement verified if calls enabled. — BLOCKED / not executed end-to-end
- T51: Profile sharing thumbnail uses approved image. — BLOCKED / not executed end-to-end
- T52: Unpublished profile metadata does not leak. — BLOCKED / not executed end-to-end
- T53: Existing job/company/product/clinic workflows regressions pass. — BLOCKED / not executed end-to-end
- T54: Migration upgrade and rollback rehearsal pass. — BLOCKED / not executed end-to-end
- T55: CI audit lint types tests build security checks pass. — BLOCKED / not executed end-to-end
- T56: Both production aliases and post-release smoke tests verified after approval. — BLOCKED / not executed end-to-end
