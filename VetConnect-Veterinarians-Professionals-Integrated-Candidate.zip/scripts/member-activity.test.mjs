import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
const read=p=>readFileSync(new URL("../"+p,import.meta.url),"utf8");
test("account menu uses authenticated email and existing admin permission",()=>{const s=read("app/components/CareerWorkspaceFrame.tsx");assert.match(s,/identity.email/);assert.match(s,/canOpenAdmin&&<Link href="\/admin"/);assert.match(s,/action=\{signOutAction\}/);assert.match(s,/action=\{switchAccountAction\}/)});
test("switch account ends local session",()=>{assert.match(read("app/auth/actions.ts"),/signOut\(\{scope:"local"\}\)/)});
test("activity counts are restricted to current account and owned clinics",()=>{const s=read("app/dashboard/MemberActivity.tsx");assert.match(s,/identity.userId!==userId/);assert.match(s,/eq\("requester_id",userId\)/);assert.match(s,/eq\("owner_id",userId\)/);assert.match(s,/in\("clinic_id",ids\)/);assert.match(s,/Unavailable/)});
