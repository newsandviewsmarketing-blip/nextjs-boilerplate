import Link from "next/link";
import {createClient} from "@/lib/supabase/server";
import {getCurrentIdentity} from "@/lib/auth";

export default async function MemberActivity({userId,roles}:{userId:string;roles:readonly string[]}) {
  const identity=await getCurrentIdentity();
  if(!identity||identity.userId!==userId)return null;
  const db=await createClient();
  const ownRoles=identity.roles.filter(role=>roles.includes(role));
  const isVet=ownRoles.includes("veterinarian");
  const career=ownRoles.some(role=>["veterinarian","professional","candidate"].includes(role));
  const clinic=ownRoles.some(role=>["veterinarian","professional","company"].includes(role));
  const [requests,calls,owned]=await Promise.all([
    db.from("clinic_appointment_requests").select("id",{count:"exact",head:true}).eq("requester_id",userId).in("status",["new","contacted","scheduled"]),
    isVet?db.from("consultation_history").select("id",{count:"exact",head:true}).eq("veterinarian",userId).eq("state","requested"):Promise.resolve({count:null,error:null}),
    clinic?db.from("clinics").select("id").eq("owner_id",userId):Promise.resolve({data:[],error:null})
  ]);
  const ids=(owned.data??[]).map(row=>row.id);
  const visits=owned.error?{count:null,error:owned.error}:ids.length?await db.from("clinic_appointment_requests").select("id",{count:"exact",head:true}).in("clinic_id",ids).in("status",["new","contacted","scheduled"]):{count:0,error:null};
  const count=(result:{count:number|null;error:unknown})=>result.error||result.count===null?"Unavailable":String(result.count);
  return <section className="backend-form-card vcx-account-card" aria-labelledby="member-activity"><h2 id="member-activity">My activities</h2><p>Only activity linked to your authenticated account is counted.</p><div className="workspace-record-list">
    <article><div><h3>My open appointment requests</h3><p>{count(requests)}</p></div><Link className="button button-secondary" href="/clinics">Find a clinic</Link></article>
    {career&&<article><div><h3>Professional profile</h3><p>Expertise, qualifications and career.</p></div><Link className="button button-secondary" href="/dashboard/professional">Manage profile</Link></article>}
    {clinic&&<article><div><h3>Open requests for owned clinics</h3><p>{count(visits)}</p></div><Link className="button button-secondary" href="/dashboard/clinics">Manage clinics</Link></article>}
    {isVet&&<article><div><h3>Incoming online consultation requests</h3><p>{count(calls)}. Calls require separate release authorization.</p></div><Link className="button button-secondary" href="/dashboard/consultation">Consultation settings</Link></article>}
    </div><p className="form-help">Product enquiries are available in authorized company workspaces. Sales, payment and order totals are not yet supported by this dashboard.</p></section>;
}
