# Consolidated P0/P1 closure register
Baseline: verify latest main, production aliases and migration history before changes. Last directly checked at 11:09 UTC: PR 162 build READY (2b7fbaca), both domains still on PR 158 (cca5908). Recheck rather than assuming current state. User screenshots previously confirmed Jadeed save/publish. No complete functional acceptance yet.

| ID | Priority | Action | Required implementation | Acceptance |
|---|---|---|---|---|
| VC01 | P0 | KEEP/MODIFY | Reuse companies.id; migrate legacy company_sectors and company_locations ownership to canonical ID with audited mappings | Admin-created and owner-created records save/reload; no cross-tenant access |
| VC02 | P0 | MODIFY | Reuse master_data_items and geo_areas/geo_aliases; stable parent/child IDs and reviewed synonyms; do not infer missing sectors | Valid hierarchy, duplicate prevention, inactive records retained |
| VC03 | P0 | MODIFY | Universal countries, Pakistan default, city-first, Karachi main city, optional district/tehsil, international region/city/postcode, Google Maps links | Pakistan/UK/UAE round-trip across relevant modules; no forced Pakistani subdivisions |
| VC04 | P0 | MODIFY | Company classification multi-sector/subsector/activity using shared master; separate brand, breed, species, disease, generic | Admin/customer create/edit parity; legacy text retained until reviewed mapping |
| VC05 | P0 | MODIFY | Secure owner/company-scoped drafts and staged uploads, conflict versioning, idempotency, atomic writes or recoverable partial saves | Refresh, failed submit, session expiry, repeated fields, two-account isolation |
| VC06 | P0 | MODIFY | Role-specific verification, separate publication and approval, optional NTN and appropriate foreign evidence | No approval bypass, no private evidence leakage, PVMC rules preserved |
| VC07 | P0 | MODIFY | Consistent record actions: edit/update, publish/unpublish where applicable, archive/restore, dependency-checked audited delete | Authorized actions only; no destructive production testing; preserve historical records |
| VC08 | P0 | REMOVE FROM DISPLAY | Hide raw IDs, audit actor IDs, storage URLs, internal tags, private contacts from public views and ordinary admin presentation; authorized audit panel only | Public response and export allowlists; direct URL and RLS tests |
| VC09 | P1 | MODIFY | Company directory centered original logos, company name, sector chips, short tagline, read more, consistent cards; reuse PR162 | Phone/tablet/desktop, no full description, individual filters |
| VC10 | P1 | MODIFY | All public profiles and admin/customer forms use shared typography, spacing, labels, responsive layout; remove duplicate buttons and unnecessary internal marketing copy | Visual route matrix, no sticky overlap, no horizontal overflow |
| VC11 | P1 | ADD/INTEGRATE | Global search with approved public projections, sector/alias and exact disease matching, entity tabs, location filters, indexed pagination | Poultry returns relevant entities; unrelated vaccines excluded; no unpublished/private matches |
| VC12 | P1 | MODIFY | Master data add/edit/deactivate, reviewed suggestions, dedupe/merge/relink, audit; retain stable IDs | Permissions, parent validation, no orphan relationships |
| VC13 | P1 | MODIFY | Jobs, clinics, labs, professionals, students, owners, products, CV and reporting integrate only relevant shared fields | Per-module create/edit/search/print tests; product origin not duplicate company address |
| VC14 | P1 | MODIFY | Performance: indexed measured queries, bounded server pagination, lightweight assets, optional map links without initial embeds | Compare query plans, requests, mobile load and bundle |
| VC15 | P0 | VERIFY | GitHub exact-head CI, isolated DB migration rehearsal, rollback, production alias configuration and release controls | Tests and build pass, explicit acceptance, both aliases verified |

All items remain OPEN/PARTIAL unless evidence is recorded. PRs 159–162 are partial implementation, not universal closure. Alumni separate future issue #150. Clinical workflow #80 must be scoped against actual existing implementation; no fake completion. Main issues: #96, #132, #114, #101, #80. Preserve current branding, AdSense, approved profiles, routes and security. No duplicate source files or per-module master tables without justification.
