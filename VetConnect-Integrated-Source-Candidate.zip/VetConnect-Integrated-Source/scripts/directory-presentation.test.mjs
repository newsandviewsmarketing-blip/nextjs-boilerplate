import {test} from 'node:test';
import assert from 'node:assert/strict';
import {compactDescription, distinctLabels} from '../lib/directory-presentation.ts';
test('summary is bounded and preserves source text',()=>{const text='Company A '+ 'Animal health and nutrition. '.repeat(20);assert.ok(compactDescription(text,'Company A').length<=140);assert.ok(compactDescription(text,'Company A').startsWith('Animal health'));});
test('empty description does not invent claims',()=>assert.equal(compactDescription('', 'A'),'View the company profile for more information.'));
test('category labels deduplicate without inferring sectors',()=>assert.deepEqual(distinctLabels(' Poultry, poultry, Feed Mill, , '),['Poultry','Feed Mill']));
test('links and heading stripped from preview',()=>assert.equal(compactDescription('# About the company\n**[Website](https://example.org)**','A'),'Website'));
