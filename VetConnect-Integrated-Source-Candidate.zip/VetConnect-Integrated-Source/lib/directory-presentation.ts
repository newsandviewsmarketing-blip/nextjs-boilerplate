/** Presentation only: preserve the original record and do not infer classifications. */
export function compactDescription(value: string, companyName: string, limit = 140) {
  let text = value.replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g, "$1").replace(/^#{1,6}\s+/gm, "").replace(/\*\*/g, "").replace(/\s+/g, " ").trim();
  if (text.toLowerCase().startsWith(companyName.toLowerCase()+" ")) text=text.slice(companyName.length).trim();
  text=text.replace(/^about the company\s*[:\-]?\s*/i, "").trim();
  if (!text) return "View the company profile for more information.";
  if (text.length<=limit) return text;
  const cut=text.slice(0,limit-1), last=cut.lastIndexOf(" ");
  return (last>limit/2?cut.slice(0,last):cut)+"…";
}
export function distinctLabels(value:string|null) {
  const labels=new Map<string,string>();
  for(const item of (value??"").split(",")){const label=item.trim();if(label&&!labels.has(label.toLowerCase()))labels.set(label.toLowerCase(),label);}
  return [...labels.values()];
}
